Attribute VB_Name = "basM28V997"
''M�DULO COM FUN��ES E PROCEDURES COMUNS DO SYAS.

'AO ALTERAR ESTE M�DULO, COMPILAR E CRIAR EXECUT�VEL DE TODOS OS M�DULOS QUE O REFERENCIAM.

Option Explicit

Public gFinalizarPrograma   As Boolean
Public gAppPath         As String       'App.Path considerando sempre uma \ no final.
Public gAuxilio         As String       'Indica uso do aux�lio autom�tico: 1 = Sim e 2 = N�o.
Public gBaseLocal       As Boolean      'Indica se a base da IST est� local ou n�o
Public gCarP0043900     As String       'Endere�o do arquivo para carga da base de dados: P0043900.
Public gCarP0044000     As String       'Endere�o do arquivo para carga da base de dados: P0044000.
Public gConL28V001A     As String       'Arquivo de configura��o: L28V001A.
Public gConL28V001B     As String       'Arquivo de configura��o: L28V001B.
Public gConL28V002A     As String       'Arquivo de configura��o: L28V002A.
Public gConL28V002B     As String       'Arquivo de configura��o: L28V002B.
Public gConL28V003A     As String       'Arquivo de configura��o: L28V003A.
Public gConL28V003B     As String       'Arquivo de configura��o: L28V003B.
Public gConL28V004A     As String       'Arquivo de configura��o: L28V004A.
Public gConL28V005A     As String       'Arquivo de configura��o: L28V005A.
Public gConL28V005B     As String       'Arquivo de configura��o: L28V005B.
Public gConL28V006A     As String       'Arquivo de configura��o: L28V006A.
Public gConL28V007A     As String       'Arquivo de configura��o: L28V007A.
Public gConL28V008A     As String       'Arquivo de configura��o: L28V008A.
Public gConL28V009A     As String       'Arquivo de configura��o: L28V009A.
Public gConL28V010A     As String       'Arquivo de configura��o: L28V010A.
Public gConL28V011A     As String       'Arquivo de configura��o: L28V011A.
Public gConL28V012A     As String       'Arquivo de configura��o: L28V012A.
Public gCreate          As String       'Campo gen�rico para montar comandos Create.
Public gDelete          As String       'Campo gen�rico para montar comandos DELETE.
Public gEndP0042100     As String       'Endere�o da base de dados: P0042100.
Public gEndP0042200     As String       'Endere�o da base de dados: P0042200.
Public gEndP0042300     As String       'Endere�o da base de dados: P0042300.
Public gEndP0042400     As String       'Endere�o da base de dados: P0042400.
Public gEndP0042500     As String       'Endere�o da base de dados: P0042500.
Public gEndP0042600     As String       'Endere�o da base de dados: P0042600.
'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
Public gEndP0042601     As String       'Endere�o da base de dados: P0042601.
'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
Public gEndTAB_HIST_ROTEIRO_CALCULO     As String       'Endere�o da base de dados: TAB_HIST_ROTEIRO_CALCULO
'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
Public gEndP0042700     As String       'Endere�o da base de dados: P0042700.
Public gEndP0042800     As String       'Endere�o da base de dados: P0042800.
Public gEndP0042900     As String       'Endere�o da base de dados: P0042900.
Public gEndP0043000     As String       'Endere�o da base de dados: P0043000.
Public gEndP0043100     As String       'Endere�o da base de dados: P0043100.
Public gEndP0043200     As String       'Endere�o da base de dados: P0043200.
Public gEndP0043300     As String       'Endere�o da base de dados: P0043300.
Public gEndP0043400     As String       'Endere�o da base de dados: P0043400.
Public gEndP0043500     As String       'Endere�o da base de dados: P0043500.
Public gEndP0043600     As String       'Endere�o da base de dados: P0043600.
Public gEndP0043700     As String       'Endere�o da base de dados: P0043700.
Public gEndP0043800     As String       'Endere�o da base de dados: P0043800.
Public gEndP0043900     As String       'Endere�o da base de dados: P0043900.
Public gEndP0044000     As String       'Endere�o da base de dados: P0044000.
Public gEndP0044100     As String       'Endere�o da base de dados: P0044100.
Public gEndP0044200     As String       'Endere�o da base de dados: P0044200.
Public gEndP0044300     As String       'Endere�o da base de dados: P0044300.
Public gEndP0044400     As String       'Endere�o da base de dados: P0044400.
Public gEndP0044500     As String       'Endere�o da base de dados: P0044500.
Public gEndP0044600     As String       'Endere�o da base de dados: P0044600.
Public gEndP0044700     As String       'Endere�o da base de dados: P0044700.
Public gEndP0044800     As String       'Endere�o da base de dados: P0044800.
Public gEndP0044900     As String       'Endere�o da base de dados: P0044900.
Public gEndP0045000     As String       'Endere�o da base de dados: P0045000.
Public gEndP0045100     As String       'Endere�o da base de dados: P0045100.
Public gEndP0045200     As String       'Endere�o da base de dados: P0045200.
Public gEndP0045300     As String       'Endere�o da base de dados: P0045300.
Public gEndP0045400     As String       'Endere�o da base de dados: P0045400.

Public gEndP00MULTI     As String       'Endere�o da base de dados: P00Multi.
Public gEndRemessa      As String       'Endere�o da pasta de remessa (arquivos a serem transmitidos).
Public gEndServidor     As String       'Endere�o do servidor.
Public gEndSiscad       As String       'Endere�o do Siscad.
Public gEndSYASUpDt     As String       'Endere�o da localiza��o do s arquivos de atualiza��o do SYAS
Public gEndSYASEMIS     As String       'Endere�o da base de dados: SYASEMIS.

Public gEndSYASPROD     As String       'Endere�o da base de dados: SYASPROD
Public gUidSYASPROD     As String       'Par�metro UID para base de dados: SYASPROD.
Public gPwdSYASPROD     As String       'Par�metro PWS para base de dados: SYASPROD.
Public gSerSYASPROD     As String       'Par�metro SERVER para base de dados: SYASPROD.
Public gTipSYASPROD     As String       'Tipo da base de dados: SYASEMIS.

Public gEndEAPDB        As String
Public gUidEAPDB        As String
Public gPWDEAPDB        As String
Public gSerEAPDB        As String
Public gTipEAPDB        As String

Public gForHoje         As String       'Data do dia formatada.
Public gGraLog          As String       'Identificador de grava��o de log
                                        '"0" ou " " = N�o, "1" = Sim e "2" = Completo.
Public gHojAno          As Integer      'Data do dia: ano.
Public gHojDia          As Integer      'Data do dia: dia.
Public gHojMes          As Integer      'Data do dia: m�s.
Public gHoje            As Double       'Data do dia.
Public gImaL28V001A     As String       'Arquivo de imagem: L28V001A.
Public gImaL28V001B     As String       'Arquivo de imagem: L28V001B.
Public gImaL28V002A     As String       'Arquivo de imagem: L28V002A.
Public gImaL28V002B     As String       'Arquivo de imagem: L28V002B.
Public gImaL28V003A     As String       'Arquivo de imagem: L28V003A.
Public gImaL28V003B     As String       'Arquivo de imagem: L28V003B.
Public gImaL28V004A     As String       'Arquivo de imagem: L28V004A.
Public gImaL28V005A     As String       'Arquivo de imagem: L28V005A.
Public gImaL28V005B     As String       'Arquivo de imagem: L28V005B.
Public gImaL28V006A     As String       'Arquivo de imagem: L28V006A.
Public gImaL28V007A     As String       'Arquivo de imagem: L28V007A.
Public gImaL28V008A     As String       'Arquivo de imagem: L28V008A.
Public gImaL28V009A     As String       'Arquivo de imagem: L28V009A.
Public gImaL28V010A     As String       'Arquivo de imagem: L28V010A.
Public gImaL28V011A     As String       'Arquivo de imagem: L28V011A.
Public gImaL28V012A     As String       'Arquivo de imagem: L28V012A.
Public gInsert          As String       'Campo gen�rico para montar comandos INSERT.
Public gCodSeguradoSYAS As String       'C�digo de cliente para pesquisas do syas corretor Citrix.
Public gConcessionaria  As Boolean      'Indicador se � concession�ria.
Public gCodConcessionaria    As Integer
Public gPlanoFuncionario  As Boolean    'Indicador se � plano de funcion�rio .

Public gCod_Corretor    As Long
Public gNomUsuario      As String       'Nome do usu�rio.
Public gNomUsuario8     As String       'Nome do usu�rio (8 posi��es).
Public gNomArqLog       As String       'Nome do arquivo de log.
Public gDifEndArqLog    As String       'Endere�o direfente para o arquivo de LOG.
Public gNomUsuMainFrame As String       'Nome do usu�rio no MainFrame
Public gUltNomUsuMainFrame As String    '�ltimo Nome do usu�rio no MainFrame
Public gNomUserSYAS     As String       'Nome de Usuario do SYAS
Public gPrefixo         As String       'Prefixo.
Public gPrograma        As String       'Nome do programa em execu��o
Public gPropTabela      As String       'Propriet�rio da tabela.
Public gPwdSYASEMIS     As String       'Par�metro PWS para base de dados: SYASEMIS.
Public gSelect          As String       'Campo gen�rico para montar comandos SELECT.
Public gSerSYASEMIS     As String       'Par�metro SERVER para base de dados: SYASEMIS.
Public gTipP0042100     As String       'Tipo da base de dados: P0042100.
Public gTipP0042200     As String       'Tipo da base de dados: P0042200.
Public gTipP0042300     As String       'Tipo da base de dados: P0042300.
Public gTipP0042400     As String       'Tipo da base de dados: P0042400.
Public gTipP0042500     As String       'Tipo da base de dados: P0042500.
Public gTipP0042600     As String       'Tipo da base de dados: P0042600.
'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
Public gTipP0042601     As String       'Tipo da base de dados: P0042601.
'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
Public gTipTAB_HIST_ROTEIRO_CALCULO     As String       'Tipo da base de dados: TAB_HIST_ROTEIRO_CALCULO.
'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
Public gTipP0042700     As String       'Tipo da base de dados: P0042700.
Public gTipP0042800     As String       'Tipo da base de dados: P0042800.
Public gTipP0042900     As String       'Tipo da base de dados: P0042900.
Public gTipP0043000     As String       'Tipo da base de dados: P0043000.
Public gTipP0043100     As String       'Tipo da base de dados: P0043100.
Public gTipP0043200     As String       'Tipo da base de dados: P0043200.
Public gTipP0043300     As String       'Tipo da base de dados: P0043300.
Public gTipP0043400     As String       'Tipo da base de dados: P0043400.
Public gTipP0043500     As String       'Tipo da base de dados: P0043500.
Public gTipP0043600     As String       'Tipo da base de dados: P0043600.
Public gTipP0043700     As String       'Tipo da base de dados: P0043700.
Public gTipP0043800     As String       'Tipo da base de dados: P0043800.
Public gTipP0043900     As String       'Tipo da base de dados: P0043900.
Public gTipP0044000     As String       'Tipo da base de dados: P0044000.
Public gTipP0044100     As String       'Tipo da base de dados: P0044100.
Public gTipP0044200     As String       'Tipo da base de dados: P0044200.
Public gTipP0044300     As String       'Tipo da base de dados: P0044300.
Public gTipP0044400     As String       'Tipo da base de dados: P0044400.
Public gTipP0044500     As String       'Tipo da base de dados: P0044500.
Public gTipP0044600     As String       'Tipo da base de dados: P0044600.
Public gTipP0044700     As String       'Tipo da base de dados: P0044700.
Public gTipP0044800     As String       'Tipo da base de dados: P0044800.
Public gTipP0044900     As String       'Tipo da base de dados: P0044900.
Public gTipP0045000     As String       'Tipo da base de dados: P0045000.
Public gTipP0045100     As String       'Tipo da base de dados: P0045100.
Public gTipP0045200     As String       'Tipo da base de dados: P0045200.
Public gTipP0045300     As String       'Tipo da base de dados: P0045300.
Public gTipP0045400     As String       'Tipo da base de dados: P0045400.
Public gTipP00MULTI     As String       'Tipo da base de dados: P00MULTI.
Public gTipSYASEMIS     As String       'Tipo da base de dados: SYASEMIS.
Public gTipUsuario      As String       'Tipo do usu�rio.
Public gPerfilAcesso    As e_PerfilAcesso 'Perfil de Acesso no sistema para os usu�rios YASUDA
                                            '1 - Gestor (Digita��o com acesso Master)
                                            '2 - Usu�rio Digita��o (IST)
                                            '3 - Gestor (C�lculo)
                                            '4 - Usu�rio para C�lculo (vers�o corretor para usu�rios YASUDA)
                                            '5 - Usu�rio Digita��o (YASUDA)
Public gPerfilAjustaPremio  As Integer
                                            
Public Enum e_PerfilAcesso
    e_Perfil_DIG_Gestor = 1
    e_Perfil_DIG_IST = 2
    e_Perfil_CALC_Auto = 3
    e_Perfil_CALC = 4
    e_Perfil_DIG_Yas = 5
    e_Perfil_Operacao = 6
    e_Perfil_Triagem = 7
End Enum
Public gTipoAcesso      As e_Acesso

Public Enum e_Acesso
    DIGITACAO = 1
    CALCULO = 2
End Enum

Public gPerfilEspecial  As Long         '1 - Especial
                                        '2 - N�o especial
Public gUsuarioMulti    As Boolean      'Indica se o usu�rio � somente do sistema Multi ou � do Syas tamb�m.
Public gUidSYASEMIS     As String       'Par�metro UID para base de dados: SYASEMIS.
Public gUpdate          As String       'Campo gen�rico para montar comandos UPDATE.
Public gVerDataMaq      As Byte         '0 - N�o ver inconsist�ncia de datas
                                        '1 - Ver inconsist�ncias de data
Public gTrvSistema      As Boolean      'Travar Sistema
Public mConexaoSQL     As ADODB.Connection 'Conex�o com SQL Server.
Public Enum TipoDados
   TpoNumerico = 1
   TpoData = 2
   TpoHora = 3
   TpoValor = 4
   TpoString = 5
   TpoBoolean = 6
End Enum
Public gProibidoMsgBox      As Boolean   'Indica que um MsgBox N�o pode ser exibido nunca (Exemplo Servi�os e execu��es em modo oculto)
    
'1000515 - Multipla escolha de Assist�ncia 24horas e Vidros
Public Enum e_TipoClausula
    e_TipoClausulaComun = 0
    e_TipoClausulaAss24h = 1
    e_TipoClausulaVidros = 2
End Enum
    
    
Public Function gpRetirarCaracterEspecial(pTexto As String) As String
    'Fun��o: Retira os caracteres especiais do texto
    'Par�metros de entrada..........pTexto....Texto que ser� retirado os caracteres especiais.
    'Par�metros de sa�da......................O texto de entrada sem os caracteres especiais.
    
    Dim i       As Long
    Dim Letra   As String
    
    gpRetirarCaracterEspecial = ""
    
    For i = 1 To Len(pTexto)
        Letra = Mid(pTexto, i, 1)
        Select Case Asc(Letra)
        Case 34, 39, 59, 94, 96, 126, 168, 180, 13, 10  ' ", ', ; , ^, `, ~, �, �, 'Enter
            Letra = " "
        Case 192 To 198 ' �, �, �, �, �, �, �
            Letra = "A"
        Case 224 To 229 ' �, �, �, �, �, �, �
            Letra = "a"
        Case 199        ' �
            Letra = "C"
        Case 231        ' �
            Letra = "c"
        Case 200 To 203 ' �, �, �, �
            Letra = "E"
        Case 232 To 235 ' �, �, �, �
            Letra = "e"
        Case 204 To 207 ' �, �, �, �
            Letra = "I"
        Case 236 To 239 ' �, �, �, �
            Letra = "i"
        Case 209        ' �
            Letra = "N"
        Case 241        ' �
            Letra = "n"
        Case 210 To 214 ' �, �, �, �, �
            Letra = "O"
        Case 242 To 246 ' �, �, �, �, �
            Letra = "o"
        Case 217 To 220 ' �, �, �, �
            Letra = "U"
        Case 249 To 252 ' �, �, �, �
            Letra = "u"
        End Select
        gpRetirarCaracterEspecial = gpRetirarCaracterEspecial & Letra
    Next i
End Function

Public Function gfComBasDados_DAO(ByVal pEndBasDados As String) As Boolean
    'Fun��o: Compactar base de dados.

    'Par�metro de entrada...pEndBasDados...Endere�o da base de dados.

    Dim lCaracter       As String   'Caracter identificador do endere�o.
    Dim lNomBasDados    As String   'Nome da base de dados.
    Dim lNovBasDados    As String   'Nova base de dados.
    Dim lPosicao1       As Byte     'Posi��o 1 - utilizado com InStr.
    Dim lPosicao2       As Byte     'Posi��o 2 - utilizado com InStr.
    Dim lSegBasDados    As String   'Nome de seguran�a da base de dados.

    gfComBasDados_DAO = False

    '1. Posiciona endere�o da base de dados.
    lCaracter = "/"
    lPosicao1 = InStr(pEndBasDados, lCaracter)
    If lPosicao1 = 0 Then
        lCaracter = "\"
        lPosicao1 = InStr(pEndBasDados, lCaracter)
    End If
    Do
        lPosicao2 = InStr(lPosicao1 + 1, pEndBasDados, lCaracter)
        If lPosicao2 = 0 Then
            Exit Do
        End If
        lPosicao1 = lPosicao2
    Loop
    lNovBasDados = Left$(pEndBasDados, lPosicao1) & "BD1.MDB"
    lNomBasDados = Mid(pEndBasDados, lPosicao1 + 1, 8)
    lNomBasDados = Replace(lNomBasDados, ".", "")
    '2. Se j� existe arquivo BD1.MDB, exclu�-lo.
    If gfPreenchido(Dir(lNovBasDados)) Then
        Kill lNovBasDados
    End If

    '3. Compacta arquivo.
    
    If UCase(pEndBasDados) Like "*P00MULTI*" Or UCase(pEndBasDados) Like "*P00MPED*" Or UCase(pEndBasDados) Like "*P00APOL*" Then
        DBEngine.CompactDatabase pEndBasDados, lNovBasDados, , , ";PWD=" & LCase(lNomBasDados) & "46"
    Else
        DBEngine.CompactDatabase pEndBasDados, lNovBasDados, , , ";PWD=" & LCase(lNomBasDados) & "21"
    End If

    '4. Renomeia arquivo atual para seguran�a (salva arquivo para efeito de seguran�a).
    lSegBasDados = Left$(pEndBasDados, lPosicao1) & "XXXXXXXX.MDB"
    Name pEndBasDados As lSegBasDados

    '5. Renomeia arquivo compactado.
    Name lNovBasDados As pEndBasDados

    '6. Exclui arquivo antigo.
    Kill lSegBasDados

    gfComBasDados_DAO = True
End Function

Public Function gfAbrBasDados(ByVal pIndBasDados As String, ByVal pTipBasDados As String, _
                              ByVal pEndBasDados As String, ByRef pADOBasDados As ADODB.Connection, _
                              ByRef pMensagem As String) As Boolean
    'Fun��o: abre arquivo.

    'Par�metros de entrada...pIndBasDados...Indicador da base de dados.
    '                        pTipBasDados...Tipo da base de dados.
    '                        pEndBasDados...Endere�o da base de dados.
    'Par�metros de sa�da.....pADOBasDados...Base de dados.
    '                        pMensagem......Mensagem.
    Dim lSqlServer As Boolean
    gfAbrBasDados = False
    
    '1. Verifica indicador do arquivo.
    If Not gfPreenchido(pIndBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (indicador n�o preenchido)."
        Exit Function
    End If
    
    Select Case gTipoAcesso
        Case DIGITACAO  'Se for usu�rio de digita��o ent�o algumas tabelas dever�o ser acessadas do SQL Server
            Select Case UCase$(pIndBasDados)
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                'Inclus�o da tabela P0042601
                'Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042600", "P0042700", "P0042800"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042600", "P0042601", "P0042700", "P0042800"
                Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042600", "P0042601", "P0042700", "P0042800", "TAB_HIST_ROTEIRO_CALCULO"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                    If gBaseLocal = True Then
                        gfAbrBasDados = gfAbrBasDadosAccess(pIndBasDados, pTipBasDados, _
                              pEndBasDados, pADOBasDados, _
                              pMensagem)
                    Else
                        gfAbrBasDados = gfAbrBasSQL("DBSYASEMIS", "2", gSerSYASEMIS, _
                              gEndSYASEMIS, gUidSYASEMIS, gPwdSYASEMIS, pADOBasDados, _
                              pMensagem)
                    End If
                Case "SYAS_EMIS", "P0044000", "P0042500", "P0043000"
                    gfAbrBasDados = gfAbrBasSQL("DBSYASEMIS", "2", gSerSYASEMIS, _
                            gEndSYASEMIS, gUidSYASEMIS, gPwdSYASEMIS, pADOBasDados, _
                            pMensagem)
                Case Else
                    If gPerfilAcesso = e_Perfil_DIG_IST Or UCase(pIndBasDados) = "P0045400" Then
                        gfAbrBasDados = gfAbrBasDadosAccess(pIndBasDados, pTipBasDados, _
                              pEndBasDados, pADOBasDados, _
                              pMensagem)
                    Else
                        gfAbrBasDados = gfAbrBasSQL("DBSYASEMIS", "2", gSerSYASEMIS, _
                                gEndSYASEMIS, gUidSYASEMIS, gPwdSYASEMIS, pADOBasDados, _
                                pMensagem)
                    End If
            End Select
        Case Else
            lSqlServer = False
            If UCase(pIndBasDados) = "SYAS_EMIS" And gPerfilAcesso = e_Perfil_CALC_Auto Then
                lSqlServer = True
            ElseIf (gTipUsuario = 1 And (UCase(pIndBasDados) = "P0044000" Or UCase(pIndBasDados) = "P0043000")) Then
                lSqlServer = True
                If UCase(pEndBasDados) Like "S:\SYASPROD\AUTOMOVEL\*" And gPerfilAcesso = 3 Then
                    lSqlServer = False
                End If
            ElseIf gPropTabela <> "" Then
                'marcia colocou o P00MULTI
                If (pIndBasDados = "P0043900" And gTipUsuario = 1) Or pIndBasDados = "P00MULTI" Then
                    lSqlServer = False
                Else
                'Select Case UCase$(pIndBasDados)
                    'Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042500", "P0042600", "P0042700", "P0042800", "SYAS_EMIS", "P0044000"
                        lSqlServer = True
                'End Select
                End If
            End If
            
            If lSqlServer = True Then
                If UCase(pIndBasDados) = "SYASPROD" Then
                    gfAbrBasDados = gfAbrBasSQL("DBSYASEMIS", "2", gSerSYASPROD, _
                            gEndSYASPROD, gUidSYASPROD, gPwdSYASPROD, pADOBasDados, _
                            pMensagem)
                ElseIf UCase(pIndBasDados) = "EAPDB" Then
                    gfAbrBasDados = gfAbrBasSQL("EAPDB", "2", gSerEAPDB, _
                            gEndEAPDB, gUidEAPDB, gPWDEAPDB, pADOBasDados, _
                            pMensagem)
                Else
                    gfAbrBasDados = gfAbrBasSQL("DBSYASEMIS", "2", gSerSYASEMIS, _
                            gEndSYASEMIS, gUidSYASEMIS, gPwdSYASEMIS, pADOBasDados, _
                            pMensagem)
                End If
            Else
                gfAbrBasDados = gfAbrBasDadosAccess(pIndBasDados, pTipBasDados, _
                              pEndBasDados, pADOBasDados, _
                              pMensagem)
            End If
    End Select
    On Error GoTo 0
End Function
Public Function gfRepBasDados_DAO(ByVal pArquivo As String) As Boolean
    'Fun��o: Repara arquivo.

    gfRepBasDados_DAO = False

    On Error Resume Next
    DBEngine.RepairDatabase pArquivo
    If Err <> 0 Then
        Call gpGraLog(2, "FTE0024 - Erro ao reparar arquivo " & pArquivo & ": " & Err & " - " & Error & _
                          ".")
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    gfRepBasDados_DAO = True
End Function

Public Function gfCompactar(ByVal pEndBasDados As String) As Boolean
    'Fun��o: compactar base de dados.

    'Par�metro de entrada...pEndBasDados...Endere�o da base de dados.

    gfCompactar = False

    '1. Verifica endere�o da base de dados.
    If Not gfPreenchido(pEndBasDados) Then
        Call gpGraLog(2, "FTE0038 - Endere�o da base de dados n�o preenchido (processo de compactar " & _
                         "base de dados).")
        Exit Function
    End If

    '2. Inicia processo para reparar e compactar base de dados.
    'panAviso.Caption = "Compactando base de dados " & pEndBasDados & "."
    'panAviso.Visible = True
    'panAviso.Refresh
    Call gpGraLog(0, "AGE0013 - Compacta base de dados " & pEndBasDados & _
                     " (in�cio - data da �ltima atualiza��o: " & FileDateTime(pEndBasDados) & _
                     " - tamanho: " & FileLen(pEndBasDados) & ").")

    '3. Repara base de dados.
    If gfRepBasDados_DAO(pEndBasDados) = False Then
        Exit Function
    End If

    '4. Compacta base de dados.
    If gfComBasDados_DAO(pEndBasDados) = False Then
        Exit Function
    End If

    '5. Encerra processo.
    Call gpGraLog(0, "AGE0013 - Compacta base de dados " & pEndBasDados & _
                     " (t�rmino - data da �ltima atualiza��o: " & FileDateTime(pEndBasDados) & _
                     " - tamanho: " & FileLen(pEndBasDados) & ").")
    'panAviso.Visible = False
    'panAviso.Refresh

    gfCompactar = True
End Function
Public Function gfAbrBasDadosAccess(ByVal pIndBasDados As String, ByVal pTipBasDados As String, _
                              ByVal pEndBasDados As String, ByRef pADOBasDados As ADODB.Connection, _
                              ByRef pMensagem As String) As Boolean
    'Fun��o: abre arquivo.

    'Par�metros de entrada...pIndBasDados...Indicador da base de dados.
    '                        pTipBasDados...Tipo da base de dados.
    '                        pEndBasDados...Endere�o da base de dados.
    'Par�metros de sa�da.....pADOBasDados...Base de dados.
    '                        pMensagem......Mensagem.

    Dim lAbriu          As Boolean  'Abriu a base de dados?
    Dim lComando        As String   'Comando.
    Dim lDriver(6)      As String   'Drivers.
    Dim lErrDriver(6)   As String   'Grava mensagem de erro obtida em cada driver
    Dim li              As Byte     'Utilizado com For...Next.
    Dim lIniCatalog     As String   'Par�metro INITIAL CATALOG.
    Dim lPwd            As String   'Par�metro PWD.
    Dim lServer         As String   'Par�metro SERVER.
    Dim lTemErro        As Boolean  'Tem erro?
    Dim lUid            As String   'Par�metro UID.
    Dim lMsgErro        As String   'Mensagem de erro

    gfAbrBasDadosAccess = False

    '1. Verifica indicador do arquivo.
    If Not gfPreenchido(pIndBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (indicador n�o preenchido)."
        Exit Function
    End If
    Select Case UCase$(pIndBasDados)
        'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
        'Inclus�o da tabela P0042601
        Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042500", "P0042600", "P0042700", _
             "P0042800", "P0042900", "P0043000", "P0043100", "P0043200", "P0043300", "P0043400", _
             "P0043500", "P0043600", "P0043700", "P0043800", "P0043900", "P0044000", "P0044100", _
             "P0044200", "P0044300", "P0044400", "P0044500", "P0044600", "P0044700", "P0044800", _
             "P0044900", "P0045000", "P0045100", "P0045200", "P0045300", "P0045400", "EAPDB", _
             "L28V001", "CONNECT", "P00MULTI", "P00APOL", "P00MPED, P0042601"
        'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
            'Nada a fazer - arquivos v�lidos.
        Case Else
            pMensagem = "FTE0001 - Erro ao abrir base de dados (indicador desconhecido - " & _
                        pIndBasDados & ")."
            Exit Function
    End Select

    '2. Verifica tipo do arquivo.
    If Not gfPreenchido(pTipBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & _
                    " - tipo da base de dados n�o preenchido)."
        Exit Function
    End If
    If pTipBasDados <> "1" Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & _
                    " - tipo da base de dados desconhecido: " & pTipBasDados & ")."
        Exit Function
    End If

    '3. Verifica endere�o do arquivo.
    If Not gfPreenchido(pEndBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & _
                    " - endere�o da base de dados n�o preenchido)."
        Exit Function
    End If
    If Not gfPreenchido(Dir(pEndBasDados)) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & _
                    " - endere�o da base de dados n�o localizado: " & pEndBasDados & ")."
        Exit Function
    End If

    '4. Abre arquivo.
    lDriver(1) = "Microsoft Access Driver (*.mdb)"
    lDriver(2) = "Microsoft Access Driver(*.mdb)"
    lDriver(3) = "Driver do Microsoft Access (*.mdb)"
    lDriver(4) = "Driver do Microsoft Access(*.mdb)"
    lDriver(5) = "Driver para o Microsoft Access (*.mdb)"
    lDriver(6) = "Driver para o Microsoft Access(*.mdb)"
    lTemErro = False
    lAbriu = False
    lMsgErro = ""
    For li = 1 To 6
        'a) Posiciona conex�o.
        On Error Resume Next
        Set pADOBasDados = New ADODB.Connection
        If Err <> 0 Then
            pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & _
                        " - comando: SET New ADODB.Connection - Erro " & Err & " - " & Error & ")."
            lTemErro = True
            Exit For
        End If
        'b) Posiciona propriedade CursorLocation.
        pADOBasDados.CursorLocation = adUseClient
        If Err <> 0 Then
            pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & _
                        " - comando: CursorLocation = adUseClient - Erro " & Err & " - " & Error & ")."
            lTemErro = True
            Exit For
        End If
        'c) Abre arquivo.
        lComando = "Driver={" & lDriver(li) & "};Dbq=" & pEndBasDados
        If gGraLog = "2" Then
            Call gpGraLog(0, "AGE0000 - gfAbrBasDadosAccess : lComando=" & lComando & " pIndBasDados=" & pIndBasDados)
        End If
        If pIndBasDados = "P00MULTI" Or pIndBasDados = "P00APOL" Or pIndBasDados = "P00MPED" Then
            pADOBasDados.Open lComando, , LCase(pIndBasDados) & "46"
        Else
            pADOBasDados.Open lComando, , LCase(pIndBasDados) & "21"
        End If
        If Err = 0 Then
            lAbriu = True
            Exit For
        Else
            lMsgErro = " - Erro " & Err & " - " & Error
            'o n�mero da msg � o mesmo, por isso estou consistindo pelo nome.
            If InStr(1, UCase(lMsgErro), "CORROMPIDO") > 0 Or InStr(1, UCase(lMsgErro), "DANIFICADO") > 0 Then
                lMsgErro = " - Arquivo corrompido ou danificado."
                Exit For
            ElseIf InStr(1, UCase(lMsgErro), "N�O � UM CAMINHO V�LIDO") > 0 Or InStr(1, UCase(lMsgErro), "ESCRITO CORRETAMENTE") > 0 Then
                lMsgErro = " - Problemas de comunica��o, verifique comunica��o com a rede."
                Exit For
            ElseIf InStr(1, UCase(lMsgErro), "MODO EXCLUSIVO") > 0 Or InStr(1, UCase(lMsgErro), "PERMISS�O") > 0 Then
                If Len(pEndBasDados) > 12 Then
                    lMsgErro = " - Privil�gios insuficientes no diret�rio " & Left(pEndBasDados, Len(pEndBasDados) - 12)
                Else
                    lMsgErro = " - Privil�gios insuficientes no diret�rio " & gAppPath
                End If
                Exit For
            End If
            'Guarda a mensagem de erro n�o prevista
            lErrDriver(li) = lMsgErro
        End If
        On Error GoTo 0
    Next li
    If lTemErro Then
        On Error GoTo 0
        Exit Function
    End If
    If lAbriu = False Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (" & pIndBasDados & " - comando: " & _
                    lComando & IIf(lMsgErro = "", " - Erro " & Err & " - " & Error, lMsgErro) & ")."
        For li = 1 To 6
            'Concatena mensagens de erro diferentes
            If gfPreenchido(lErrDriver(li)) = True Then
                If lErrDriver(li) <> lMsgErro Then
                    pMensagem = pMensagem & Chr(13) & "- " & li & lErrDriver(li)
                End If
            End If
        Next li
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    gfAbrBasDadosAccess = True
End Function

Public Function gfBuscaUsuarioTransmissao(ByRef pCodUsuTransmissao As Long, ByRef pMensagem As String) _
                                          As Boolean
    'Fun��o: busca usu�rio de transmiss�o.

    'Par�metros de sa�da...pCodUsuTransmissao...C�digo do usu�rio.
    '                      pMensagem............Mensagem.

    Dim lCodUsuario         As Long     'C�digo do usu�rio.
    Dim lEndSyasEdi_EXE    As String    'Endere�o do arquivo SYASEDI.EXE.
    Dim lNumSyasEdi_EXE    As Integer   'Utilizado com FreeFile.
    Dim lRegistro           As String   'Registro.

    gfBuscaUsuarioTransmissao = False

    '1. Verifica arquivo SYASEDI.EXE.
    lEndSyasEdi_EXE = gAppPath & "SYASEDI.EXE"
    If Not gfPreenchido(Dir(lEndSyasEdi_EXE)) Then
        'Procuro pelo arquivo antigo
        lEndSyasEdi_EXE = gAppPath & "Eapscript.INI"
        If Not gfPreenchido(Dir(lEndSyasEdi_EXE)) Then
            pMensagem = "FTExxxx - Erro ao obter c�digo do usu�rio de transmiss�o (identifica��o n�o " & _
                        "localizada)." & vbLf & vbLf & "Reinicie o processo de c�lculo."
            Exit Function
        End If
    End If
    lNumSyasEdi_EXE = FreeFile
    On Error Resume Next
    Open lEndSyasEdi_EXE For Input Access Read As #lNumSyasEdi_EXE
    If Err <> 0 Then
        pMensagem = "FTExxxx - Erro ao obter c�digo do usu�rio de transmiss�o (" & Err & " - " & _
                    Error & ")." & vbLf & vbLf & "Reinicie o processo de c�lculo."
        Exit Function
    End If
    On Error GoTo 0

    '2. Obt�m c�digo do usu�rio.
    Do While Not EOF(lNumSyasEdi_EXE)
        Line Input #lNumSyasEdi_EXE, lRegistro
        If Mid(lRegistro, 1, 7) = "sender=" Then
            lCodUsuario = Val(Mid(lRegistro, 9, 6))
            Exit Do
        End If
    Loop
    Close #lNumSyasEdi_EXE
    pCodUsuTransmissao = lCodUsuario
    Call gpGraLog(0, "Buscou Syasedi.exe")
    gfBuscaUsuarioTransmissao = True
End Function

Public Function gfExeSQL(ByVal pBasDados As ADODB.Connection, ByVal pComando As String, _
                         ByRef pMensagem As String, Optional ByRef pRegAfetados As Long) As Double
    'Fun��o: executa comando SQL.

    'Par�metros de entrada...pBasDados......base de dados.
    '                        pComando ......comando SQL a ser executado.
    'Par�metros de sa�da.....pMensagem......mensagem.
    '                        pRegAfetados...quantidade de registros afetados pelo comando SQL (OPCIONAL).

    'Resultado da fun��o.....C�digo de retorno do comando SQL: 0 = comando OK.
Inicio:
    gfExeSQL = 999
    
    'If Not pComando Like "*[filesize]*" Then
    '    Call gpGraLog(0, "AGE0000 - gfExeSQL : pComando=" & pComando)
    'End If
    
    
    If InStr(1, UCase(pBasDados), "SYAS_EMIS") > 0 And InStr(1, pComando, "exec ") = 0 Then
        pComando = " exec [SYAS_EMIS].[SYAS].[Yproc_ExecDML] '" & Replace(pComando, "'", "!;$") & "'"
    Else
        If InStr(1, UCase(pBasDados), "EAPDB") > 0 Then
            pComando = " exec EAPDB_ExecDML '" & Replace(pComando, "'", "!;$") & "'"
        End If
    End If
    
    If gGraLog = "2" Then
        Call gpGraLog(0, "AGE0000 - gfExeSQL : pComando=" & pComando)
    End If
    If UCase(pBasDados) Like "*MIX*" Then
        'Call gpGraLog(0, pComando)
    End If
    On Error Resume Next
    If IsMissing(pRegAfetados) Then
        pBasDados.Execute pComando
    Else
        pBasDados.Execute pComando, pRegAfetados
    End If
    If Err <> 0 Then
        If UCase(Err.Description) Like "FALHA DE V�NCULO DE COMUNICA��O" Or _
            UCase(Err.Description) Like "COMMUNICATION LINK FAILURE" Then
            Call gpGraLog(0, Err.Description)
            If UCase(App.EXEName) = "P28V200" Then
                If InStr(1, UCase(pBasDados), "EAPDB") > 0 Then
                    Set pBasDados = Nothing
                    
                    If gfAbrBasSQL(gEndSYASEMIS, gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, gUidSYASEMIS, _
                                   gPwdSYASEMIS, pBasDados, pMensagem) = False Then
                        Call gpGraLog(2, pMensagem)
                        Exit Function
                    End If
                    GoTo Inicio
                Else
                    If UCase(pBasDados) Like "*MIX*" Then
                        If gfAbrBasSQL("DBSYASEMIS", "2", "SPX20112CSLUMIX", "SYAS_EMIS", "workflow", _
                                             "yasworkflow", pBasDados, pMensagem) = False Then
                            Call gpGraLog(2, pMensagem)
                            Exit Function
                        End If
                    Else
                        Set pBasDados = Nothing
                        If gfAbrBasSQL("DBSYASEMIS", "2", "LPX20102PSLUSQL", "SYAS_EMIS", "workflow", _
                                             "yasworkflow", pBasDados, pMensagem) = False Then
                            Call gpGraLog(2, pMensagem)
                            Exit Function
                        End If
                    End If
                    GoTo Inicio
                End If
            End If
            Call gpGraLog(2, "Comunica��o com o banco de dados foi perdida. Verifique se o acesso ao servidor " & Mid(pBasDados, InStr(1, pBasDados, "SERVER=") + 7, 15) & " e reinicie o procedimento.")
            Select Case UCase(App.EXEName)
                Case "P28V100", "P28V200", "P28V101", "P28V001"
                    'End
                    Exit Function
            End Select
        End If
                                                                                                        '***
        pMensagem = "FTE0027 - Erro ao executar comando SQL: " & Err & " - " & Error & " - " & pComando '& vbCrLf & "Conex�o:" & pBasDados.ConnectionString
    End If
    gfExeSQL = Err      'Este comando precisa ser o �ltimo antes do On Error GoTo 0.
    On Error GoTo 0
End Function

Public Function gfObtRegistro(ByVal pNomArquivo As ADODB.Connection, ByVal pComando As String, _
                              ByRef pRegistro As ADODB.Recordset, ByRef pMensagem As String) As Boolean
    'Fun��o: obt�m registro.

    'Par�metros de entrada...pNomArquivo...Nome do arquivo.
    '                        pComando .....Comando SELECT.
    'Par�metros de sa�da.....pRegistro.....Registro (recordset).
    '                        pMensagem.....Mensagem.
    Dim lInicio As Double
    gfObtRegistro = False
Inicio:
    
    On Error Resume Next

    Set pRegistro = New ADODB.Recordset

    pRegistro.CursorLocation = adUseClient
    'Abre o Recordset

    'If gGraLog = "2" Then
    
    'If pComando Like "*exec*" Then
    '    Call gpGraLog(0, pComando)
    'End If

    If InStr(1, UCase(pNomArquivo), "SYAS_EMIS") > 0 Then
        If InStr(1, UCase(pComando), "GED") > 0 And _
           InStr(1, UCase(pComando), "SYAS_EMIS") > 0 Then
           
           'N�o altera o comando
           
        Else
         'Somente se n�o estiver fazendo "JOIN" entre tabelas da base GED e SYAS_EMIS
         'atraves de conex�o com a base SYAS_EMIS
            pComando = Replace(pComando, "'", "!;$")
            If Len(pComando) > 5000 Then
                pComando = " exec [SYAS_EMIS].[SYAS].[Yproc_ExecDML2] '" & Mid(pComando, 1, 7500) & "','" & Mid(pComando, 7501) & "'"
            Else
                pComando = " exec [SYAS_EMIS].[SYAS].[Yproc_ExecDML2] '" & Mid(pComando, 1, 10) & "','" & Mid(pComando, 11) & "'"
            End If
        End If
    Else
        If InStr(1, UCase(pNomArquivo), "EAPDB") > 0 Then
            pComando = " exec EAPDB_ExecDML '" & Replace(pComando, "'", "!;$") & "'"
        End If
    End If
    lInicio = Timer
    If UCase(pNomArquivo) Like "*MIX*" Then
        'Call gpGraLog(0, pComando)
    End If
    pRegistro.Open pComando, pNomArquivo, adOpenForwardOnly, adLockReadOnly
    'Set pRegistro = pNomArquivo.Execute(pComando)
    If Err <> 0 Then
        If UCase(Err.Description) Like "FALHA DE V�NCULO DE COMUNICA��O" Or _
            UCase(Err.Description) Like "COMMUNICATION LINK FAILURE" Then
            Call gpGraLog(0, Err.Description & " / tentativa de se reconectar")
            If UCase(App.EXEName) = "P28V200" Then
                If InStr(1, UCase(pNomArquivo), "EAPDB") > 0 Then
                    Set pNomArquivo = Nothing
                    
                    If gfAbrBasSQL(gEndSYASEMIS, gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, gUidSYASEMIS, _
                                   gPwdSYASEMIS, pNomArquivo, pMensagem) = False Then
                        Call gpGraLog(2, pMensagem)
                        Call gpGraLog(0, pMensagem & " / erro na tentativa de se reconectar")
                        Exit Function
                    End If
                    GoTo Inicio
                Else
                    If UCase(pNomArquivo) Like "*MIX*" Then
                        If gfAbrBasSQL("DBSYASEMIS", "2", "SPX20112CSLUMIX", "SYAS_EMIS", "workflow", _
                                             "yasworkflow", pNomArquivo, pMensagem) = False Then
                            Call gpGraLog(2, pMensagem)
                            Exit Function
                        End If
                    Else
                        Set pNomArquivo = Nothing
                        If gfAbrBasSQL("DBSYASEMIS", "2", "LPX20102PSLUSQL", "SYAS_EMIS", "workflow", _
                                             "yasworkflow", pNomArquivo, pMensagem) = False Then
                            Call gpGraLog(2, pMensagem)
                            Exit Function
                        End If
                    End If
                    GoTo Inicio
                End If
            End If
            Call gpGraLog(2, "Comunica��o com o banco de dados foi perdida. Verifique se o acesso ao servidor " & Mid(pNomArquivo, InStr(1, pNomArquivo, "SERVER=") + 7, 15) & " e reinicie o procedimento.")
            Select Case UCase(App.EXEName)
                Case "P28V100", "P28V200", "P28V101", "P28V001"
                    'End
                    Exit Function
            End Select
        End If
        pMensagem = "FTE0044 - Erro ao obter registro (Erro = " & Err & " - " & Error & _
                        " - comando: " & pComando & ")."
        Exit Function
    End If
    If InStr(pNomArquivo, "UID=") = 0 And InStr(pNomArquivo, "Initial Catalog=") = 0 Then
        Set pRegistro.ActiveConnection = Nothing
    End If
    Select Case Err
        Case 0      'Sem erro.
            gfObtRegistro = True
        Case 3159   'Marcador inv�lido - arquivo dados corrompido.
            pMensagem = "FTE0044 - Erro ao obter registro (arquivo corrompido - comando: " & pComando & _
                        ")."
        Case Else
            pMensagem = "FTE0044 - Erro ao obter registro (Erro = " & Err & " - " & Error & _
                        " - comando: " & pComando & ")."
    End Select
    On Error GoTo 0
End Function

Public Function gfPreenchido(ByVal pCampo) As Boolean
    'Fun��o: verifica se campo preenchido.

    If IsNull(pCampo) Then
        gfPreenchido = False
    Else
        If Len(Trim(pCampo)) = 0 Then
            gfPreenchido = False
        Else
            gfPreenchido = True
        End If
    End If
End Function

Public Sub gpFecha1(ByRef pTabela As ADODB.Recordset)
    'Procedure: fecha tabela.

    'Par�metro de entrada...pTabela...Vari�vel Recordset.
    If Not pTabela Is Nothing Then
        If pTabela.State = 1 Then
            pTabela.Close
        End If
    End If
    Set pTabela = Nothing
End Sub

Public Sub gpFecha2(ByRef pBasDados As ADODB.Connection)
    'Procedure: fecha arquivo.

    'Par�metro de entrada...pBasDados...Vari�vel Database.
    If Not pBasDados Is Nothing Then
        If InStr(1, UCase(pBasDados.ConnectionString), ".MDB") > 0 Then
            If pBasDados.State = 1 Then
                pBasDados.Close
            End If
            Set pBasDados = Nothing
        End If
    End If
End Sub

Public Sub gpFecha3(ByRef pTabela As ADODB.Recordset, ByRef pBasDados As ADODB.Connection)
    'Procedure: fecha tabela e arquivo.

    'Par�metros de entrada...pTabela.....Recordset da tabela.
    '                        pBasDados...Vari�vel Database.

    '1. Fecha tabela.
    If pTabela.State = 1 Then
        pTabela.Close
    End If
    Set pTabela = Nothing

    '2. Fecha arquivo.
    If InStr(1, UCase(pBasDados.ConnectionString), ".MDB") > 0 Then
        If pBasDados.State = 1 Then
            pBasDados.Close
        End If
        Set pBasDados = Nothing
    End If
End Sub


Public Sub gpGraLog(ByVal pOpcao As Byte, ByVal pMensagem As String)
    'Procedure: grava arquivo log.

    'Par�metros de entrada...pOpcao......0 = grava log.
    '                                    1 = grava log e emite mensagem.
    '                                    2 = grava log e emite mensagem com frase inicial
    '                                        "Comunique Central de Atendimento".
    '                        pMensagem...Mensagem.

Dim lMensagem           As String   'Mensagem.
Dim lNumLog             As Integer  'N�mero do arquivo log.
Dim lPosicao            As Integer  'Utilizado com InStr.
Dim lmsgErr             As String   'Mensagem de erro dentro desta procedure
Dim lCkPoint            As String    'Variavel utilizada para determinar pontos onde o c�digo j� passou.
Dim lArqAberto          As Boolean

Static lEndLog          As String   'Endere�o do arquivo log.
Static lNomComputador   As String   'Nome do computador.
Static lNomPrograma     As String   'Nome do programa.
Static lNomUsuario      As String   'Nome do usu�rio.
Static lNumMensagem     As Integer  'N�mero de mensagem.
Static lPriVez          As Boolean  'Indicador de primeira vez (false).

Err = 0
On Error GoTo TRATAMENTO_ERRO
    
'1. Verifica op��o.
    lCkPoint = "1"
    If Not gfPreenchido(pOpcao) Then
        MsgBox "FTE0006 - Op��o inv�lida (grava log - n�o preenchida)."
        GoTo SAIDA
    End If
    lCkPoint = "2"
    If Not IsNumeric(pOpcao) Then
        MsgBox "FTE0006 - Op��o inv�lida (grava log - n�o num�rica)."
        GoTo SAIDA
    End If
    lCkPoint = "3"
    If pOpcao <> 0 And pOpcao <> 1 And pOpcao <> 2 Then
        MsgBox pMensagem
        MsgBox "FTE0006 - Op��o inv�lida (grava log - diferente de 0, 1 e 2 - " & pOpcao & ")."
        GoTo SAIDA
    End If
    lCkPoint = "4"
    If gVerDataMaq = 1 Then
        lCkPoint = "5"
        If gfIncDatas = False Then
            'Travar o sistema
            gTrvSistema = True
        End If
    End If
    lCkPoint = "6    "
'2. Ao executar esta procedure pela primeira vez, obter dados utilizados na grava��o das mensagens.
    If lPriVez = False Then
        lCkPoint = "7"
        lPriVez = True
        'a) Verifica arquivo log.
        lCkPoint = "8"
        If gfPreenchido(gNomArqLog) = False Then
            gNomArqLog = "SYASPROD.LOG"
        End If
        lCkPoint = "9"
        If gfPreenchido(gDifEndArqLog) = False Then
            lEndLog = gAppPath & gNomArqLog
        Else
            'Favor consistir o uso da variavel "gDifEndArqLog"
            'antes de iniciar o programa (sub MAIN)
            lEndLog = gDifEndArqLog & gNomArqLog
        End If
        
        'b) Obt�m nome do usu�rio.
        lCkPoint = "10"
        If gfPreenchido(gNomUsuario) Then
            lCkPoint = "11"
            lNomUsuario = gNomUsuario
            While Len(lNomUsuario) < 20
                lCkPoint = "12"
                lNomUsuario = lNomUsuario & " "
            Wend
            lCkPoint = "13"
        Else
            lCkPoint = "14"
            lNomUsuario = String(20, "X")
        End If
        lCkPoint = "15"
        'c) Obt�m nome do computador.
        lNomComputador = GetLoginComputerName()
        lCkPoint = "16"
        If Not gfPreenchido(lNomComputador) Then
            lNomComputador = "********"
        End If
        lCkPoint = "17"
        While Len(lNomComputador) < 16
            lCkPoint = "18"
            lNomComputador = lNomComputador & " "
        Wend
        lCkPoint = "19"
        'd) Obt�m nome do programa.
        lNomPrograma = Trim$(App.EXEName)
        lCkPoint = "20"
        While Len(lNomPrograma) < 12
            lCkPoint = "21"
            lNomPrograma = lNomPrograma & " "
        Wend
        lCkPoint = "22"
    End If
    lCkPoint = "23"
    
'3. Consiste par�metro de entrada (Mensagem).
    lCkPoint = "24"
    If Not gfPreenchido(pMensagem) Then
        lCkPoint = "25"
        pMensagem = "FTE0045 - Mensagem n�o preenchida."
    End If
    lCkPoint = "26"
'4. Ajusta a mensagem
    lMensagem = pMensagem
    Do
        lCkPoint = "27"
        lPosicao = InStr(lMensagem, vbLf)
        lCkPoint = "28"
        If lPosicao = 0 Then
            Exit Do
        End If
        lCkPoint = "29"
        lMensagem = Left$(lMensagem, lPosicao - 1) & " " & Mid$(lMensagem, lPosicao + 1)
    Loop
        
'3. Abre arquivo log.
    lCkPoint = "30"
    lNumLog = FreeFile
    lCkPoint = "31"
    lArqAberto = False
    lCkPoint = "32"
    Open lEndLog For Append Shared As #lNumLog
        lCkPoint = "33"
        lArqAberto = True
        
        'x. Posiciona n�mero da mensagem.
        lCkPoint = "34"
        If lNumMensagem = 9999 Then
            lCkPoint = "35"
            lNumMensagem = 1
        Else
            lCkPoint = "36"
            lNumMensagem = lNumMensagem + 1
        End If
        lCkPoint = "37"
    
        'x. Grava mensagem.
        'Print #lNumLog, lMensagem
        Print #lNumLog, gForHoje & " | " & Format$(Now, "hh:nn:ss") & " | " & lNomUsuario & " | " & _
                        lNomComputador & " | " & lNomPrograma & " | " & Format$(lNumMensagem, "0000") & _
                        " | " & lMensagem
        lCkPoint = "38"
FecharArquivo:
    lCkPoint = "36"
    Close #lNumLog
    lCkPoint = "40"
    lArqAberto = False      'marca que o arquivo n�o est� mais aberto
    lCkPoint = "41"
    
'6. Emite mensagem ao usu�rio.
    lCkPoint = "42"
    
    If App.EXEName = "D028O003" Then gProibidoMsgBox = True
    
    If gProibidoMsgBox = True Then
        pOpcao = 0
    End If
    Select Case pOpcao
        Case 0
            lCkPoint = "43"
            'Nada a fazer.
        Case 1
            lCkPoint = "44"
            MsgBox pMensagem
        Case 2
            lCkPoint = "45"
            MsgBox "Comunique Central de Atendimento. " & vbLf & vbLf & pMensagem & vbLf & vbLf & "Data/Hora da ocorr�ncia : " & gForHoje & " " & Format$(Now, "Hh:Nn:Ss")
    End Select
    lCkPoint = "46"
    
SAIDA:
    If lArqAberto = True Then
        'Fecha o arquivo caso o c�digo tenha sido desviado para o erro
        'ap�s ter aberto o arquivo.
        Close #lNumLog
        lArqAberto = False
    End If
    Err = 0
    On Error GoTo 0
    Exit Sub
    
TRATAMENTO_ERRO:
    If gfPreenchido(lmsgErr) = False Then
        lmsgErr = Err & " - " & Error
    End If
    lmsgErr = "gpGraLog Erro " & lmsgErr
    lmsgErr = lmsgErr & vbCrLf & "CheckPoint " & lCkPoint
    
    lMensagem = "Comunique Central de Atendimento. " & vbLf & vbLf & lMensagem & vbLf & vbLf & "Data/Hora da ocorr�ncia : " & gForHoje & " " & Format$(Now, "Hh:Nn:Ss")
    lmsgErr = lmsgErr & vbCrLf & vbCrLf & gForHoje & " | " & Format$(Now, "hh:nn:ss") & " | " & lNomUsuario & " | " & _
                                            lNomComputador & " | " & lNomPrograma & " | " & Format$(lNumMensagem, "0000") & _
                                            " | " & lMensagem
    If pOpcao <> 0 Then
        MsgBox lmsgErr
    End If
    
    GoTo SAIDA
    
End Sub

Public Function gfIncDatas() As Boolean

    'Fun��o:        Verifica se houve altera��o de data do micro.
    
Dim lDataReg        As String   'Data que est� salva no registro
Dim lDataMaq        As String   'Data da m�quina
Dim lStatusData     As String   'Status data
Dim lEndDest        As String   'Endere�o do arquivo para destravar.
Dim lMensagem       As String   'Mensagem
Dim lDestravado     As Byte     '0 - Travado
                                '1 - Destravado
Dim lNumDestr       As Byte     'utilizado no freefile
Dim lRegistro       As Variant  'Linha que est� no arquivo
Dim lDatArq         As String   'Data que est� no arquivo de destravamento
Dim lUltEnd         As String   'Ultimo arquivo destravado

    '1. Monto a mensagem de sistema bloqueado.
    lMensagem = "Comunique Central de Atendimento. " & vbLf & vbLf & _
                "FGE0111 - O sistema est� bloqueado pois houve uma altera��o na data/hora da m�quina." & vbCrLf & _
                "Para desbloquear o sistema, acerte a data/hora da m�quina e entre em contato com a central de atendimento."
    
    '2. Busco o registro da �ltima data de log.
    lDataReg = GetSetting("SYAS", "UltimaData", "LOG")
    lDataReg = Replace(lDataReg, ".", "/")
    lDataReg = Replace(lDataReg, "-", "/")
    lStatusData = GetSetting("SYAS", "StatusData", "LOG")
    lDataMaq = Format(Date, "dd/mm/yyyy")
    lUltEnd = GetSetting("SYAS", "ArquivoDestravar", "LOG")
    
    '3. Se n�o tinha nada salvo ent�o grava a data atual no registro.
    If lDataReg = "" Then
        SaveSetting "SYAS", "UltimaData", "LOG", lDataMaq
        lDataReg = lDataMaq
    End If
    
    '4. Verifico se pode continuar ou n�o.
    If lStatusData = "TRAVADO" Then
        lDestravado = 0
        '� necess�rio destravar o sistema.
        'Verifico se existe o arquivo que destrava o sistema.
        lEndDest = Dir(gAppPath & "*.dtr")
        lDatArq = "01/01/1001 00:00:00"
        Do While lEndDest <> ""
            'Nome do arquivo:
                'dd - dia atual                             --> Exemplo (17)
                'mm - m�s atual                             --> Exemplo (01)
                'yyyy - dois primeiros n�mero do ano atual  --> Exemplo (2004)
                'hh - horas                                 --> Exemplo (16)
                'mm - minutos                               --> Exemplo (26)
                'ss - dois �ltimo n�mero do ano atual       --> Exemplo (04)
                'resultado ddmmyyyyhhmmss.dtr               --> Exemplo 17012004162604.dtr
                
            If Len(lEndDest) = 18 Then
                If lEndDest <> lUltEnd Then
                    If lUltEnd <> "" Then
                        If CDate(Mid(lEndDest, 1, 2) & "/" & Mid(lEndDest, 3, 2) & "/" & Mid(lEndDest, 5, 4) & " " & Mid(lEndDest, 9, 2) & ":" & Mid(lEndDest, 11, 2) & ":" & Mid(lEndDest, 13, 2)) < CDate(Mid(lUltEnd, 1, 2) & "/" & Mid(lUltEnd, 3, 2) & "/" & Mid(lUltEnd, 5, 4) & " " & Mid(lUltEnd, 9, 2) & ":" & Mid(lUltEnd, 11, 2) & ":" & Mid(lUltEnd, 13, 2)) Then
                            lDestravado = 3
                        End If
                    End If
                    If CDate(Mid(lEndDest, 1, 2) & "/" & Mid(lEndDest, 3, 2) & "/" & Mid(lEndDest, 5, 4) & " " & Mid(lEndDest, 9, 2) & ":" & Mid(lEndDest, 11, 2) & ":" & Mid(lEndDest, 13, 2)) > CDate(lDatArq) And lDestravado = 0 Then
                        lDatArq = CDate(Mid(lEndDest, 1, 2) & "/" & Mid(lEndDest, 3, 2) & "/" & Mid(lEndDest, 5, 4) & " " & Mid(lEndDest, 9, 2) & ":" & Mid(lEndDest, 11, 2) & ":" & Mid(lEndDest, 13, 2))
                        lNumDestr = FreeFile
                        Open lEndDest For Input As #lNumDestr
                        While Not EOF(lNumDestr)
                            'a) Obt�m registro de entrada.
                            Line Input #lNumDestr, lRegistro
                            If gfCripEncript(lRegistro, 0) <> lEndDest Then
                                If gfCripEncript(lRegistro, 0) <> lEndDest & "T" Then
                                    lDestravado = 0
                                    SaveSetting "SYAS", "StatusData", "LOG", "TRAVADO"
                                Else
                                    SaveSetting "SYAS", "StatusData", "LOG", "DESTRAVADO"
                                    SaveSetting "SYAS", "UltimaData", "LOG", Format(Date, "dd/mm/yyyy")
                                    lDestravado = 1
                                End If
                            Else
                                If lDataMaq < lDataReg Then
                                    'Se a data do computador n�o foi ajustada ainda finalizo o sistema
                                    lDestravado = 0
                                Else
                                    'Se igual destravo
                                    SaveSetting "SYAS", "StatusData", "LOG", "DESTRAVADO"
                                    SaveSetting "SYAS", "ArquivoDestravar", "LOG", lEndDest
                                    lDestravado = 1
                                End If
                            End If
                        Wend
                        Close #lNumDestr
                        Kill (gAppPath & "*.dtr")
                    Else
                        Kill (gAppPath & "*.dtr")
                    End If
                End If
            End If
            lEndDest = Dir      ' Obt�m a pr�xima entrada.
        Loop
        If lDestravado = 0 Or lDestravado = 3 Then
            MsgBox lMensagem
            gfIncDatas = False
            Exit Function
        End If
    ElseIf CDate(lDataMaq) < CDate(lDataReg) Then
        'Finalizo o sistema
        SaveSetting "SYAS", "StatusData", "LOG", "TRAVADO"
        If Dir(gAppPath & "*.dtr") <> "" Then
            Kill (gAppPath & "*.dtr")
        End If
        MsgBox lMensagem
        gfIncDatas = False
        Exit Function
    ElseIf lDataMaq <> lDataReg Then
        'Registro a �ltima data
        SaveSetting "SYAS", "UltimaData", "LOG", lDataMaq
    End If
    gfIncDatas = True
End Function

Function gfCripEncript(ByVal strng, force%)
    'C�digo copiado da internet para encriptar e decriptar
    
Dim chK             As String
Dim look            As String
Dim addin           As String
Dim eNcryptflag     As String
Dim passUP          As String
Dim passMAx         As String
Dim looPer          As Variant
Dim tOChange        As String
Dim password        As String

  'Set error capture routine
  On Local Error GoTo ErrorHandler

  password = "Password"
  'Is there a strng$ to work with?
  If Len(strng) = 0 Then Error 31100

  
  'Check if file is encrypted and not forcing
  If force% = 0 Then
    
    'Check for encryption ID tag
    chK = Left$(strng, 4) + Right$(strng, 4)
    
    If chK = Chr$(1) + "KT" + Chr$(1) + Chr$(1) + "KT" + Chr$(1) Then
      
      'Remove ID tag
      strng = Mid$(strng, 5, Len(strng) - 8)
      
      'String was encrypted so filter out CHR$(1) flags
      look = 1
      Do
        look = InStr(look, strng, Chr$(1))
        If look = 0 Then
          Exit Do
        Else
          addin = Chr$(Asc(Mid$(strng, look + 1)) - 1)
          strng = Left$(strng, look - 1) + addin + Mid$(strng, look + 2)
        End If
        look = look + 1
      Loop
      
      'Since it is encrypted we want to decrypt it
      eNcryptflag = False
    
    Else
      'Tag not found so flag to encrypt string
      eNcryptflag = True
    End If
  Else
    'force% flag set, ecrypt string regardless of tag
    eNcryptflag = True
  End If
    


  'Set up variables
  passUP = 1
  passMAx = Len(password)
  
  
  'Tack on leading characters to prevent repetative recognition
  password = Chr$(Asc(Left$(password, 1)) Xor passMAx) + password
  password = Chr$(Asc(Mid$(password, 1, 1)) Xor Asc(Mid$(password, 2, 1))) + password
  password = password + Chr$(Asc(Right$(password, 1)) Xor passMAx)
  password = password + Chr$(Asc(Right$(password, 2)) Xor Asc(Right$(password, 1)))
  
  
  'If Encrypting add password check tag now so it is encrypted with string
  If eNcryptflag = True Then
    strng = Left$(password, 3) + Format$(Asc(Right$(password, 1)), "000") + Format$(Len(password), "000") + strng
  End If
  
  'Loop until scanned though the whole string
  For looPer = 1 To Len(strng)
DoEvents
    'Alter character code
    tOChange = Asc(Mid$(strng, looPer, 1)) Xor Asc(Mid$(password, passUP, 1))

    'Insert altered character code
    Mid$(strng, looPer, 1) = Chr$(tOChange)
    
    'Scroll through password string one character at a time
    passUP = passUP + 1
    If passUP > passMAx + 4 Then passUP = 1
      
  Next looPer

  'If encrypting we need to filter out all bad character codes (0, 10, 13, 26)
  If eNcryptflag = True Then
    'First get rid of all CHR$(1) since that is what we use for our flag
    look = 1
    Do
      look = InStr(look, strng, Chr$(1))
      If look > 0 Then
        strng = Left$(strng, look - 1) + Chr$(1) + Chr$(2) + Mid$(strng, look + 1)
        look = look + 1
      End If
    Loop While look > 0

    'Check for CHR$(0)
    Do
      look = InStr(strng, Chr$(0))
      If look > 0 Then strng = Left$(strng, look - 1) + Chr$(1) + Chr$(1) + Mid$(strng, look + 1)
    Loop While look > 0

    'Check for CHR$(10)
    Do
      look = InStr(strng, Chr$(10))
      If look > 0 Then strng = Left$(strng, look - 1) + Chr$(1) + Chr$(11) + Mid$(strng, look + 1)
    Loop While look > 0

    'Check for CHR$(13)
    Do
      look = InStr(strng, Chr$(13))
      If look > 0 Then strng = Left$(strng, look - 1) + Chr$(1) + Chr$(14) + Mid$(strng, look + 1)
    Loop While look > 0

    'Check for CHR$(26)
    Do
      look = InStr(strng, Chr$(26))
      If look > 0 Then strng = Left$(strng, look - 1) + Chr$(1) + Chr$(27) + Mid$(strng, look + 1)
    Loop While look > 0

    'Tack on encryted tag
    strng = Chr$(1) + "KT" + Chr$(1) + strng + Chr$(1) + "KT" + Chr$(1)

  Else
    
    'We decrypted so ensure password used was the correct one
    If Left$(strng, 9) <> Left$(password, 3) + Format$(Asc(Right$(password, 1)), "000") + Format$(Len(password), "000") Then
      'Password bad cause error
      Error 31100
    Else
      'Password good, remove password check tag
      strng = Mid$(strng, 10)
    End If

  End If


  'Set function equal to modified string
  gfCripEncript = strng
  

  'Were out of here
  Exit Function


ErrorHandler:
  'We had an error!  Were out of here
  Exit Function
End Function
Public Sub gpInicia(Optional ByRef pTipUsuario As String, Optional pMsgErr As String)
    'Procedure: obt�m informa��es inicias do sistema:
    '           - Arquivo de inicializa��o: tipo do usu�rio, endere�os das bases de dados (endere�o do
    '                                       servidor), endere�os dos arquivos imagem e configura��o de
    '                                       impress�o e indicador de uso do aux�lio autom�tico.
    '           - Nome do usu�rio (ou c�digo do usu�rio no caso de corretor).
    '           - Para usu�rio Yasuda, verifica se o Segsul est� liberado.

    Dim lAuxiliar           As String   'Auxiliar.
    Dim lEndSyasEdi_EXE    As String    'Endere�o do arquivo SyasEdi.EXE.
    Dim lEndSyaslibSGS      As String   'Endere�o do arquivo SYASLIB.SGS.
    Dim lLiberado           As Boolean  'Indica que o Segsul est� liberado.
    Dim lLimite             As Double   'Data limite para o arquivo de libera��o do Segsul.
    Dim lNumSyasEdi_EXE    As Integer   'Utilizado com FreeFile para o arquivo SYASEDI.EXE.
    Dim lNumSyaslibSGS      As Integer  'Utilizado com FreeFile para o arquivo SYASLIB.SGS.
    Dim lPosicao            As Integer  'Utilizado com InStr.
    Dim lRegSyasEdi_EXE    As String    'Registro do arquivo SYASEDI.EXE.
    Dim lRegSyaslibSGS      As String   'Registro do arquivo SYASLIB.SGS.

Dim lCkPoint As String
On Error GoTo ControleErro: pMsgErr = ""
    lCkPoint = "01"
    '1. Posiciona data de hoje.
    gHoje = CDbl(Format$(Now, "yyyymmdd")): lCkPoint = "02"
    lAuxiliar = Format$(gHoje, "00000000"): lCkPoint = "03"
    gHojDia = CInt(Mid$(lAuxiliar, 7, 2)): lCkPoint = "04"
    gHojMes = CInt(Mid$(lAuxiliar, 5, 2)): lCkPoint = "05"
    gHojAno = CInt(Mid$(lAuxiliar, 1, 4)): lCkPoint = "06"
    gForHoje = Format$(Now, "dd/mm/yyyy"): lCkPoint = "07"

    '2. Posiciona controle dos endere�os dos arquivos (gAppPath).
    If Right$(App.Path, 1) = "\" Then
        gAppPath = App.Path
    Else
        gAppPath = App.Path & "\"
    End If: lCkPoint = "08"
    
    'Evita erros de localiza��o de arquivos
    ChDir App.Path: lCkPoint = "09"
    
    '3. Obt�m dados do arquivo de inicializa��o.
ObtemDados:
    ' Se o direcionamento das bases de dados P0042400 e P0042900
    ' estiverem diferentes do direcionamento da Base P0042100
    ' Entra na Procedure gpReescreveSYASPROD
    gGraLog = 0
    'If gfPreenchido(gNumPI) = False Then gNumPI = "0"
    If mfObtSYASPRODINI = False Then
        lCkPoint = "10"
        If gFinalizarPrograma = True Then Exit Sub
       Call gpReescreveSYASPROD: lCkPoint = "11"
       GoTo ObtemDados
    Else
        lCkPoint = "12"
        If gPrograma = "YASUDA.EXE" Or gPrograma = "D028O002" Or gPrograma = "D028O003" Or gPrograma = "P28V800" Then
            'Sai da orcedure para processar o arquivo Yasuda.exe processar as
            'Atualiza��es
            pTipUsuario = gTipUsuario
            Exit Sub
        End If: lCkPoint = "13"
    End If: lCkPoint = "14"

    '4. Verifica informa��es.
    'a) Tipo de usu�rio.
    If Not gfPreenchido(gTipUsuario) Then
        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (tipo do usu�rio n�o preenchido).")
        gFinalizarPrograma = True
        Exit Sub
    End If: lCkPoint = "15"
    If Not IsNumeric(gTipUsuario) Then
        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (tipo do usu�rio n�o num�rico).")
        gFinalizarPrograma = True
        Exit Sub
    End If: lCkPoint = "16"
    If gTipUsuario <> "1" And gTipUsuario <> "2" And gTipUsuario <> "3" Then
        lCkPoint = "17"
        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (tipo do usu�rio desconhecido).")
        gFinalizarPrograma = True
        Exit Sub
    End If: lCkPoint = "18"
        'b) Nome do usu�rio.
        Select Case gTipUsuario
            Case "1"        'Yasuda.
                lCkPoint = "19"
                gNomUsuario = Trim$(GetLoginUserName)
                If Not gfPreenchido(gNomUsuario) Then
                    lCkPoint = "20"
                    Call gpGraLog(2, "FTE0028 - Identifica��o do usu�rio Yasuda n�o localizada.")
                    gFinalizarPrograma = True
                    Exit Sub
                End If: lCkPoint = "21"
                If Len(gNomUsuario) > 8 Then
                    gNomUsuario8 = Left$(gNomUsuario, 8)
                Else
                    gNomUsuario8 = gNomUsuario
                End If: lCkPoint = "22"
            Case "2"        'Corretor.
                lCkPoint = "23"
                lEndSyasEdi_EXE = gAppPath & "SYASEDI.EXE"
                If Not gfPreenchido(Dir(lEndSyasEdi_EXE)) Then
                    lEndSyasEdi_EXE = gAppPath & "EAPSCRIPT.INI"
                End If: lCkPoint = "24"
                If Not gfPreenchido(Dir(lEndSyasEdi_EXE)) Then
                    gNomUsuario = "XXXXXXXX": lCkPoint = "25"
                Else
                    lCkPoint = "26"
                    lNumSyasEdi_EXE = FreeFile: lCkPoint = "27"
                    Open lEndSyasEdi_EXE For Input Access Read As #lNumSyasEdi_EXE: lCkPoint = "28"
                    If Err <> 0 Then
                        lCkPoint = "29"
                        Call gpGraLog(2, "FTE0026 - Erro ao abrir arquivo " & lEndSyasEdi_EXE & ": " & _
                                         Err & " - " & Error & vbLf & vbLf & "O sistema ser� encerrado.")
                        On Error GoTo 0
                        gFinalizarPrograma = True
                        Exit Sub
                    End If: lCkPoint = "30"
                    Do While Not EOF(lNumSyasEdi_EXE)
                        Line Input #lNumSyasEdi_EXE, lRegSyasEdi_EXE: lCkPoint = "31"
                        lRegSyasEdi_EXE = UCase$(lRegSyasEdi_EXE): lCkPoint = "32"
                        lPosicao = InStr(lRegSyasEdi_EXE, "SENDER="""): lCkPoint = "33"
                        If lPosicao <> 0 Then
                            gNomUsuario = Mid(lRegSyasEdi_EXE, lPosicao + 8, 6): lCkPoint = "34"
                            Exit Do
                        End If: lCkPoint = "35"
                    Loop: lCkPoint = "36"
                    Close #lNumSyasEdi_EXE: lCkPoint = "37"
                    If Not gfPreenchido(gNomUsuario) Then
                        gNomUsuario = "XXXXXXXX": lCkPoint = "38"
                    End If: lCkPoint = "39"
                End If: lCkPoint = "40"
                gNomUsuario8 = gNomUsuario: lCkPoint = "41"
            Case "3"
                lCkPoint = "42"
                gNomUsuario = Trim$(GetLoginUserName): lCkPoint = "43"
                If Not gfPreenchido(gNomUsuario) Then
                    lCkPoint = "44"
                    Call gpGraLog(2, "FTE0028 - Identifica��o do usu�rio Yasuda n�o localizada.")
                    gFinalizarPrograma = True
                    Exit Sub
                End If: lCkPoint = "45"
                If Len(gNomUsuario) > 8 Then
                    gNomUsuario8 = Left$(gNomUsuario, 8): lCkPoint = "46"
                Else
                    gNomUsuario8 = gNomUsuario: lCkPoint = "47"
                End If: lCkPoint = "48"
                If Dir(gAppPath & gNomUsuario & ".txt") <> "" Then
                    Dim lArq As Integer: lCkPoint = "49"
                    Dim lNomArq As String: lCkPoint = "50"
                    lArq = FreeFile: lCkPoint = "51"
                    lNomArq = gAppPath & gNomUsuario & ".txt": lCkPoint = "52"
                    Open lNomArq For Input Access Read As lArq: lCkPoint = "53"
                    Do While Not EOF(lArq)
                        Line Input #lArq, lAuxiliar: lCkPoint = "54"
                        If UCase(lAuxiliar) Like "*CORRETOR*" Then
                            gCod_Corretor = Replace(UCase(lAuxiliar), "CORRETOR=", ""): lCkPoint = "56"
                        End If: lCkPoint = "57"
                        If UCase(lAuxiliar) Like "*SEGURADO*" Then
                            gCodSeguradoSYAS = Replace(UCase(lAuxiliar), "SEGURADO=", ""): lCkPoint = "58"
                        End If: lCkPoint = "59"
                    Loop: lCkPoint = "60"
                Else
                    Dim lMensagem   As String: lCkPoint = "61"
                    If Not mfCarregaUsuarioPortal(lMensagem) Then
                        lCkPoint = "62"
                        Call gpGraLog(1, lMensagem)
                        gFinalizarPrograma = True
                        Exit Sub
                    End If: lCkPoint = "63"
                End If: lCkPoint = "64"
        End Select: lCkPoint = "65"
        'c) Verifica indicador de aux�lio autom�tico do T28V101A.
        If Not gfPreenchido(gAuxilio) Then
            gAuxilio = "1": lCkPoint = "66"
        End If: lCkPoint = "67"
    
        '5. Verifica arquivo de libera��o do Segsul.
        If gTipUsuario = "1" Then
            lEndSyaslibSGS = gAppPath & "SYASLIB.SGS": lCkPoint = "68"
            If gfPreenchido(Dir(lEndSyasEdi_EXE)) Then
                lNumSyaslibSGS = FreeFile: lCkPoint = "69"
                Open lEndSyaslibSGS For Input Access Read As lNumSyaslibSGS: lCkPoint = "70"
                If Err = 0 Then
                    Line Input #lNumSyaslibSGS, lRegSyaslibSGS: lCkPoint = "71"
                    lLiberado = False: lCkPoint = "72"
                    If gfPreenchido(lRegSyaslibSGS) Then
                        lRegSyaslibSGS = Trim$(lRegSyaslibSGS): lCkPoint = "73"
                        If Len(lRegSyaslibSGS) = 1 Then
                            If Left$(lRegSyaslibSGS, 1) = "1" Then
                                lLiberado = True: lCkPoint = "74"
                            End If: lCkPoint = "75"
                        End If: lCkPoint = "76"
                    End If: lCkPoint = "77"
                    Close lNumSyaslibSGS: lCkPoint = "78"
                    If lLiberado = True Then
                        'Bloquear Segsul.
                        lLimite = CDbl(Format$(FileDateTime(lEndSyaslibSGS), "yyyymmddhhnnss")) + 1000: lCkPoint = "79"
                        If Mid(lLimite, 11, 2) > 60 Then
                            lLimite = lLimite + 10000: lCkPoint = "80"
                            lLimite = lLimite - 6000: lCkPoint = "81"
                        End If: lCkPoint = "82"
                        If CDbl(Format$(Now, "yyyymmddhhnnss")) > lLimite Then
                            Open lEndSyaslibSGS For Output As #lNumSyaslibSGS: lCkPoint = "83"
                            Print #lNumSyaslibSGS, "2": lCkPoint = "84"
                            Close lNumSyaslibSGS: lCkPoint = "85"
                        End If: lCkPoint = "86"
                    End If: lCkPoint = "87"
                End If: lCkPoint = "88"
        End If: lCkPoint = "89"
    End If: lCkPoint = "90"
    
    pTipUsuario = gTipUsuario
    
SAIDA:
    Err.Clear
    On Error GoTo 0
    Exit Sub
    
ControleErro:
    If Not gfPreenchido(pMsgErr) Then
        pMsgErr = "gpInicia Erro:" & Err & " - " & Err.Description
    End If
    pMsgErr = pMsgErr & " ||CkPoint:" & lCkPoint
    GoTo SAIDA
    
End Sub
Public Function mfCarregaUsuarioPortal(pMensagem As String) As Boolean
Dim lSql        As String
Dim lRst        As ADODB.Recordset

    On Error GoTo ControleErro
    
    If Not gfAbrBasDados("SYAS_EMIS", gTipSYASEMIS, gEndSYASEMIS, mConexaoSQL, pMensagem) Then
        Exit Function
    End If
        
    lSql = " select cod_cli , cli.COD_CORR , cod_portal, Cod_Cons From yasudanet.dbo.Tab_Grupo_Corr as c inner join yasudanet.dbo.Tab_Portal_Acesso as a"
    lSql = lSql & " on c.cod_user = a.cod_user  inner join ged.dbo.tab_cliente as cli on  cod_cli = num_susep "
    lSql = lSql & " where c.Cod_User = '" & gNomUsuario & "' And cod_portal in (6,3)"
    
    If Not gfObtRegistro(mConexaoSQL, lSql, lRst, pMensagem) Then
        GoTo ProcuraCorretor
    End If
    
    gConcessionaria = False
    gPlanoFuncionario = False
    gCodSeguradoSYAS = ""
    gCodConcessionaria = 0
    If Not lRst.EOF Then
        gCod_Corretor = lRst("Cod_Corr")
        gCodSeguradoSYAS = lRst("Cod_Cli")
        If lRst("cod_portal") = "3" Then
            gConcessionaria = True
            gCodConcessionaria = gfTratarNulo(lRst("cod_cons"), TpoNumerico)
        Else
            gPlanoFuncionario = True
        End If
        'If UCase(gNomUsuario) = "ABRF01" Then
        '    gPlanoFuncionario = False
        'End If
    Else
ProcuraCorretor:
        'Verifico se � o corretor
        lSql = " select cod_cli , cli.COD_CORR , cod_cons From"
        lSql = lSql & " yasudanet.dbo.Tab_Grupo_Corr as c INNER join yasudanet.dbo.Tab_Portal_Acesso as a"
        lSql = lSql & " on c.cod_user = a.cod_user"
        lSql = lSql & " INNER JOIN yasudanet.dbo.Tab_USER_CITRIX  AS u"
        lSql = lSql & " ON C.cod_user = u.cod_user_portal"
        lSql = lSql & " INNER join ged.dbo.tab_cliente as cli"
        lSql = lSql & " on  cod_cli = cod_acesso"
        lSql = lSql & " where u.cod_user_citrix = '" & gNomUsuario & "' And cod_portal in (1)"
        If Not gfObtRegistro(mConexaoSQL, lSql, lRst, pMensagem) Then
            Exit Function
        End If
        If Not lRst.EOF Then
            gCod_Corretor = lRst("Cod_Corr")
            gCodSeguradoSYAS = lRst("Cod_Cli")
            gConcessionaria = True
            gCodConcessionaria = gfTratarNulo(lRst("cod_cons"), TpoNumerico)
        Else
            lSql = " select cod_corretor From yasudanet.dbo.Tab_Grupo_Corr as c inner join yasudanet.dbo.Tab_Portal_Acesso as a on c.cod_user = a.cod_user  "
            lSql = lSql & " inner join ged.dbo.tbs_corretor as co on co.num_susep = c.num_susep "
            lSql = lSql & " where c.Cod_User = '" & gNomUsuario & "' And cod_portal = 1"
            lSql = lSql & " and cod_ativo = 1"
            
            If Not gfObtRegistro(mConexaoSQL, lSql, lRst, pMensagem) Then
                Exit Function
            End If
            If Not lRst.EOF Then
                gCod_Corretor = lRst("cod_corretor")
            Else
                pMensagem = "AGE0178 - Usu�rio n�o cadastrado. Acesso negado."
                GoTo ControleErro
            End If
        End If
    End If
    mfCarregaUsuarioPortal = True
    Exit Function
ControleErro:
    If Not gfPreenchido(pMensagem) Then
        pMensagem = Err.Description
    End If
End Function
Public Sub gpReescreveSYASPROD()
' Procedure que reescreve o arquivo SYASPROD.INI
' Somente � acionada caso ender�o das bases de dados P0042400 e P0042900
' sejam diferentes do endere�o da base de dados de cota��o P0042100

Dim l_EndBasesCotacao       As String 'Caminho do Direcionamento das bases
Dim lEndSyasprodINI         As String 'Endereco do SYASPROD.INI
Dim lEndSyasProd001         As String 'Endereco da Copia do arquivo SYASPRO.INI renomeada para SYASPROD.001
Dim lRegistro               As String
Dim lNumSyasprodINI         As String
Dim lNumSyasProd001         As String

' Caminho da base de Dados de Cota��o P0042100
l_EndBasesCotacao = Mid(gEndP0042100, 1, (Len(gEndP0042100) - 12))


    Dim lContaLinha As Byte
    
    ' Inicia A Variavel
    ' Se lContaLinha = 0 Escreve o registro sem altera��o
    ' Se lContaLinha = 1 escreve o registro sem altera��o e incremente lContaLinha
    ' Se lContaLinha = 3 escreve o registro utilizando caminho da base de dados P0042100
    
    lContaLinha = 0
    
    '---
    lEndSyasprodINI = gAppPath & "SYASPROD.INI"
    lEndSyasProd001 = gAppPath & "SYASPROD.001"
        '---------------
    FileCopy lEndSyasprodINI, lEndSyasProd001
    
    lNumSyasProd001 = FreeFile
    On Error Resume Next
    Open lEndSyasProd001 For Input Access Read As #lNumSyasProd001
    If Err <> 0 Then
        Call gpGraLog(1, "FTE0026 - Erro ao abrir arquivo " & lEndSyasProd001 & ": " & Err & _
                         " - " & Error & vbLf & vbLf & "O sistema ser� encerrado.")
        gFinalizarPrograma = True
        Exit Sub
    Else
    
        lNumSyasprodINI = FreeFile
        On Error Resume Next
        Open lEndSyasprodINI For Output Access Write As #lNumSyasprodINI
        Do While Not EOF(lNumSyasProd001)
            Line Input #lNumSyasProd001, lRegistro
                      
            ' Encontrou Titulo da base de dados a ser alteraodo o Caminho
            If lRegistro = "[P0042400]" Or lRegistro = "[P0042900]" Then
            lContaLinha = 1
            End If
            
            
            If lContaLinha = 3 Then ' Escreve caminho novo da base de dados
                
                Print #lNumSyasprodINI, Left(lRegistro, 9) & l_EndBasesCotacao & _
                                        Right(lRegistro, 12)
                lContaLinha = 0 ' Reinicia a variavel para n�o entrar neste processo outra vez
                
            Else
                Print #lNumSyasprodINI, lRegistro
                
                If lContaLinha > 0 Then ' Incrementa o contador
                    lContaLinha = lContaLinha + 1
                End If
                
            End If
            
        Loop
        Close #lNumSyasprodINI
        Close #lNumSyasProd001
        
        Kill lEndSyasProd001
    
    End If


End Sub
Private Function mfObtSYASPRODINI() As Boolean
    'Fun��o: obt�m dados do arquivo SYASPROD.INI.

    Dim lConImpressao() As String   'Arquivos de impress�o: endere�o do arquivo de configura��o.
    Dim lDado           As String   'Dado da linha de registro.
    Dim lDesconhecido   As Boolean  'Tipo desconhecido.
    Dim lEndBasDados()  As String   'Bases de dados: endere�os.
    Dim lEndereco       As String   'Endereco.
    Dim lEndSyasprodINI As String   'Endere�o do arquivo SYASPROD.INI.
    Dim li              As Integer  'Utilizado com For...Next.
    Dim lImaImpressao() As String   'Arquivos de impress�o: endere�o do arquivo de imagem.
    Dim lNomImpressao() As String   'Arquivos de impress�o: nomes.
    Dim lNomBasDados()  As String   'Bases de dados: nomes.
    Dim lNumSyasprodINI As Integer  'Utilizado com FreeFile para o arquivo SYASPROD.INI.
    Dim lPosicao        As Integer  'Utilizado com InStr.
    Dim lQuaBasDados    As Byte     'Bases de dados: quantidade.
    Dim lQuaImpressao   As String   'Arquivos de impress�o: quantidade.
    Dim lRegSyasprodINI As String   'Registro do arquivo SYASPROD.INI.
    Dim lTamanho        As Integer  'Tamanho.
    Dim lTipBasDados()  As String   'Bases de dados: tipos.
    Dim lTipo           As String   'Tipo de linha do arquivo de inicializa��o.
    Dim lTitulo         As String   'Linha de t�tulo.
    Dim lPathP0042100   As String   'Localiza��o Da base P0042100 obtido na leitura do arquivo SYASPROD.INI
    Dim lPathP0042400   As String   'Localiza��o Da base P0042400 obtido na leitura do arquivo SYASPROD.INI
    Dim lPathP0042900   As String   'Localiza��o Da base P0042900 obtido na leitura do arquivo SYASPROD.INI
    
    On Error GoTo ControleErro
    '1. Abre arquivo SYASPROD.INI.
    lEndSyasprodINI = gAppPath & "SYASPROD.INI"
    If Not gfPreenchido(Dir(lEndSyasprodINI)) Then
        Call gpGraLog(2, "FTE0025 - Arquivo n�o localizado: " & lEndSyasprodINI & _
                         " (obter dados de inicializa��o do sistema)." & vbLf & vbLf & _
                         "O sistema ser� encerrado.")
        gFinalizarPrograma = True
        Exit Function
    End If
    lNumSyasprodINI = FreeFile
    On Error Resume Next
    Open lEndSyasprodINI For Input Access Read As lNumSyasprodINI
    If Err <> 0 Then
        Call gpGraLog(2, "FTE0026 - Erro ao abrir arquivo " & lEndSyasprodINI & ": " & Err & " - " & _
                         Error & vbLf & vbLf & "O sistema ser� encerrado.")
        On Error GoTo 0
        gFinalizarPrograma = True
        Exit Function
    End If
    On Error GoTo ControleErro

    '2. Trata registros do arquivo de inicializa��o.
    lDesconhecido = False
    Do While Not EOF(lNumSyasprodINI)
        Line Input #lNumSyasprodINI, lRegSyasprodINI
        If gfPreenchido(lRegSyasprodINI) Then
            Select Case Left$(lRegSyasprodINI, 1)
                Case ";"    'Linha de observa��o.
                    'Nada a processar - linha de observa��o.
                Case "["    'Linha de t�tulo.
                    lTitulo = Trim$(UCase$(lRegSyasprodINI))
                Case Else   'Linha de tipo.
                    lRegSyasprodINI = Trim$(lRegSyasprodINI)
                    lPosicao = InStr(lRegSyasprodINI, "=")
                    lTamanho = Len(lRegSyasprodINI)
                    If lPosicao = 0 Then
                        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (sinal de igual " & _
                                         "n�o localizado no registro)." & vbLf & vbLf & _
                                         lRegSyasprodINI & vbLf & vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
                    If lPosicao = 1 Then
                        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (sinal de igual " & _
                                         "na primeira posi��o do registro)." & vbLf & vbLf & _
                                         lRegSyasprodINI & vbLf & vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
                    If lPosicao = lTamanho Then
                        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (sinal de igual " & _
                                         "na �ltima posi��o do registro)." & vbLf & vbLf & _
                                         lRegSyasprodINI & vbLf & vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
                    lTipo = Trim$(UCase$(Left$(lRegSyasprodINI, lPosicao - 1)))
                    lDado = Trim$(Mid$(lRegSyasprodINI, lPosicao + 1))
                    Select Case lTitulo
                        Case "[AUXILIO]"
                            Select Case lTipo
                                Case "TIPO"
                                    gAuxilio = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[DBSYASEMIS]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipSYASEMIS = lDado
                                Case "SERVER"
                                    gSerSYASEMIS = lDado
                                Case "DATABASE"
                                    gEndSYASEMIS = lDado
                                Case "UID"
                                    gUidSYASEMIS = lDado
                                Case "PWD"
                                    gPwdSYASEMIS = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[DBSYASPROD]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipSYASPROD = lDado
                                Case "SERVER"
                                    gSerSYASPROD = lDado
                                Case "DATABASE"
                                    gEndSYASPROD = lDado
                                Case "UID"
                                    gUidSYASPROD = lDado
                                Case "PWD"
                                    gPwdSYASPROD = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[DBEAPDB]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipEAPDB = lDado
                                Case "SERVER"
                                    gSerEAPDB = lDado
                                Case "DATABASE"
                                    gEndEAPDB = lDado
                                Case "UID"
                                    gUidEAPDB = lDado
                                Case "PWD"
                                    gPWDEAPDB = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V001A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V001A = lDado
                                Case "IMAGEM"
                                    gImaL28V001A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V002A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V002A = lDado
                                Case "IMAGEM"
                                    gImaL28V002A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V002B]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V002B = lDado
                                Case "IMAGEM"
                                    gImaL28V002B = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V003A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V003A = lDado
                                Case "IMAGEM"
                                    gImaL28V003A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V004A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V004A = lDado
                                Case "IMAGEM"
                                    gImaL28V004A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V005A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V005A = lDado
                                Case "IMAGEM"
                                    gImaL28V005A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V005B]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V005B = lDado
                                Case "IMAGEM"
                                    gImaL28V005B = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V006A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V006A = lDado
                                Case "IMAGEM"
                                    gImaL28V006A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V007A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V007A = lDado
                                Case "IMAGEM"
                                    gImaL28V007A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V008A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V008A = lDado
                                Case "IMAGEM"
                                    gImaL28V008A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V009A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V009A = lDado
                                Case "IMAGEM"
                                    gImaL28V009A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V010A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V010A = lDado
                                Case "IMAGEM"
                                    gImaL28V010A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[L28V011A]"
                            Select Case lTipo
                                Case "CONFIG"
                                    gConL28V011A = lDado
                                Case "IMAGEM"
                                    gImaL28V011A = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042100]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042100 = lDado
                                Case "DATABASE"
                                    gEndP0042100 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042200]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042200 = lDado
                                Case "DATABASE"
                                    gEndP0042200 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042300]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042300 = lDado
                                Case "DATABASE"
                                    gEndP0042300 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042400]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042400 = lDado
                                Case "DATABASE"
                                    gEndP0042400 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042500]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042500 = lDado
                                Case "DATABASE"
                                    gEndP0042500 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042600]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042600 = lDado
                                Case "DATABASE"
                                    gEndP0042600 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                        Case "[P0042601]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042601 = lDado
                                Case "DATABASE"
                                    gEndP0042601 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                        'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                        Case "[TAB_HIST_ROTEIRO_CALCULO]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipTAB_HIST_ROTEIRO_CALCULO = lDado
                                Case "DATABASE"
                                    gEndTAB_HIST_ROTEIRO_CALCULO = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                        Case "[P0042700]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042700 = lDado
                                Case "DATABASE"
                                    gEndP0042700 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042800]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042800 = lDado
                                Case "DATABASE"
                                    gEndP0042800 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0042900]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0042900 = lDado
                                Case "DATABASE"
                                    gEndP0042900 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043000]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043000 = lDado
                                Case "DATABASE"
                                    gEndP0043000 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043100]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043100 = lDado
                                Case "DATABASE"
                                    gEndP0043100 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043200]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043200 = lDado
                                Case "DATABASE"
                                    gEndP0043200 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043300]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043300 = lDado
                                Case "DATABASE"
                                    gEndP0043300 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043400]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043400 = lDado
                                Case "DATABASE"
                                    gEndP0043400 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043500]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043500 = lDado
                                Case "DATABASE"
                                    gEndP0043500 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043600]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043600 = lDado
                                Case "DATABASE"
                                    gEndP0043600 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043700]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043700 = lDado
                                Case "DATABASE"
                                    gEndP0043700 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043800]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043800 = lDado
                                Case "DATABASE"
                                    gEndP0043800 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0043900]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0043900 = lDado
                                Case "DATABASE"
                                    gEndP0043900 = lDado
                                Case "CARGA"
                                    gCarP0043900 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044000]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044000 = lDado
                                Case "DATABASE"
                                    gEndP0044000 = lDado
                                Case "CARGA"
                                    gCarP0044000 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044100]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044100 = lDado
                                Case "DATABASE"
                                    gEndP0044100 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044200]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044200 = lDado
                                Case "DATABASE"
                                    gEndP0044200 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044300]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044300 = lDado
                                Case "DATABASE"
                                    gEndP0044300 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044400]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044400 = lDado
                                Case "DATABASE"
                                    gEndP0044400 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044500]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044500 = lDado
                                Case "DATABASE"
                                    gEndP0044500 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044700]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044700 = lDado
                                Case "DATABASE"
                                    gEndP0044700 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P0044800]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP0044800 = lDado
                                Case "DATABASE"
                                    gEndP0044800 = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[P00MULTI]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipP00MULTI = lDado
                                Case "DATABASE"
                                    gEndP00MULTI = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[PROGRAMAS]"      'N�o utilizado.
                        Case "[REMESSA]"
                            Select Case lTipo
                                Case "ENDERECO"
                                    gEndRemessa = lDado
                            End Select
                        Case "[RETORNO]"
                        Case "[USO EM REDE]"
                        Case "[USO VERSAO DOS]"
                        Case "[USUARIO]"
                            Select Case lTipo
                                Case "TIPO"
                                    gTipUsuario = lDado
                                Case "NOME"
                                    gNomUsuario = lDado
                                Case Else
                                    lDesconhecido = True
                            End Select
                        Case "[SISCAD]"
                            gEndSiscad = lDado
                        Case "[ATUALIZACAO]"
                            gEndSYASUpDt = lDado
                            
                            If gfPreenchido(gEndSYASUpDt) Then
                                lTamanho = Len(gEndSYASUpDt)
                                If lTamanho = 5 Then
                                    gEndSYASUpDt = gAppPath
                                Else
                                    gEndSYASUpDt = Left$(gEndSYASUpDt, lTamanho - 5)
                                End If
                            End If
                        Case "[PROPRIETARIO TABELA]"
                            gPropTabela = lDado
                    End Select
                    If lDesconhecido = True Then
                        Call gpGraLog(2, "FTE0046 - Erro no arquivo de inicializa��o (tipo " & _
                                         "desconhecido para t�tulo " & lTitulo & ")." & vbLf & vbLf & _
                                         lRegSyasprodINI & vbLf & vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
            End Select
        End If
    Loop
    Close lNumSyasprodINI
                            
    '2.2 Verifica se o preenchimento da localiza��o das bases est�o iguais
    If gfPreenchido(gEndP0042100) Then
        lPathP0042100 = Mid(gEndP0042100, 1, (Len(gEndP0042100) - 12))
    End If
    If gfPreenchido(gEndP0042400) Then
        lPathP0042400 = Mid(gEndP0042400, 1, (Len(gEndP0042400) - 12))
    End If
    If gfPreenchido(gEndP0042900) Then
        lPathP0042900 = Mid(gEndP0042900, 1, (Len(gEndP0042900) - 12))
    End If
    
    If gfPreenchido(gImaL28V010A) = False Then
        gImaL28V010A = Replace(gImaL28V009A, "009A", "010A")
        gConL28V010A = Replace(gConL28V009A, "009A", "010A")
    End If
    
    If gfPreenchido(gImaL28V011A) = False Then
        gImaL28V011A = Replace(gImaL28V009A, "009A", "011A")
        gConL28V011A = Replace(gConL28V009A, "009A", "011A")
    End If
        
    If gfPreenchido(gImaL28V012A) = False Then
        gImaL28V012A = Replace(gImaL28V009A, "009A", "012A")
        gConL28V012A = Replace(gConL28V009A, "009A", "012A")
    End If
    
    If gfPreenchido(gImaL28V001B) = False Then
        gImaL28V001B = Replace(gImaL28V001A, "001A", "001B")
        gConL28V001B = Replace(gConL28V001A, "001A", "001B")
    End If
    
    If gfPreenchido(gImaL28V003B) = False Then
        gImaL28V003B = Replace(gImaL28V003A, "003A", "003B")
        gConL28V003B = Replace(gConL28V003A, "003A", "003B")
    End If
    
    If lPathP0042400 <> lPathP0042100 Or lPathP0042900 <> lPathP0042100 Then
        mfObtSYASPRODINI = False
        Exit Function
    Else
        mfObtSYASPRODINI = True
    End If
    
    '3. Posiciona endere�os de novas bases de dados - mesma pasta da base de dados P0043700.
    'a) P0044400 - tabela de indicadores de endosso.
    'b) P0044900 - tabela de coeficientes de CEP.
    'c) P0045000 - tabela de b�nus e fidelidade.
    'd) P0045100 - tabela de taxa m�nima.
    If gfPreenchido(gEndP0043700) Then
        lTamanho = Len(gEndP0043700)
        If lTamanho = 12 Then
            lEndereco = ""
        Else
            lEndereco = Left$(gEndP0043700, lTamanho - 12)
        End If
    Else
        lEndereco = gAppPath
    End If
    gEndP0044400 = lEndereco & "P0044400.MDB"
    gEndP0044600 = lEndereco & "P0044600.MDB"
    gEndP0044900 = lEndereco & "P0044900.MDB"
    gEndP0045000 = lEndereco & "P0045000.MDB"
    gEndP0045100 = lEndereco & "P0045100.MDB"
    gEndP0045200 = lEndereco & "P0045200.MDB"
    If Dir(gEndP0045200) = "" Then
        If Dir(gAppPath & "P0045200.MDB") <> "" Then
            On Error Resume Next
            FileCopy gAppPath & "P0045200.MDB", gEndP0045200
            On Error GoTo ControleErro
        End If
    End If
    gEndP0045300 = lEndereco & "P0045300.MDB"
    If Dir(gEndP0045300) = "" Then
        If Dir(gAppPath & "P0045300.MDB") <> "" Then
            On Error Resume Next
            FileCopy gAppPath & "P0045300.MDB", gEndP0045300
            On Error GoTo ControleErro
        End If
    End If
    
    gEndP0045400 = lEndereco & "P0045400.MDB"
    If Dir(gEndP0045400) = "" Then
        If Dir(gAppPath & "P0045400.MDB") <> "" Then
            On Error Resume Next
            FileCopy gAppPath & "P0045400.MDB", gEndP0045400
            On Error GoTo ControleErro
        End If
    End If
    
    gTipP0044400 = 1
    gTipP0044600 = 1
    gTipP0044900 = 1
    gTipP0045000 = 1
    gTipP0045100 = 1
    gTipP0045200 = 1
    gTipP0045300 = 1
    gTipP0045400 = 1
    
    If Len(gEndP0042100) = 12 Then
        gEndP0042100 = gAppPath & gEndP0042100
    End If
    If Len(gEndP0042200) = 12 Then
        gEndP0042200 = gAppPath & gEndP0042200
    End If
    If Len(gEndP0042300) = 12 Then
        gEndP0042300 = gAppPath & gEndP0042300
    End If
    If Len(gEndP0042400) = 12 Then
        gEndP0042400 = gAppPath & gEndP0042400
    End If
    If Len(gEndP0042500) = 12 Then
        gEndP0042500 = gAppPath & gEndP0042500
    End If
    If Len(gEndP0042600) = 12 Then
        gEndP0042600 = gAppPath & gEndP0042600
    End If
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    If Len(gEndP0042601) = 12 Then
        gEndP0042601 = gAppPath & gEndP0042601
    End If
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    If Len(gEndTAB_HIST_ROTEIRO_CALCULO) = 12 Then
        gEndP0042601 = gAppPath & gEndTAB_HIST_ROTEIRO_CALCULO
    End If
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    If Len(gEndP0042700) = 12 Then
        gEndP0042700 = gAppPath & gEndP0042700
    End If
    If Len(gEndP0042800) = 12 Then
        gEndP0042800 = gAppPath & gEndP0042800
    End If
    If Len(gEndP0042900) = 12 Then
        gEndP0042900 = gAppPath & gEndP0042900
    End If
    If Len(gEndP0043000) = 12 Then
        gEndP0043000 = gAppPath & gEndP0043000
    End If
    If Len(gEndP0043100) = 12 Then
        gEndP0043100 = gAppPath & gEndP0043100
    End If
    If Len(gEndP0043200) = 12 Then
        gEndP0043200 = gAppPath & gEndP0043200
    End If
    If Len(gEndP0043300) = 12 Then
        gEndP0043300 = gAppPath & gEndP0043300
    End If
    If Len(gEndP0043400) = 12 Then
        gEndP0043400 = gAppPath & gEndP0043400
    End If
    If Len(gEndP0043500) = 12 Then
        gEndP0043500 = gAppPath & gEndP0043500
    End If
    If Len(gEndP0043600) = 12 Then
        gEndP0043600 = gAppPath & gEndP0043600
    End If
    If Len(gEndP0043700) = 12 Then
        gEndP0043700 = gAppPath & gEndP0043700
    End If
    If Len(gEndP0043800) = 12 Then
        gEndP0043800 = gAppPath & gEndP0043800
    End If
    If Len(gEndP0043900) = 12 Then
        gEndP0043900 = gAppPath & gEndP0043900
    End If
    If Len(gEndP0044000) = 12 Then
        gEndP0044000 = gAppPath & gEndP0044000
    End If
    If Len(gEndP0044100) = 12 Then
        gEndP0044100 = gAppPath & gEndP0044100
    End If
    If Len(gEndP0044200) = 12 Then
        gEndP0044200 = gAppPath & gEndP0044200
    End If
    If Len(gEndP0044300) = 12 Then
        gEndP0044300 = gAppPath & gEndP0044300
    End If
    If Len(gEndP0044400) = 12 Then
        gEndP0044400 = gAppPath & gEndP0044400
    End If
    If Len(gEndP0044500) = 12 Then
        gEndP0044500 = gAppPath & gEndP0044500
    End If
    If Len(gEndP0044600) = 12 Then
        gEndP0044600 = gAppPath & gEndP0044600
    End If
    If Len(gEndP0044700) = 12 Then
        gEndP0044700 = gAppPath & gEndP0044700
    End If
    If Len(gEndP0044800) = 12 Then
        gEndP0044800 = gAppPath & gEndP0044800
    End If
    If Len(gEndP0044900) = 12 Then
        gEndP0044900 = gAppPath & gEndP0044900
    End If
    If Len(gEndP0045000) = 12 Then
        gEndP0045000 = gAppPath & gEndP0045000
    End If
    If Len(gEndP0045100) = 12 Then
        gEndP0045100 = gAppPath & gEndP0045100
    End If
    If Len(gEndP0045200) = 12 Then
        gEndP0045200 = gAppPath & gEndP0045200
    End If
    If Len(gEndP0045300) = 12 Then
        gEndP0045300 = gAppPath & gEndP0045300
    End If
    If Len(gEndP0045400) = 12 Then
        gEndP0045400 = gAppPath & gEndP0045400
    End If
    
    '4. Posiciona endere�o do servidor - mesma pasta da base de dados P0043700.
    If gfPreenchido(gEndP0043700) Then
        lTamanho = Len(gEndP0043700)
        If lTamanho = 12 Then
            gEndServidor = gAppPath
        Else
            gEndServidor = Left$(gEndP0043700, lTamanho - 12)
        End If
    End If
    
    '5. Finaliza a procedure para iniciar procedimento de atualiza��o do SYAS
    'com os arquivos SYASxxnn.003
    'Processo iniciado apenas se o modulo estiver sendo executado pelo programa
    'Yasuda.exe
    If gfPreenchido(gPrograma) Then
        If gPrograma = "YASUDA.EXE" Or gPrograma = "D028O002" Or gPrograma = "D028O003" Or gPrograma = "P28V300.EXE" Then
            'encerra a procedure para processar atualiza��es
            Exit Function
        End If
    End If
    '-----
    
    '6. Verifica bases de dados.
    'a) Posiciona quantidade de bases de dados.
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    'Inclus�o da base P0042601
    'lQuaBasDados = 30       '<<<<<<====== Verificar quantidade de bases de dados a verificar.
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    'Inclus�o da base TAB_HIST_ROTEIRO_CALCULO
    'lQuaBasDados = 31       '<<<<<<====== Verificar quantidade de bases de dados a verificar.
    lQuaBasDados = 32       '<<<<<<====== Verificar quantidade de bases de dados a verificar.
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    'b) Posiciona nomes, tipos e endere�os das bases de dados.
    ReDim lNomBasDados(lQuaBasDados)
    ReDim lEndBasDados(lQuaBasDados)
    ReDim lTipBasDados(lQuaBasDados)
    lNomBasDados(1) = "P0042100"
    lEndBasDados(1) = gEndP0042100
    lTipBasDados(1) = gTipP0042100
    lNomBasDados(2) = "P0042200"
    lEndBasDados(2) = gEndP0042200
    lTipBasDados(2) = gTipP0042200
    lNomBasDados(3) = "P0042300"
    lEndBasDados(3) = gEndP0042300
    lTipBasDados(3) = gTipP0042300
    lNomBasDados(4) = "P0042400"
    lEndBasDados(4) = gEndP0042400
    lTipBasDados(4) = gTipP0042400
    lNomBasDados(5) = "P0042500"
    lEndBasDados(5) = gEndP0042500
    lTipBasDados(5) = gTipP0042500
    lNomBasDados(6) = "P0042600"
    lEndBasDados(6) = gEndP0042600
    lTipBasDados(6) = gTipP0042600
    lNomBasDados(7) = "P0042700"
    lEndBasDados(7) = gEndP0042700
    lTipBasDados(7) = gTipP0042700
    lNomBasDados(8) = "P0042800"
    lEndBasDados(8) = gEndP0042800
    lTipBasDados(8) = gTipP0042800
    lNomBasDados(9) = "P0042900"
    lEndBasDados(9) = gEndP0042900
    lTipBasDados(9) = gTipP0042900
    lNomBasDados(10) = "P0043000"
    lEndBasDados(10) = gEndP0043000
    lTipBasDados(10) = gTipP0043000
    lNomBasDados(11) = "P0043100"
    lEndBasDados(11) = gEndP0043100
    lTipBasDados(11) = gTipP0043100
    lNomBasDados(12) = "P0043200"
    lEndBasDados(12) = gEndP0043200
    lTipBasDados(12) = gTipP0043200
    lNomBasDados(13) = "P0043300"
    lEndBasDados(13) = gEndP0043300
    lTipBasDados(13) = gTipP0043300
    lNomBasDados(14) = "P0043400"
    lEndBasDados(14) = gEndP0043400
    lTipBasDados(14) = gTipP0043400
    lNomBasDados(15) = "P0043500"
    lEndBasDados(15) = gEndP0043500
    lTipBasDados(15) = gTipP0043500
    lNomBasDados(16) = "P0043600"
    lEndBasDados(16) = gEndP0043600
    lTipBasDados(16) = gTipP0043600
    lNomBasDados(17) = "P0043700"
    lEndBasDados(17) = gEndP0043700
    lTipBasDados(17) = gTipP0043700
    lNomBasDados(18) = "P0043800"
    lEndBasDados(18) = gEndP0043800
    lTipBasDados(18) = gTipP0043800
    lNomBasDados(19) = "P0043900"
    lEndBasDados(19) = gEndP0043900
    lTipBasDados(19) = gTipP0043900
    'P0044000 - apenas para usu�rio Yasuda.
    lNomBasDados(20) = "P0044000"
    lEndBasDados(20) = gEndP0044000
    lTipBasDados(20) = gTipP0044000
    lNomBasDados(21) = "P0044100"
    lEndBasDados(21) = gEndP0044100
    lTipBasDados(21) = gTipP0044100
    lNomBasDados(22) = "P0044200"
    lEndBasDados(22) = gEndP0044200
    lTipBasDados(22) = gTipP0044200
    lNomBasDados(23) = "P0044300"
    lEndBasDados(23) = gEndP0044300
    lTipBasDados(23) = gTipP0044300
    lNomBasDados(24) = "P0044400"
    lEndBasDados(24) = gEndP0044400
    lTipBasDados(24) = gTipP0044400
    lNomBasDados(25) = "P0044500"
    lEndBasDados(25) = gEndP0044500
    lTipBasDados(25) = gTipP0044500
    'P0044600 - sem uso.
    lNomBasDados(26) = "P0044700"
    lEndBasDados(26) = gEndP0044700
    lTipBasDados(26) = gTipP0044700
    lNomBasDados(27) = "P0044800"
    lEndBasDados(27) = gEndP0044800
    lTipBasDados(27) = gTipP0044800
    lNomBasDados(28) = "P0044900"
    lEndBasDados(28) = gEndP0044900
    lTipBasDados(28) = gTipP0044900
    lNomBasDados(29) = "P0045000"
    lEndBasDados(29) = gEndP0045000
    lTipBasDados(29) = gTipP0045000
    lNomBasDados(30) = "P0045100"
    lEndBasDados(30) = gEndP0045100
    lTipBasDados(30) = gTipP0045100     'Observar vari�vel lQuaBasDados.
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    lEndBasDados(31) = gEndP0042601
    lTipBasDados(31) = gTipP0042601     'Observar vari�vel lQuaBasDados.
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    lEndBasDados(32) = gEndTAB_HIST_ROTEIRO_CALCULO
    lTipBasDados(32) = gTipTAB_HIST_ROTEIRO_CALCULO      'Observar vari�vel lQuaBasDados.
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    
    'b) Processa verifica��o.
    If gUsuarioMulti = False Then
        If gTipUsuario = "2" Then
            For li = 1 To lQuaBasDados
                Do
                    ''===1) A base de dados P0044000.MDB s� tem na Yasuda.
                    'If lNomBasDados(lI) = "P0044000" And gTipUsuario <> 1 Then
                    '    Exit Do
                    'End If
        
                    '===2) Verifica tipo da base de dados.
                    If Not gfPreenchido(lTipBasDados(li)) Then
                        Call gpGraLog(2, "FTE0067 - Erro ao verificar base de dados " & lNomBasDados(li) & _
                                         ": tipo da base de dados n�o preenchido." & vbLf & vbLf & _
                                         "O sistema ser� encerrado.")
                        
                        gFinalizarPrograma = True
                        Exit Function
                    End If
                    If lTipBasDados(li) <> "1" Then
                        Call gpGraLog(2, "FTE0067 - Erro ao verificar base de dados " & lNomBasDados(li) & _
                                         ": tipo da base de dados diferente de 1 - " & lTipBasDados(li) & "." & _
                                         vbLf & vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
        
                    '===3) Verifica endere�o do arquivo.
                    If gfPreenchido(lEndBasDados(li)) Then
                        lEndereco = lEndBasDados(li)
                        If Len(lEndBasDados(li)) = 12 Then
                            lEndereco = gAppPath & lEndBasDados(li)
                        End If
                    Else
                        lEndereco = gAppPath & lNomBasDados(li) & ".MDB"
                    End If
                    
                    If UCase(lNomBasDados(li)) = "P0044000" And gTipUsuario = 1 Then
                        Exit Do
                    End If
                    If gfPreenchido(gPropTabela) = True Then
                        Select Case UCase(lNomBasDados(li))
                            'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                            'Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042600", "P0042700", "P0042800"
                            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                            'Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042600", "P0042601", "P0042700", "P0042800"
                            Case "P0042100", "P0042200", "P0042300", "P0042400", "P0042600", "P0042601", "P0042700", "P0042800", "HIROTCAL"
                            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                            'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                            Exit Do
                        End Select
                    End If
                    If Not gfPreenchido(Dir(lEndereco)) Then
                        Call gpGraLog(2, "FTE0067 - Erro ao verificar base de dados " & lNomBasDados(li) & _
                                         ": base de dados n�o localizada." & vbLf & vbLf & lEndereco & vbLf & _
                                         vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
                    lPosicao = InStr(lEndereco, lNomBasDados(li) & ".MDB")
                    If lPosicao = 0 Then
                        Call gpGraLog(2, "FTE0067 - Erro ao verificar base de dados " & lNomBasDados(li) & _
                                         ": nome da base de dados n�o consta no endere�o." & vbLf & vbLf & _
                                         lEndereco & vbLf & vbLf & "O sistema ser� encerrado.")
                        gFinalizarPrograma = True
                        Exit Function
                    End If
                    Exit Do
                Loop
            Next li
        End If
    End If
    '7. Verifica arquivos de impress�o.
    'a) Posiciona quantidade de arquivos de impress�o.
    lQuaImpressao = 11      '<<<<<<====== Verificar quantidade de arquivos de impress�o a verificar.
    'b) Posiciona nomes e endere�os dos arquivos de impress�o.
    ReDim lNomImpressao(lQuaImpressao)
    ReDim lConImpressao(lQuaImpressao)
    ReDim lImaImpressao(lQuaImpressao)
    lNomImpressao(1) = "L28V001A"
    lConImpressao(1) = gConL28V001A
    lImaImpressao(1) = gImaL28V001A
    lNomImpressao(2) = "L28V002A"
    lConImpressao(2) = gConL28V002A
    lImaImpressao(2) = gImaL28V002A
    lNomImpressao(3) = "L28V002B"
    lConImpressao(3) = gConL28V002B
    lImaImpressao(3) = gImaL28V002B
    lNomImpressao(4) = "L28V003A"
    lConImpressao(4) = gConL28V003A
    lImaImpressao(4) = gImaL28V003A
    lNomImpressao(5) = "L28V004A"
    lConImpressao(5) = gConL28V004A
    lImaImpressao(5) = gImaL28V004A
    lNomImpressao(6) = "L28V005A"
    lConImpressao(6) = gConL28V005A
    lImaImpressao(6) = gImaL28V005A
    lNomImpressao(7) = "L28V005B"
    lConImpressao(7) = gConL28V005B
    lImaImpressao(7) = gImaL28V005B
    lNomImpressao(8) = "L28V006A"
    lConImpressao(8) = gConL28V006A
    lImaImpressao(8) = gImaL28V006A
    lNomImpressao(9) = "L28V007A"
    lConImpressao(9) = gConL28V007A
    lImaImpressao(9) = gImaL28V007A
    lNomImpressao(10) = "L28V008A"
    lConImpressao(10) = gConL28V008A
    lImaImpressao(10) = gImaL28V008A
    lNomImpressao(11) = "L28V009A"
    lConImpressao(11) = gConL28V009A
    lImaImpressao(11) = gImaL28V009A        'Observar vari�vel lQuaImpressao.
    'b) Processa verifica��o.
    If gUsuarioMulti = False Then
        If gTipUsuario = "2" Then
            For li = 1 To lQuaImpressao
                '===1) Verifica endereco do arquivo de configura��o da impress�o.
                If gfPreenchido(lConImpressao(li)) Then
                    lEndereco = lConImpressao(li)
                    If Len(lConImpressao(li)) = 12 Then
                        lEndereco = gAppPath & lConImpressao(li)
                    End If
                Else
                    lEndereco = gAppPath & lNomImpressao(li) & ".CXY"
                End If
                If Not gfPreenchido(Dir(lEndereco)) Then
                    Call gpGraLog(1, "FTE0025 - Arquivo n�o localizado: " & lEndereco & _
                                     " (obter dados de inicializa��o do sistema).")
                    'Desabilitado encerramento do sistema devido motivo n�o justific�vel.
                    'End
                End If
        
                '===2) Verifica endere�o do arquivo de imagem da impress�o.
                If gfPreenchido(lImaImpressao(li)) Then
                    lEndereco = lImaImpressao(li)
                    If Len(lImaImpressao(li)) = 12 Then
                        lEndereco = gAppPath & lImaImpressao(li)
                    End If
                Else
                    lEndereco = gAppPath & lNomImpressao(li) & ".WMF"
                End If
                If Not gfPreenchido(Dir(lEndereco)) Then
                    Call gpGraLog(1, "FTE0025 - Arquivo n�o localizado: " & lEndereco & _
                                     " (obter dados de inicializa��o do sistema).")
                    'Desabilitado encerramento do sistema devido motivo n�o justific�vel.
                    'End
                End If
            Next li
        End If
    End If
    '8. Verifica pasta remessa.
    If Not gfPreenchido(gEndRemessa) Then
        gEndRemessa = gAppPath & "REMESSA"
    End If
    If Right$(gEndRemessa, 1) = "\" Then
        gEndRemessa = Left$(gEndRemessa, Len(gEndRemessa) - 1)
    End If
    
    On Error Resume Next
    Err.Clear
    If Not gfPreenchido(Dir(gEndRemessa, vbDirectory)) Then
        If Err.Number <> 0 Then
            If Err.Number = 52 Then
                Call gpGraLog(1, "Verifique o diret�rio " & gEndRemessa & ".Caminho desconhecido ou sem acesso")
'                End
            End If
        End If
        On Error Resume Next
        MkDir (gEndRemessa)
        If Err <> 0 Then
            Call gpGraLog(0, "FTE0033 - Erro ao criar pasta " & gEndRemessa & _
                             " (pasta de remessa obter dados de inicializa��o do sistema).")
            'Desabilitado encerramento do sistema devido motivo n�o justific�vel.
            'End
        End If
    End If
    gEndRemessa = gEndRemessa & "\"
    Exit Function
ControleErro:
    Call gpGraLog(0, Err.Description)
End Function
Public Function gfAbrBasSQL(ByVal pIdeBasDados As String, ByVal pTipBasDados As String, _
                             ByVal pSerBasDados As String, ByVal pEndBasDados As String, _
                             ByVal pUIDBasDados As String, ByVal pPWDBasDados As String, _
                             ByRef pADOBasDados As ADODB.Connection, ByRef pMensagem As String) _
                             As Boolean
    'Fun��o: abre base de dados.

    'Par�metros de entrada...pIdeBasDados...Identificador da base de dados.
    '                        pTipBasDados...Tipo da base de dados.
    '                        pEndBasDados...Endere�o da base de dados.
    'Par�metros de sa�da.....pADOBasDados...Base de dados.
    '                        pMensagem......Mensagem.

    Dim lFlag           As Boolean  'Variavel l�gica, indica se o procedimento utilizar� ou n�o a ultima conex�o aberta
                                    ' TRUE = Abre nova conex�o ; FALSE = Mantem a ultima conex�o aberta
    Dim lFlag2          As Boolean  'VAriavel l�gica auxiliar
                                    'Utilizada para verificar da solicita��o de abertura de Base
                                    'Caso a verifica��o encontre divergencias.
                                    'TRUE = encontrado divergencia ; FALSE = N�o encontrado Divergencia Continua a verifica��o
    Dim lInd            As Integer  'Contador.
    Dim lInd2           As Integer  'Contador auxiliar
    Dim lIndMax         As Integer  'Maior �ndice.
    Dim lInfoConexao()  As String   'informa��o sobre a conex�o.
    Dim lSubInfoCn()    As String   'Recebe itens da variavel lInfoConexao
    Dim lIniCatalog     As String   'Par�metro INITIAL CATALOG.
    Dim lMensagem       As String   'Mensagem de log.
    Dim lOpen           As String   'Linha para comando OPEN.
    Dim lDriver         As String

    If gGraLog = "2" Then
        Call gpGraLog(0, "AGE0000 - gfAbrBasSQL : pSerBasDados=" & pSerBasDados & " pEndBasDados=" & pEndBasDados & _
                         " pUIDBasDados=" & pUIDBasDados & " pPWDBasDados=" & pPWDBasDados)
    End If
    
    '1. Verifica se a conex�o foi a ultima a ser aberta
    Set mConexaoSQL = Nothing
    If mConexaoSQL Is Nothing Then
        'mConexaoSQL = Nothing
        'Atribui true para a variavel lFlag
        'Para abrir nova conex�o
        lFlag = True
    Else
        'separa as informa��es da ultima conex�o aberta em uma variavel matriz
        lInfoConexao = Split(UCase(mConexaoSQL), ";")
        
        If gGraLog = "2" Then
            lInd = 0
            lMensagem = ""
            lIndMax = UBound(lInfoConexao())
            Do Until lInd = lIndMax + 1
                lMensagem = lMensagem & "Ind(" & lInd & ")=" & lInfoConexao(lInd) & " "
                lInd = lInd + 1
            Loop
            Call gpGraLog(0, "AGE0000 - gfAbrBasSQL : lInfoConexao - " & lMensagem)
        End If
        
        'Inicia a variavel para abrir nova conex�o
        lFlag = True
        
        'Inicia a variavel para prosseguir com a verifica��o
        lFlag2 = False
        
        For lInd = LBound(lInfoConexao()) To UBound(lInfoConexao())
            
            If UBound(lInfoConexao()) < 0 Then
                'Se a String estiver vazia
                'encerra a verifica��o, e o procedimento abrir� nova conex�o
                Exit For
            End If
                        
            lSubInfoCn = Split(lInfoConexao(lInd), "=")
                
            For lInd2 = LBound(lSubInfoCn()) To 0
                
                If UBound(lSubInfoCn()) < 0 Then
                    Exit For
                End If
                
                Select Case lSubInfoCn(lInd2)
                    Case "SERVER"
                        If lInfoConexao(lInd) = "SERVER=" & UCase(pSerBasDados) Then
                           'servidores de base de dados s�o iguais
                           'Atribui false para a Variavel lFlag.
                           'Para manter a ultima conex�o aberta
                           lFlag = False
                        Else
                            'Encontrado Divergencia
                            'Atribui TRUE para a Variavel lFlag2
                            'Para encerrar a verifica��o
                            lFlag2 = True
                            'Atribui TRUE para abrir nova conex�o
                            lFlag = True
                        End If
                    Case "UID"
                        If lInfoConexao(lInd) = "UID=" & UCase(pUIDBasDados) Then
                            'Usuarios s�o iguais
                            lFlag = False
                        Else
                            lFlag2 = True
                            lFlag = True
                        End If
                    Case "PWD"
                        If lInfoConexao(lInd) = "PWD=" & UCase(pPWDBasDados) Then
                            'Senhas de acesso ao Banco s�o iguias
                            lFlag = False
                        Else
                            lFlag2 = True
                            lFlag = True
                        End If
                    Case "DATABASE"
                        If Replace(lInfoConexao(lInd), """", "") = "DATABASE=" & UCase(pEndBasDados) Then
                            'Bancos de Dados s�o iguais
                            lFlag = False
                        Else
                            lFlag2 = True
                            lFlag = True
                        End If
                End Select
                
            Next lInd2
            
            If lFlag2 = True Then
                'Encontrado divergencia
                'lFlag � igual a TRUE, o procedimento abrir� nova conex�o
                'Encerra a verifica��o
                Exit For
            End If
                            
        Next lInd
        
    End If

    gfAbrBasSQL = False

    If lFlag = True Then
        '2. Verifica identifica��o da base de dados.
        If Not gfPreenchido(pIdeBasDados) Then
            pMensagem = "FTE0001 - Erro ao abrir base de dados (identifica��o da base de dados n�o " & _
                        "preenchida)."
            Exit Function
        End If
        Select Case UCase$(pIdeBasDados)
            Case "P0044700", "P0044800", "CORRETORES", "P0042100", "P0042200", "P0042300", _
                 "P0042400", "P0042500", "P0042600", "P0042700", "P0042800", "P0042900", _
                 "P0043000", "P0043100", "P0043200", "P0043300", "P0043400", "P0043500", _
                 "P0043600", "P0043700", "P0043800", "P0043900", "P0044000", "P0044100", _
                 "P0044200", "P0044300", "P0044500", "EAPDB", "DBSYASEMIS", "GED", _
                 "SYAS_EMIS", "YASUDANET", "SYASPROD"
                'Nada a fazer - bases de dados v�lidas.
            Case Else
                pMensagem = "FTE0001 - Erro ao abrir base de dados (identifica��o da base de dados " & _
                            "desconhecida: " & pIdeBasDados & ")."
                Exit Function
        End Select

        '3. Verifica tipo da base de dados.
        If Not gfPreenchido(pTipBasDados) Then
            pMensagem = "FTE0001 - Erro ao abrir base de dados (tipo da base de dados " & pIdeBasDados & _
                        " n�o preenchido)."
            Exit Function
        End If
        If pTipBasDados <> "2" Then
            pMensagem = "FTE0001 - Erro ao abrir base de dados (tipo da base de dados " & pIdeBasDados & _
                        " desconhecido: " & pTipBasDados & ")."
            Exit Function
        End If

        '4. Verifica endere�o da base de dados.
        If Not gfPreenchido(pEndBasDados) Then
            pMensagem = "FTE0001 - Erro ao abrir base de dados (endere�o da base de dados " & pEndBasDados & _
                        " n�o preenchido)."
            Exit Function
        End If

        '5. Abre base de dados.
        'a) Posiciona conex�o.
        On Error Resume Next
        Set mConexaoSQL = Nothing
        Set mConexaoSQL = New ADODB.Connection
        If Err <> 0 Then
            pMensagem = "FTE0001 - Erro na base de dados (" & pIdeBasDados & _
                        " - comando SET New ADODB.Connection - erro " & Err & " - " & Error & ")."
            On Error GoTo 0
            Exit Function
        End If
        
        Select Case LCase(pSerBasDados)
            Case "192.168.1.81", "SPX21181PSLUSQL"
                lDriver = "{SQL Server Native Client 10.0}"
            Case Else
                lDriver = "{SQL Server}"
        End Select
        mConexaoSQL.ConnectionString = "driver=" & lDriver & _
                                       ";server=" & pSerBasDados & _
                                       ";uid=" & LCase(pUIDBasDados) & _
                                       ";pwd=" & LCase(pPWDBasDados) & _
                                       ";database=" & pEndBasDados

        mConexaoSQL.ConnectionTimeout = 900
        mConexaoSQL.CommandTimeout = 900
        'b) Posiciona propriedade CursorLocation.
        'pADOBasDados.CursorLocation = adUseClient
        If Err <> 0 Then
            pMensagem = "FTE0001 - Erro na base de dados (" & pIdeBasDados & _
                        " - Comando CursorLocation = adUseClient - erro: " & Err & " - " & Error & ")."
            On Error GoTo 0
            Exit Function
        End If
        If gGraLog = "2" Then
            Call gpGraLog(0, "AGE0000 - gfAbrBasSQL : ConnectionString=" & mConexaoSQL.ConnectionString)
        End If
        'c) Abre base de dados.
        mConexaoSQL.Open
        If Err <> 0 Then
            pMensagem = "FTE0001 - Erro na base de dados (" & pIdeBasDados & _
                        " - comando Open " & lOpen & " - erro: " & Err & " - " & Error & ")."
            On Error GoTo 0
            Exit Function
        End If
        On Error GoTo 0
    End If
    Set pADOBasDados = mConexaoSQL

    gfAbrBasSQL = True
End Function

Public Function mfFormatarCamposSQL(pAtributo As Variant) As String
    'Fun��o: Formata o campo de entrada para o padr�o SQL
    
    Select Case VarType(pAtributo)
        Case vbEmpty, vbNull:
            mfFormatarCamposSQL = "Null"
        Case vbInteger, vbLong, vbSingle, vbDouble, vbCurrency, vbDecimal, vbByte:
            mfFormatarCamposSQL = Trim(Str(pAtributo))
        Case vbString:
            If gfPreenchido(pAtributo) = False Then
                mfFormatarCamposSQL = "' '"
            Else
                mfFormatarCamposSQL = "'" & UCase(gpRetirarCaracterEspecial(CStr(pAtributo))) & "'"
            End If
        Case vbDate:
            If Val(pAtributo) = 0 Then
                mfFormatarCamposSQL = "Null"
            Else
                mfFormatarCamposSQL = "'" & Format(pAtributo, "mm-dd-yyyy") & " " & Format(pAtributo, "hh:mm:ss") & "'"
            End If
        Case vbBoolean:
            mfFormatarCamposSQL = IIf(pAtributo = True, "1", "0")
    End Select

End Function

Public Function mfWhereAnd(pSql As String) As String
    'Fun��o: Verifica se o texto de entrada j� possui a palavra Where, se tiver retorna
    '       AND se n�o retorna WHERE. Fun��o utilizada na montagem de consultas SQL.
    
    If InStr(1, UCase(pSql), "WHERE") = 0 Then
        mfWhereAnd = pSql & " WHERE "
    Else
        mfWhereAnd = pSql & " AND "
    End If
End Function

Public Function gfTratarNulo(pAtributo As Variant, pTipodeDado As TipoDados, Optional pValorRetornar As String) As Variant
    'Fun��o: Trata o atributo se ele estiver nulo.
    
    If IsNull(pAtributo) Then
        If pValorRetornar <> "" Then
            gfTratarNulo = pValorRetornar
        Else
            Select Case pTipodeDado
                Case TpoBoolean
                    gfTratarNulo = 0
                Case TpoData
                    gfTratarNulo = "00:00:00"
                Case TpoNumerico
                    gfTratarNulo = 0
                Case TpoHora
                    gfTratarNulo = "00:00"
                Case TpoString
                    gfTratarNulo = " "
                Case TpoValor
                    gfTratarNulo = 0
            End Select
        End If
    Else
        gfTratarNulo = Trim(pAtributo)
    End If
    
End Function
Public Sub gpTransferirArquivoSQLComm(pArquivoUpdate As String, ByRef pMensagem As String)

Dim lBDConexao      As ADODB.Connection     'Arquivo conex�o.
Dim lCount          As Integer              'Contador.
Dim lDiretorio      As String               'Diret�rio.
Dim lExisteArq      As Boolean              'Existe arquivo?
Dim lNomeArq        As String               'Nome do arquivo.
Dim lNumArq         As Integer              'N�mero do arquivo.
Dim lNumProcess     As Long                 'N�mero do processo.
Dim lRst            As ADODB.Recordset      'Registro.
Dim lSql            As String               'Select
Dim lDados          As Variant              'Dados.
    
    If UCase(gSerSYASEMIS) Like "*MIX*" Then
        Exit Sub
    End If
            
    If Dir("\\spx20103psluapl\export$\Connect\Dados\connect.mdb") = "" Then
        pMensagem = "Verifique seu acesso ao diret�rio \\spx20103psluapl\export$\Connect. " & _
                    "N�o � poss�vel salvar o arquivo."
        Exit Sub
    End If
    lDiretorio = "\\spx20103psluapl\export$\Connect"
    lCount = 0
    lExisteArq = False
    
    If gfAbrBasDadosAccess("CONNECT", "1", "\\spx20103psluapl\export$\Connect\Dados\connect.mdb", lBDConexao, pMensagem) = False Then
        Call gpGraLog(1, pMensagem)
        Exit Sub
    End If
    
    
    lSql = " select * from  Tab_ctrl_transf  where nom_arq_micro like 'SQLCOMM.%'"
    lSql = lSql & " order by dat_hor_trfile  desc"
        
    If Not gfObtRegistro(lBDConexao, lSql, lRst, pMensagem) Then Exit Sub
    
    If lRst.EOF Then
        lNomeArq = "SQLCOMM.001"
    Else
        lCount = Right(lRst("Nom_Arq_Micro"), 3)
        If lCount = 999 Then lCount = 0
        lNomeArq = "SQLCOMM." & Format(lCount + 1, "000")
    End If
        
    lDiretorio = lDiretorio & "\" & lNomeArq
    
    Call FileCopy(pArquivoUpdate, lDiretorio)
    
    lNumProcess = 0
    
    lSql = "select * from Tab_num_process"
    
    If gfObtRegistro(lBDConexao, lSql, lRst, pMensagem) = False Then
        Call lBDConexao.Close
        Exit Sub
    End If
    
    If lRst.EOF Then
       Call gpGraLog(1, "FTE0010 - N�mero do Processo n�o localizado, contactar DESIS.")
       Call gpFecha1(lRst)
       lBDConexao.Close
        GoTo ContinuaTranfer
    End If
    
    lNumProcess = lRst("num_process")
    lNumProcess = lNumProcess + 1
    
    If lNumProcess > 90000 Then
       lNumProcess = 1
    End If
    
    lSql = "Update Tab_num_process set num_Process = " & lNumProcess
    
    If gfExeSQL(lBDConexao, lSql, pMensagem) <> 0 Then
        Exit Sub
    End If
        
ContinuaTranfer:
    
    lSql = "insert into Tab_ctrl_transf values ("
    lSql = lSql & "'PCE" & Format(lNumProcess, "00000") & "',"  'nom_process
    lSql = lSql & "'YASNET',"                                   'nom_user
    lSql = lSql & "'" & Trim(lNomeArq) & "',"                   'nom_arq_micro
    lSql = lSql & "'TXT',"                                      'tip_dado
    lSql = lSql & FileLen(lDiretorio) & ","                     'tam_reg_msp
    lSql = lSql & "'',"                                         'tip_compress
    lSql = lSql & "'',"                                         'status_arq_transf
    lSql = lSql & 0 & ","                                       'num_process
    lSql = lSql & "'',"                                         'cod_msg
    lSql = lSql & 0 & ",'"                                      'tam_ru
    lSql = lSql & UCase(lNomeArq) & "',"                        'nom_arq_nt
    lSql = lSql & "1,"                                          'qtd_reg_nt
    lSql = lSql & 0 & ","                                       'vtam_bytes_nt
    lSql = lSql & 0 & ","                                       'io_bytes_nt
    lSql = lSql & "'CDMSPP',"                                   'nom_no
    lSql = lSql & "'',"                                         'nom_arq_msp
    lSql = lSql & "1,"                                          'qtd_reg_msp
    lSql = lSql & 0 & ","                                       'vtam_bytes_msp
    lSql = lSql & 0 & ","                                       'io_bytes_msp
    lSql = lSql & "'',"                                         'vol_ser_msp
    lSql = lSql & 0 & ","                                       'cod_status
    lSql = lSql & "'" & Format(Now, "DD/MM/YYYY HH:MM:SS") & "',"     'dat_hor_trfile
    lSql = lSql & "'',"                                         'dat_hor_transfer
    lSql = lSql & "'')"                                         'dat_hor_estatist
    
    If gfExeSQL(lBDConexao, lSql, pMensagem) <> 0 Then
        Exit Sub
    End If
        
    Kill pArquivoUpdate

End Sub

Public Function gfForCNPJ(ByVal pCNPJ As String, ByVal pTamanho As Integer) As String
    'Formata CNPJ para posicionamento em arquivo de transmissao.
    'CNPJ numerico: alinha a direita com zeros a esquerda.
    'CNPJ alfanumerico: retorna os primeiros pTamanho caracteres, completando com espacos.
    pCNPJ = Trim$(pCNPJ)
    If Len(pCNPJ) = 0 Then
        gfForCNPJ = String(pTamanho, "0")
    ElseIf IsNumeric(pCNPJ) Then
        gfForCNPJ = Right$(String(pTamanho, "0") & pCNPJ, pTamanho)
    Else
        If Len(pCNPJ) >= pTamanho Then
            gfForCNPJ = Left$(pCNPJ, pTamanho)
        Else
            gfForCNPJ = pCNPJ & Space(pTamanho - Len(pCNPJ))
        End If
    End If
End Function
