Attribute VB_Name = "BasM28V300"
Option Explicit
' ======================================================================================================================================================
' Module Name: BasM28V300
' Data de Cria��o: 18/12/2009
' Compartilhado entre os Sistemas:
' P28V300 ; P24V007
' Analista: MOSilva
'
' *** IMPORTANTE:
'   ESTE MODULO NAO PODE EMITIR MENSAGEM EM HIPOTESE ALGUMA
'   RODA EM SERVIDORES COMO SERVI�O DO WINDOWS.
'   TODAS AS ROTINAS (PROCS E FUNCS) DEVEM TER TRATAMENTO DE ERRO, SEM INTERROMPER O PROCESSAMENTO , GRAVANDO LOG SEM EMITIR MENSAGEM
' ======================================================================================================================================================
'Private mAntNosNumero       As String           'Registro anterior P0042100: nosso n�mero.
'Public gNomArqEnvio        As String           'Nome do arquivo de envio.
'Public gEndCopEntrada      As String           'Endere�o da c�pia do arquivo de entrada.
'Public gEndArqRetorno      As String           'Endere�o do arquivo de retorno.
'Public gNumArqRetorno      As Integer          'Utilizado com FreeFile para arquivo de retorno.
'Public gNumCopEntrada      As Integer          'Utilizado com FreeFile para a c�pia do arquivo de entrada.
'Public gQuaPropostas       As Integer          'Quantidade de propostas a serem processadas.
'Public gDatHorEnvio        As String           'Data e hora do arquivo de envio.
'Public gDatHorRetorno      As String           'Data e hora do arquivo de retorno.
'Public gstcProposta        As stcA28V300
'Private mColProposta        As Collection

'Private mRegAnoFabricacao   As String           'Registro: ano de fabrica��o.
'Private mRegAnoModelo       As String           'Registro: ano de modelo.
'Private mRegCodChassi       As String           'Registro: c�digo do chassi.
'Private mRegCodChaEstrang   As String           'Registro: c�digo do chassi estrangeiro.
'Private mRegCodPlaca        As String           'Registro: c�digo da placa.
'Private mRegCodVeiculo      As String           'Registro: c�digo do ve�culo.
'Private mRegDatVigInicio    As String           'Registro: data de vig�ncia - in�cio.
'Private mRegDatVigTermino   As String           'Registro: data de vig�ncia - t�rmino.
'Private mRegNomSegurado     As String           'Registro: nome do segurado.
'Private mRegNomVeiculo      As String           'Registro: nome do ve�culo.
'Private mRegNumItem         As String           'Registro: n�mero do item.
'Public gRegNumReferencia   As String           'Registro: n�mero de refer�ncia.
'Private mRegTipEmissao      As String           'Registro: tipo de emiss�o.

Public gOwner              As String
Public gIdeBasEAPDB         As String
Public gTipBasEAPDB         As String
Public gSerBasEAPDB         As String
Public gEndBasEAPDB         As String
Public gUIDBasEAPDB         As String
Public gPWDBasEAPDB         As String

Public gIdeBasSyasEmis      As String
Public gTipBasSyasEmis      As String
Public gSerBasSyasEmis      As String
Public gEndBasSyasEmis      As String
Public gUIDBasSyasEmis      As String
Public gPWDBasSyasEmis      As String

Public gPropTabelaSyasEdi   As String
Public gPropTabelaCorporativo As String
Public gPropTabelaSyasPortal As String


Public gInsert              As String

'C�digos de cobertura e descontos utilizados.
Public Const gCobCasco = 1          '01 = Cobertura de casco.
Public Const gCobRCDM = 3           '03 = Cobertura de RCDM.
Public Const gCobRCDC = 4           '04 = Cobertura de RCDC.
Public Const gCobRCMO = 5           '05 = Cobertura de RCMO.
Public Const gCobAPPMorte = 6       '06 = Cobertura de APP-Morte.
Public Const gCobAPPInvalidez = 7   '07 = Cobertura de APP-Invalidez.
Public Const gCobAPPDMH = 8         '08 = Cobertura de APP-DMH.
Public Const gCob0km = 9            '09 = Cobertura de ve�culo 0 km.
Public Const gCobAss24hs = 10       '10 = Cobertura de assist�ncia 24 horas.
Public Const gCobCarReserva = 11    '11 = Cobertura de carro reserva.
Public Const gCobDesExtr = 12       '12 = Cobertura de despesas extraordin�rias.
Public Const gCobVidros = 13        '13 = Cobertura de vidros.
Public Const gCobClauSocDir = 14    '14 = C�digo de cobertura de cl�usula s�cio-dirigente.

Public Const gDesCasco = 1          '01 = Desconto de casco.
Public Const gDesBonus = 2          '02 = Desconto de b�nus.
Public Const gDesFidelidade = 3     '03 = Desconto de fidelidade.
Public Const gDesFrota = 4          '04 = Desconto de frota.
Public Const gDesRC = 9             '09 = Desconto de RC.
Public Const gDesPerfil = 10        '10 = Desconto de perfil.
Public Const gDesAPP = 11           '11 = Desconto de APP.

Public gEndSyasEdi          As String   'Endere�o do programa SYAS-EDI Server (P24V007.exe)

Public Sub gpCarregaTransmissao(ByVal pAprf As String, _
                                ByRef pCN As ADODB.Connection, _
                                Optional pFileName As String = "")
Dim lBusca          As String   'Busca do arquivo de entrada.
Dim lFileSize       As Double   'Tamanho em bytes do arquivo de entrada
Dim lDir            As String   'Resultado da fun��o DIR.
Dim lEndArqEntrada  As String   'Endere�o do arquivo de entrada.
Dim lEndCopRetorno  As String   'Endere�o da c�pia do arquivo de retorno.
Dim lMensagem       As String   'Mensagem.
Dim lPoint          As String
Dim lExtProtocolo   As String   'Exten��o/APRF do protocolo da transmissao
Dim lExtArqPrcsd    As String   'Exten��o/APRF do arquivo processado (Backup do arquivo recebido)
Dim lNomArqLocal    As String   'Nome do arquino copiado p/ o processamento (no App.Path)
Dim lDatHorRetorno  As String
'Variaveis abaixo estavam declaradas como globais.
'Foi alterado pois o programa P24V007 tem processamento simultaneo de multiplos usuarios, que compartilhavam as mesmas variaveis.
'Causando perda de informacoes.
Dim lNomArqEnvio    As String           ' antigo gNomArqEnvio
Dim lEndCopEntrada  As String           ' antigo gEndCopEntrada
Dim lNumCopEntrada  As Integer          ' antigo gNumCopEntrada
Dim lEndArqRetorno  As String           ' antigo gEndArqRetorno
Dim lNumArqRetorno  As Integer          ' antigo gNumArqRetorno
'================================================================================================
    
    'Busca os arquivos da pasta X:\mailboxes\YASUDA para o App.Path
    On Error GoTo ControleErro
    
Busca_Transmissao:
    lPoint = "1"
    gOwner = "" & gPropTabelaCorporativo & "ftp_"
    
    Select Case pAprf
        Case "010"      'Transmissao acionada pelo corretor (processado pelo programa P24V007)
            lExtArqPrcsd = "P10"
            lExtProtocolo = "011"
            lBusca = gEndPastas & "YASUDA\temp\" & pFileName
            lEndArqEntrada = gEndPastas & "YASUDA\temp\"
        Case "P10"      'Transmissao acionada pelo corretor (J� verificada e enviado protocolo. Apensa carga no SQL)
            lExtArqPrcsd = "Y10"
            lExtProtocolo = ""
            lBusca = gEndPastas & "YASUDA\*." & pAprf
            lEndArqEntrada = gEndPastas & "YASUDA\"
        Case "090"      'Calculo de proposta enviado pelo SYAS (Sem a��o voluntaria do corretor)
            lExtArqPrcsd = "Y90"
            lExtProtocolo = ""
            lBusca = gEndPastas & "YASUDA\*." & pAprf
            lEndArqEntrada = gEndPastas & "YASUDA\"
        Case "014"
            lExtArqPrcsd = "Y14"
            lExtProtocolo = ""
            lBusca = gEndPastas & "YASUDA\*." & pAprf
            lEndArqEntrada = gEndPastas & "YASUDA\"
    End Select
    
    lPoint = "2"
    lDir = Dir(lBusca)
    If gfPreenchido(lDir) = True Then
        Select Case pAprf
            Case "010"      'Transmissao acionada pelo corretor (processado pelo programa P24V007)
                lNomArqLocal = pFileName
                FileCopy lEndArqEntrada & lDir, gAppPath & lNomArqLocal
                lNomArqLocal = Left(lDir, (InStr(1, lDir, ".") - 1)) & ".P10"
                Name lEndArqEntrada & lDir As lEndArqEntrada & lNomArqLocal
                lNomArqLocal = pFileName
            Case Else
                lNomArqLocal = Left(lDir, (InStr(1, lDir, ".") - 1)) & "." & pAprf
                FileCopy lEndArqEntrada & lDir, gAppPath & lNomArqLocal
                Kill lEndArqEntrada & lDir
        End Select
    End If

    '4- Processa arquivo de entrada
    lPoint = "3"
        Select Case pAprf
            Case "010"      'Transmissao acionada pelo corretor (processado pelo programa P24V007)
                lBusca = gAppPath & lNomArqLocal
            Case Else
                lBusca = gAppPath & "*." & pAprf
        End Select
        
    '5. Obt�m arquivo de entrada.
    lDir = Dir(lBusca)
    If Not gfPreenchido(lDir) Then
        If gfPreenchido(lExtProtocolo) = True Then
        '** N�o envia protocolo para pAprf = "090" e "P10"
            lBusca = gAppPath & "Remessa\*." & lExtProtocolo
            lDir = Dir(lBusca)
            Do While gfPreenchido(lDir) = True
                If mfEnviaProtocolo(Left(lDir, 6), lDir, lMensagem) = False Then
                    Call gpGraLog(0, "P28V300 - ERRO ao enviar protocolo" & lMensagem)
                    Shell "net send tjgomes " & App.EXEName & " - ERRO ao enviar protocolo" & lMensagem
                    Shell "net send mosilva " & App.EXEName & " - ERRO ao enviar protocolo" & lMensagem
                End If
                lDir = Dir(lBusca)
            Loop
        End If
        Exit Sub
    End If
    lPoint = "4"
    Select Case pAprf
        Case "010"      'Transmissao acionada pelo corretor (processado pelo programa P24V007)
            'N�o grava na Base SyasEmiss
            DoEvents
        Case Else
            If mfAbrBasSQL(gEndBasSyasEmis, gTipBasSyasEmis, gSerBasSyasEmis, gEndBasSyasEmis, gUIDBasSyasEmis, _
               gPWDBasSyasEmis, pCN, lMensagem) = False Then
               If Not UCase(gSerBasSyasEmis) Like "*MIX*" Then
                    Shell "net send tjgomes " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
                    Shell "net send hideo " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
                    Shell "net send newton " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
                    Shell "net send oscar " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
                End If
                Call gpGraLog(0, lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
                End
            End If
    End Select
    lPoint = "5"
    Do
        'a) Posiciona controles.
        lNomArqEnvio = Trim$(lDir)

        lEndArqEntrada = gAppPath & lDir
        lPoint = "6"
        'b) Copia arquivo de entrada.
        lEndCopEntrada = Mid$(lEndArqEntrada, 1, Len(lEndArqEntrada) - 3) & lExtArqPrcsd
        Call FileCopy(lEndArqEntrada, lEndCopEntrada)

        'c) Exclui arquivo de entrada.
        lFileSize = FileLen(lEndArqEntrada)
        Kill lEndArqEntrada

        If gfPreenchido(lExtProtocolo) = True Then
        '** N�o envia protocolo para pAprf = 090
            'd) Cria e inicializa arquivo de retorno.
            lEndArqRetorno = Mid$(lEndArqEntrada, 1, Len(lEndArqEntrada) - 3) & lExtProtocolo
            lNumArqRetorno = FreeFile
            lDatHorRetorno = Format$(Now, "yyyymmddhhnnss")
            Open lEndArqRetorno For Output As #lNumArqRetorno
            lPoint = "7"
        End If
        'e) Processa arquivo de entrada.
        Call mpProEntrada(lNomArqEnvio, gfPreenchido(lExtProtocolo), (pAprf = "010"), _
                          lEndCopEntrada, lNumCopEntrada, _
                          lEndArqRetorno, lNumArqRetorno, pCN)
        
        If gfPreenchido(lExtProtocolo) = True Then
        '** N�o envia protocolo para pAprf = 090
            'f) Encerra processo.
            Close #lNumArqRetorno
    
            'g) Copia o arquivo de retorno na pasta de remessa.
            lEndCopRetorno = gAppPath & "Remessa\"
            lEndCopRetorno = lEndCopRetorno & Mid$(lEndArqRetorno, Len(lEndArqRetorno) - 11, 12)
            Call FileCopy(lEndArqRetorno, lEndCopRetorno)
            'Apaga os arquivos utilizados como c�pias auxiliares no processo
            Kill lEndArqRetorno
            Kill lEndCopEntrada
        End If
        'h) marca arquivo como recebido
        Call gpMarcaRecebido(Left(lNomArqEnvio, (InStr(1, lNomArqEnvio, ".") - 1)), lFileSize, "YASUDA", pAprf)
        lPoint = "8"
        'i) Verifica se tem outro arquivo de entrada a processar.
        lDir = Dir(lBusca)
        If Not gfPreenchido(lDir) Then
            Select Case pAprf
                Case "010"      'Transmissao acionada pelo corretor (processado pelo programa P24V007)
                    DoEvents
                Case Else
                    Call gpFecha2(pCN)
            End Select
            GoTo Busca_Transmissao
            Exit Sub
        End If
    Loop
    lPoint = "9"
    Exit Sub
ControleErro:
    Call gpGraLog(0, "gpCarregaTransmissao - Erro - " & lPoint & " - " & Err.Description)
End Sub

Public Sub gpCarregaCancelamentoEmissao(ByRef pCN As ADODB.Connection)
Dim lBusca          As String   'Busca do arquivo de entrada.
Dim lFileSize       As Double   'Tamanho em bytes do arquivo de entrada
Dim lDir            As String   'Resultado da fun��o DIR.
Dim lEndArqEntrada  As String   'Endere�o do arquivo de entrada.
Dim lEndCopRetorno  As String   'Endere�o da c�pia do arquivo de retorno.
Dim lMensagem       As String   'Mensagem.
Dim lPoint          As String
Dim lExtProtocolo   As String   'Exten��o/APRF do protocolo da transmissao
Dim lExtArqPrcsd    As String   'Exten��o/APRF do arquivo processado (Backup do arquivo recebido)
Dim lNomArqLocal    As String   'Nome do arquino copiado p/ o processamento (no App.Path)
Dim lDatHorRetorno  As String
'Variaveis abaixo estavam declaradas como globais.
'Foi alterado pois o programa P24V007 tem processamento simultaneo de multiplos usuarios, que compartilhavam as mesmas variaveis.
'Causando perda de informacoes.
Dim lNomArqEnvio    As String           ' antigo gNomArqEnvio
Dim lEndCopEntrada  As String           ' antigo gEndCopEntrada
Dim lNumCopEntrada  As Integer          ' antigo gNumCopEntrada
Dim lEndArqRetorno  As String           ' antigo gEndArqRetorno
Dim lNumArqRetorno  As Integer          ' antigo gNumArqRetorno
'================================================================================================
Dim lNossoNumero    As String
Dim lNumPI          As Double
Dim lRegistro       As String
Dim lPosicao        As Long
Dim lHora           As Date
Dim lRst            As ADODB.Recordset
Dim lUsuarioHora    As String

    'Busca os arquivos da pasta X:\mailboxes\YASUDA para o App.Path
    On Error GoTo ControleErro
    
Busca_Transmissao:
    lHora = Time
    
    
    If lHora > "19:00" Or lHora < "06:00" Then
        'o cancelamento n�o pode ser efetuado em hor�rio n�o comercial
        Exit Sub
    End If
    
    
    
    lPoint = "1"
    gOwner = "" & gPropTabelaCorporativo & "ftp_"
    
    
    lExtArqPrcsd = "012"
    lExtProtocolo = "013"
    lBusca = gEndPastas & "YASUDA\*." & lExtArqPrcsd
    lEndArqEntrada = gEndPastas & "YASUDA\"
        
    
    '4- Processa arquivo de entrada
    lPoint = "3"
               
    '5. Obt�m arquivo de entrada.
    lDir = Dir(lBusca)
    If Not gfPreenchido(lDir) Then
        If gfPreenchido(lExtProtocolo) = True Then
            lBusca = gAppPath & "Remessa\*." & lExtProtocolo
            lDir = Dir(lBusca)
            Do While gfPreenchido(lDir) = True
                If mfEnviaProtocoloCancelamento(Left(lDir, 6), lDir, lMensagem) = False Then
                    Call gpGraLog(0, "P28V300 - ERRO ao enviar protocolo de cancelamento" & lMensagem)
                    Shell "net send tjgomes " & App.EXEName & " - ERRO ao enviar protocolo de cancelamento" & lMensagem
                    Shell "net send mosilva " & App.EXEName & " - ERRO ao enviar protocolo de cancelamento" & lMensagem
                End If
                lDir = Dir(lBusca)
            Loop
        End If
        Exit Sub
    End If
    lPoint = "4"
    If mfAbrBasSQL(gEndBasSyasEmis, gTipBasSyasEmis, gSerBasSyasEmis, gEndBasSyasEmis, gUIDBasSyasEmis, _
       gPWDBasSyasEmis, pCN, lMensagem) = False Then
       If Not UCase(gSerBasSyasEmis) Like "*MIX*" Then
            Shell "net send tjgomes " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send hideo " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send newton " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send oscar " & GetLoginComputerName & " com falha na conex�o SQL.  Verificar com urg�ncia."
        End If
        Call gpGraLog(0, lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    lPoint = "5"
    Do
        'a) Posiciona controles.
        lNomArqEnvio = Trim$(lDir)
        lEndArqEntrada = gEndPastas & "YASUDA\"
        lEndArqEntrada = lEndArqEntrada & lDir
        lPoint = "6"
        'b) Copia arquivo de entrada.
        lEndCopEntrada = gAppPath & lDir
        Call FileCopy(lEndArqEntrada, lEndCopEntrada)

        'c) Exclui arquivo de entrada.
        lFileSize = FileLen(lEndArqEntrada)
        Kill lEndArqEntrada

        If gfPreenchido(lExtProtocolo) = True Then
        '** N�o envia protocolo para pAprf = 090
            'd) Cria e inicializa arquivo de retorno.
            lEndArqRetorno = Mid$(lEndCopEntrada, 1, Len(lEndCopEntrada) - 7) & lExtProtocolo
            lNumArqRetorno = FreeFile
            lDatHorRetorno = Format$(Now, "yyyymmddhhnnss")
            Open lEndArqRetorno For Output As #lNumArqRetorno
            lPoint = "7"
        End If
        lNumCopEntrada = FreeFile
        'Processa a entrado do arquivo
        Open lEndCopEntrada For Input As #lNumCopEntrada
        Line Input #lNumCopEntrada, lRegistro
        Do
            If gfPreenchido(lRegistro) Then     'N�o considerar registro em branco.
                lRegistro = UCase$(Trim(lRegistro))
                If Len(lRegistro) < 8 Then
                    lMensagem = "Arquivo de transmiss�o inv�lido - registro com menos de 8 posi��es: " & _
                                lRegistro
                    Exit Do
                End If
                Select Case Left$(lRegistro, 8)
                    Case "USUARIO ", "CORRETOR"
                        lUsuarioHora = "Usu�rio: " & Mid(lRegistro, 25, 6)
                        
                        lPosicao = InStr(lRegistro, "DATA")
                        If lPosicao <> 0 Then
                            lUsuarioHora = lUsuarioHora & " " & Mid$(lRegistro, lPosicao + 5, 2) & "/" & Mid$(lRegistro, lPosicao + 8, 2) & "/" & Mid$(lRegistro, lPosicao + 11, 4)
                        End If
                        lPosicao = InStr(lRegistro, "HORA")
                        If lPosicao <> 0 Then
                            lUsuarioHora = lUsuarioHora & " " & _
                                           Mid$(lRegistro, lPosicao + 5, 2) & ":" & _
                                           Mid$(lRegistro, lPosicao + 8, 2) & ":" & _
                                           Mid$(lRegistro, lPosicao + 11, 2)
                        End If
                    Case "CANCELAR"
                        lNossoNumero = Mid(lRegistro, 9, 20)
                        lNumPI = Mid(lRegistro, 29, 10)
                        
                        Exit Do
                    Case Else
                        lMensagem = "Arquivo de cancelamento inv�lido - registro com c�digo desconhecido: " & _
                                    lRegistro
                        Exit Do
                End Select
                If EOF(lNumCopEntrada) Then
                    lMensagem = "Arquivo de cancelamento inv�lido - n�o encontrado registro de controle."
                    Exit Do
                End If
                Line Input #lNumCopEntrada, lRegistro
            End If
        Loop
    
        Close #lNumCopEntrada
        'Gera o protocolo
        'Open lEndArqRetorno For Output As #lNumArqRetorno
        If gfPreenchido(lMensagem) Then
            'Erro
            lRegistro = "CANCELA" & lNossoNumero & lNumPI & "01" & lMensagem
        ElseIf gfPreenchido(lNossoNumero) = False Or lNumPI = 0 Then
            lRegistro = "CANCELA" & lNossoNumero & lNumPI & "02"
        Else
            'Executa a procedure
            gSelect = "Exec ged.dbo.proc_CancelaEmissaoSyas " & lNumPI & ",'" & lUsuarioHora & "'"
            If Not gfObtRegistro(pCN, gSelect, lRst, lMensagem) Then
                Call gpGraLog(0, "P28V300 - Cancelamento " & lMensagem)
                Shell "net send tjgomes " & App.EXEName & " - ERRO ao executar procedure de cancelamento" & lMensagem
                Shell "net send mosilva " & App.EXEName & " - ERRO ao executar procedure de cancelamento" & lMensagem
            End If
            
            If lRst("Acao") = 0 Then
                'Cancelamento executado com sucesso
                lRegistro = "CANCELA" & lNossoNumero & lNumPI & "00CANCELAMENTO DO PI REALIZADO COM SUCESSO"
            Else
                'Cancelamento n�o executado
                lRegistro = "CANCELA" & lNossoNumero & lNumPI & lRst("Acao")
                Select Case lRst("Acao")
                    Case 70
                        lRegistro = lRegistro & "PI CANCELADO POR FALTA DE PAGAMENTO"
                    Case 80
                        lRegistro = lRegistro & "PI RECUSADO/CANCELADO"
                    Case 90
                        lRegistro = lRegistro & "PI EMITIDO"
                End Select
            End If
            
        End If
        Print #lNumArqRetorno, lRegistro
        
        'f) Encerra processo.
        Close #lNumArqRetorno

        'g) Copia o arquivo de retorno na pasta de remessa.
        lEndCopRetorno = gAppPath & "Remessa\"
        If Len(lNomArqEnvio) = 16 Then
            lEndCopRetorno = lEndCopRetorno & Mid$(lEndArqRetorno, Len(lEndArqRetorno) - 11, 12)
        Else
            lEndCopRetorno = lEndCopRetorno & Mid$(lEndArqRetorno, Len(lEndArqRetorno) - 13, 14)
        End If
        Call FileCopy(lEndArqRetorno, lEndCopRetorno)
        'Apaga os arquivos utilizados como c�pias auxiliares no processo
        Kill lEndArqRetorno
        Kill lEndCopEntrada
        
        ''Fim protocolo


        'h) marca arquivo como recebido
        Call gpMarcaRecebido(Left(lNomArqEnvio, (InStr(1, lNomArqEnvio, ".") - 1)), lFileSize, "YASUDA", lExtArqPrcsd)
        lPoint = "8"
        'i) Verifica se tem outro arquivo de entrada a processar.
        lDir = Dir(lBusca)
        If Not gfPreenchido(lDir) Then
            Call gpFecha2(pCN)
            GoTo Busca_Transmissao
            Exit Sub
        End If
    Loop
    lPoint = "9"
    Exit Sub
ControleErro:
    Call gpGraLog(0, "gpCarregaCancelamentoEmissao - Erro - " & lPoint & " - " & Err.Description)
End Sub

Private Function mfEnviaProtocolo(ByVal pCodUser As String, _
                                  ByVal pFileName As String, _
                                  ByRef pMensagem As String) As Boolean
                                  
Dim lIDUser             As Integer
Dim lCopyOrigem         As String
Dim lPasteDestino       As String
Dim lPathKill           As String
Dim lMensagem           As String
Dim lExec               As String
Dim lRsEAPDB            As ADODB.Recordset
Dim lCN_EAPDB           As ADODB.Connection

 Err = 0
 On Error GoTo mfEnviaProtocolo_ERRO
 pMensagem = ""
 
'1- verifica a existencia diretorio e o arquivo de origem
    lCopyOrigem = gAppPath & "Remessa\" & pFileName
        
    If gfPreenchido(Dir(gAppPath & "Remessa", vbDirectory)) = True Then
        If gfPreenchido(Dir(lCopyOrigem)) = False Then
            pMensagem = lCopyOrigem & Chr(13) & "arquivo n�o localizado"
            GoTo mfEnviaProtocolo_ERRO
        End If
    Else
        pMensagem = gAppPath & "APOLICES" & Chr(13) & "Caminho inexistente"
        GoTo mfEnviaProtocolo_ERRO
    End If

'2- verifica a existencia diretorio destino
    
    lPasteDestino = gEndPastas
    
    
    
    lPasteDestino = lPasteDestino & pCodUser
    lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".011.011"
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino
    End If
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
    'Verifica tambem a existencia da pasta temp
        '********** Sem esta pasta a trasmiss�o de protocolo ao usuario
        '********** gera erro e encera o servi�o EDIServer
    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino & "\temp"
    End If

    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
'3- Apaga o arquivo destino caso j� exista no diretorio destino
    
    'Concatena o nome do arquivo da String
    lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".011.011"
    
    If gfPreenchido(Dir(lPathKill)) = True Then
        Kill lPathKill
    End If
    
'4- Copia o arquivo de ap�lices para a pasta do usuario
    FileCopy lCopyOrigem, lPasteDestino
    
'5- verifica a existencia do arquivo no destino
    If gfPreenchido(Dir(lPasteDestino)) = False Then
        'Arquivo n�o foi copiado
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel copiar o arquivo."
        GoTo mfEnviaProtocolo_ERRO
    End If

'6- Abre a base de dados
       
    If gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, _
                   gPWDBasEAPDB, lCN_EAPDB, lMensagem) = False Then
        Call gpGraLog(0, "gpMarcaRecebido - " & lMensagem)
        GoTo mfEnviaProtocolo_ERRO
    Else
        'Inclui registro para receber este arquivo
        lExec = "" & gPropTabelaSyasEdi & "[Proc_EAPDB_IncluiEnvio] "
        lExec = lExec & "'YASUDA', "
        lExec = lExec & "'" & Mid(pFileName, 1, 8) & ".011', "
        lExec = lExec & "'" & pCodUser & "'"
        
        If gfObtRegistro(lCN_EAPDB, lExec, lRsEAPDB, lMensagem) = False Then
            If Err = 0 Then
                Err = 1
            End If
            GoTo mfEnviaProtocolo_ERRO
        Else
            lCN_EAPDB.Close
        End If
    End If

'7- Exclui o arquivo de origem
    If gfPreenchido(Dir(lCopyOrigem)) = True Then
        Kill lCopyOrigem
    End If
    
'8 Finalizado OK
    mfEnviaProtocolo = True

'Saida da Fun��o
mfEnviaProtocolo_SAIDA:
    Exit Function
    
'Tratamento de erro
mfEnviaProtocolo_ERRO:
    mfEnviaProtocolo = False
    pMensagem = "mfEnviaProtocolo - Erro " & Err & " " & Error$ & pMensagem
    
    GoTo mfEnviaProtocolo_SAIDA
End Function
Private Function mfEnviaProtocoloCancelamento(ByVal pCodUser As String, _
                                  ByVal pFileName As String, _
                                  ByRef pMensagem As String) As Boolean
                                  
Dim lIDUser             As Integer
Dim lCopyOrigem         As String
Dim lPasteDestino       As String
Dim lPathKill           As String
Dim lMensagem           As String
Dim lExec               As String
Dim lRsEAPDB            As ADODB.Recordset
Dim lCN_EAPDB           As ADODB.Connection

 Err = 0
 On Error GoTo mfEnviaProtocolo_ERRO
 pMensagem = ""
 
'1- verifica a existencia diretorio e o arquivo de origem
    lCopyOrigem = gAppPath & "Remessa\" & pFileName
        
    If gfPreenchido(Dir(gAppPath & "Remessa", vbDirectory)) = True Then
        If gfPreenchido(Dir(lCopyOrigem)) = False Then
            pMensagem = lCopyOrigem & Chr(13) & "arquivo n�o localizado"
            GoTo mfEnviaProtocolo_ERRO
        End If
    Else
        pMensagem = gAppPath & "APOLICES" & Chr(13) & "Caminho inexistente"
        GoTo mfEnviaProtocolo_ERRO
    End If

'2- verifica a existencia diretorio destino
    
    lPasteDestino = gEndPastas
    
    
    
    lPasteDestino = lPasteDestino & pCodUser
    If Len(pFileName) = 14 Then
        lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 10) & ".013.013"
    Else
        lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".013.013"
    End If
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino
    End If
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
    'Verifica tambem a existencia da pasta temp
        '********** Sem esta pasta a trasmiss�o de protocolo ao usuario
        '********** gera erro e encera o servi�o EDIServer
    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino & "\temp"
    End If

    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
'3- Apaga o arquivo destino caso j� exista no diretorio destino
    
    'Concatena o nome do arquivo da String
    If Len(pFileName) = 14 Then
        lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 10) & ".013.013"
    Else
        lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".013.013"
    End If
    
    If gfPreenchido(Dir(lPathKill)) = True Then
        Kill lPathKill
    End If
    
'4- Copia o arquivo de ap�lices para a pasta do usuario
    FileCopy lCopyOrigem, lPasteDestino
    
'5- verifica a existencia do arquivo no destino
    If gfPreenchido(Dir(lPasteDestino)) = False Then
        'Arquivo n�o foi copiado
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel copiar o arquivo."
        GoTo mfEnviaProtocolo_ERRO
    End If

'6- Abre a base de dados
       
    If gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, _
                   gPWDBasEAPDB, lCN_EAPDB, lMensagem) = False Then
        Call gpGraLog(0, "gpMarcaRecebido - " & lMensagem)
        GoTo mfEnviaProtocolo_ERRO
    Else
        'Inclui registro para receber este arquivo
        lExec = "" & gPropTabelaSyasEdi & "[Proc_EAPDB_IncluiEnvio] "
        lExec = lExec & "'YASUDA', "
        If Len(pFileName) = 12 Then
            lExec = lExec & "'" & Mid(pFileName, 1, 8) & ".013', "
        Else
            lExec = lExec & "'" & Mid(pFileName, 1, 10) & ".013', "
        End If
        lExec = lExec & "'" & pCodUser & "'"
        
        If gfObtRegistro(lCN_EAPDB, lExec, lRsEAPDB, lMensagem) = False Then
            If Err = 0 Then
                Err = 1
            End If
            GoTo mfEnviaProtocolo_ERRO
        Else
            lCN_EAPDB.Close
        End If
    End If

'7- Exclui o arquivo de origem
    If gfPreenchido(Dir(lCopyOrigem)) = True Then
        Kill lCopyOrigem
    End If
    
'8 Finalizado OK
    mfEnviaProtocoloCancelamento = True

'Saida da Fun��o
mfEnviaProtocolo_SAIDA:
    Exit Function
    
'Tratamento de erro
mfEnviaProtocolo_ERRO:
    mfEnviaProtocoloCancelamento = False
    pMensagem = "mfEnviaProtocoloCancelamento - Erro " & Err & " " & Error$ & pMensagem
    
    GoTo mfEnviaProtocolo_SAIDA
End Function

Private Sub mpProEntrada(ByVal pNomArqEnvio As String, _
                         ByVal pTemProtocolo As Boolean, _
                         ByVal pSohValidacao As Boolean, _
                         ByRef pEndCopEntrada As String, _
                         ByRef pNumCopEntrada As Integer, _
                         ByRef pEndArqRetorno As String, _
                         ByRef pNumArqRetorno As Integer, _
                         ByRef pCN As ADODB.Connection)
                         
    'Procedure: processa arquivo de entrada (a partir da c�pia do arquivo de entrada).
Dim lMensagem   As String   'Mensagem.
Dim lPoint      As String
    
Dim lQuaPropostas        As Integer             'Antigos gQuaPropostas
Dim lDatHorEnvio         As String              'Antigo gDatHorEnvio
Dim lstcProposta         As stcA28V300          'Antigo gstcProposta
Dim lColProposta         As Collection          'Antigo lColProposta
Dim lNumPI               As Double
Err.Clear
On Error GoTo TrataErro

    lPoint = "01"
    Set lstcProposta = New stcA28V300
    Set lColProposta = New Collection
    
    pNumCopEntrada = FreeFile
    Open pEndCopEntrada For Input As #pNumCopEntrada
    lPoint = "02"
    '1. Verifica arquivo de entrada (atrav�s da c�pia do arquivo).
    If mfVerEntrada(pNumCopEntrada, lDatHorEnvio, lMensagem) = False Then
        lPoint = "03"
        Call mpGraRetorno(pNomArqEnvio, lDatHorEnvio, pSohValidacao, "2", pTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
        Close #pNumCopEntrada
        GoTo SAIDA
    End If
    lPoint = "04"
    Close #pNumCopEntrada
    Open pEndCopEntrada For Input As #pNumCopEntrada    '***Fecha e reabre o arquivo... a func mfVerEntrada (le o arquivo)
                                                        'e a func gfFase1 tamb�m precisa passar no arquivo inteiro.
    
    '2. Fase 1: Processa arquivo de entrada (a partir da c�pia).
    lPoint = "06"
    If gfFase1(pNomArqEnvio, lDatHorEnvio, pTemProtocolo, pSohValidacao, _
               pEndCopEntrada, pNumCopEntrada, _
               pEndArqRetorno, pNumArqRetorno, _
               lQuaPropostas, lstcProposta, lColProposta, pCN) = True Then
        If pSohValidacao = True Then
            'j) Grava registro de retorno - registro encaminhado para processamento.
            Call mpGraRetorno(pNomArqEnvio, lDatHorEnvio, pSohValidacao, "1", pTemProtocolo, " ", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
        End If
    Else
        lPoint = "07"
        Close #pNumCopEntrada
        GoTo SAIDA
    End If
    lPoint = "08"
    Close #pNumCopEntrada
        
    If pSohValidacao = False Then
        '3. Fase 2: consiste e calcula.
        'Call mpFase2(lNumArqUsuario, lUsuTransmissao, bdSYASEMIS)
    
        '4. Carrega tabelas de transfer�ncia para o mainframe (TAB_DT1101D_COMUM/VEIC, TAB_PERFIL_AUTO e
        '   TAB_CONFIRM_BONUS).
        lPoint = "09"
        If lQuaPropostas <> 0 Then
            If mfFase3(pNomArqEnvio, lQuaPropostas, pSohValidacao, pEndArqRetorno, pNumArqRetorno, lQuaPropostas, lColProposta, pCN) = False Then
                GoTo SAIDA
            End If
        End If
    End If
    
SAIDA:
    Err.Clear
    On Error GoTo 0
    Exit Sub
    
TrataErro:
    Call gpGraLog(0, "mpProEntrada(" & lPoint & "| Arquivo:" & pNomArqEnvio & " ) Erro: " & Err & "-" & Error)
    ''Volto o arquivo
    FileCopy pEndCopEntrada, "ERRO_" & pEndCopEntrada
    
    GoTo SAIDA
    
End Sub

Public Sub gpMarcaRecebido(ByVal pArq010 As String, pFilesize As Double, ByVal pReceiver As String, ByVal pExtensao As String)
'Procedure criada para atualizar a Base EAPDB com as informa��es do obtidas
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o
                            'lDados:........String contendo todos os registros obtidos
Dim lMensagem       As String
Dim lCN_EAPDB       As ADODB.Connection
Dim lUpdate         As String

Err = 0
On Error GoTo gpMarcaRecebido_ERRO

        
    If gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, _
                   gPWDBasEAPDB, lCN_EAPDB, lMensagem) = False Then
        Call gpGraLog(0, "gpMarcaRecebido - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    
'1- Monta os comandos SQL
    If gfPreenchido(pArq010) = True Then
        lUpdate = "Update " & gPropTabelaSyasEdi & "[mailbox] "
        lUpdate = lUpdate & "SET [status] = 3, "
        lUpdate = lUpdate & "[filesize] = " & pFilesize & ", "
        lUpdate = lUpdate & "[last_extract_datetime] = CURRENT_TIMESTAMP "
        lUpdate = lUpdate & "WHERE [filename] = '" & pArq010 & "." & pExtensao & "." & pExtensao & "' "
        lUpdate = lUpdate & "and [status] = 1 "
        lUpdate = lUpdate & "and [aprf] = '" & pExtensao & "' "
        lUpdate = lUpdate & "and [receiver]= '" & pReceiver & "' "
    Else
        Exit Sub
    End If

'2- Executa atualiza�ao do registro
    If gfExeSQL(lCN_EAPDB, lUpdate, lMensagem) <> 0 Then
       If Err = 0 Then
            Err = 1
       End If
       GoTo gpMarcaRecebido_ERRO
    End If

gpMarcaRecebido_SAIDA:
    Exit Sub

gpMarcaRecebido_ERRO:
    lMensagem = lMensagem & " gpMarcaRecebido - Erro " & Err & " " & Error$
    
    Call gpGraLog(0, lMensagem & "-" & pArq010)

    GoTo gpMarcaRecebido_SAIDA

End Sub

Private Function mfVerEntrada(ByRef pNumCopEntrada As Integer, _
                              ByRef pDatHorEnvio As String, _
                              ByRef pMensagem As String) As Boolean
    'Fun��o: Verifica arquivo de entrada.

    'Par�metro de sa�da...pMensagem...Mensagem.

Dim lI              As Integer  'Utilizado com For...Next.
Dim lPosicao        As Integer  'Utilizado com InStr.
Dim lRegistro       As String   'Registro.
Dim lTotCalculado   As Double   'Total calculado pelo programa.
Dim lTotGravado     As Double   'Total gravado no arquivo de propostas.
Dim lTotInvertido   As String   'Total invertido.



    mfVerEntrada = False

    '1. Posiciona controle.
    pDatHorEnvio = "00000000000000"

    '2. Verifica se arquivo de entrada tem registro.
    Line Input #pNumCopEntrada, lRegistro
    If EOF(pNumCopEntrada) Then
        pMensagem = "Arquivo de transmiss�o sem registro."
        Exit Function
    End If

    '3. Verifica primeiro registro.
    If Not gfPreenchido(lRegistro) Then
        pMensagem = "Arquivo de transmiss�o inv�lido - primeiro registro em branco."
        Exit Function
    End If
    If Len(Trim(lRegistro)) < 8 Then
        pMensagem = "Arquivo de transmiss�o inv�lido - registro com menos de 8 caracteres: " & lRegistro
        Exit Function
    End If

    '4. Verifica integridade dos dados, utilizando o mesmo processo para c�lculo do controle utilizado no
    '   programa que cria o arquivo de dados.
    '   Formato do �ltimo registro do arquivo: "PROPOSTA XXXXXXXXXXX", onde XXXXXXXXXXX � o valor da soma
    '   dos valores ASC de todos os caracteres das linhas anteriores, gravado de forma invertida.
    '   Por exemplo: Se soma dos valores ASC de todos os caracteres dos registros de um arquivo
    '   (excetuando-se �ltimo registro) for igual a 39.485, �ltimo registro ser�: PROPOSTA 58493.
    lTotCalculado = 0
    lTotGravado = 0
    Do
        If gfPreenchido(lRegistro) Then     'N�o considerar registro em branco.
            lRegistro = UCase$(Trim(lRegistro))
            If Len(lRegistro) < 8 Then
                pMensagem = "Arquivo de transmiss�o inv�lido - registro com menos de 8 posi��es: " & _
                            lRegistro
                Exit Function
            End If
            Select Case Left$(lRegistro, 8)
                Case "USUARIO ", "CORRETOR"
                    lPosicao = InStr(lRegistro, "DATA")
                    If lPosicao = 0 Then
                        pDatHorEnvio = "00000000"
                    Else
                        pDatHorEnvio = Mid$(lRegistro, lPosicao + 11, 4) & _
                                       Mid$(lRegistro, lPosicao + 8, 2) & _
                                       Mid$(lRegistro, lPosicao + 5, 2)
                    End If
                    lPosicao = InStr(lRegistro, "HORA")
                    If lPosicao = 0 Then
                        pDatHorEnvio = pDatHorEnvio & "000000"
                    Else
                        pDatHorEnvio = pDatHorEnvio & _
                                       Mid$(lRegistro, lPosicao + 5, 2) & _
                                       Mid$(lRegistro, lPosicao + 8, 2) & _
                                       Mid$(lRegistro, lPosicao + 11, 2)
                    End If
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                'Inclus�o da tabela P0042601
                'Case "P0042100", "P0042200", "P0042300", "P0042600", "P0042700", "TABAJUPR"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'Case "P0042100", "P0042200", "P0042300", "P0042600", "P0042601", "P0042700", "TABAJUPR"
                'Inclus�o da Tabela TAB_HIST_ROTEIRO_CALCULO - HIROTCAL
                Case "P0042100", "P0042200", "P0042300", "P0042600", "P0042601", "P0042700", "TABAJUPR", "HIROTCAL"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                    'Registro v�lidos.
                Case "PROPOSTA"
                    lTotGravado = CDbl(Trim$(Mid$(lRegistro, 9)))
                    Exit Do
                Case Else
                    pMensagem = "Arquivo de transmiss�o inv�lido - registro com c�digo desconhecido: " & _
                                lRegistro
                    Exit Function
            End Select
            For lI = 1 To Len(Trim(lRegistro))
                lTotCalculado = lTotCalculado + Asc(Mid(lRegistro, lI, 1))
            Next lI
            If EOF(pNumCopEntrada) Then
                pMensagem = "Arquivo de transmiss�o inv�lido - n�o encontrado registro de controle."
                Exit Function
            End If
            Line Input #pNumCopEntrada, lRegistro
        End If
    Loop
    lTotInvertido = ""
    For lI = Len(Trim(CStr(lTotCalculado))) To 1 Step -1
        lTotInvertido = lTotInvertido & Mid(Trim(CStr(lTotCalculado)), lI, 1)
    Next lI
    
    GoTo Pula       'TEMPOR�RIO...
    
    If lTotGravado <> CDbl(lTotInvertido) Then
        pMensagem = "Arquivo de transmiss�o inv�lido - registro de controle inv�lido."
        Exit Function
    End If
    
    
Pula:

    mfVerEntrada = True
End Function

Private Sub mpGraRetorno(ByVal pNomArqEnvio As String, _
                         ByVal pDatHorEnvio As String, _
                         ByVal pSohValidacao As Boolean, _
                         ByVal pIndProposta As String, _
                         ByVal pTemProtocolo As Boolean, _
                         ByVal pMensagem As String, _
                         ByRef pstcProposta As stcA28V300, _
                         ByRef pEndArqRetorno As String, _
                         ByRef pNumArqRetorno As Integer, _
                         ByRef pCN As ADODB.Connection)
    'Procedure: grava arquivo de retorno.

    'Par�metros de entrada...pIndProposta...Indicador de proposta.
    '                        pMensagem......Mensagem.

Dim lMensagem           As String           'Mensagem.
Dim lObservacao         As String           'Observa��o.
Dim lRegistro           As String           'Registro.
Dim rsP0042900          As ADODB.Recordset  'P0042900: registro.
Dim lCN_SYASEMIS        As ADODB.Connection
Dim lInsert             As String
Dim lSelect             As String
Dim lDelete             As String
Dim lDatHorRetorno      As String
Static lPriVez          As Boolean          'Indicador de primeira vez.
Static lNosNumero       As String           'Nosso n�mero.
Static lNumItem         As String           'N�mero do item.
Static lNumLinha        As Integer          'N�mero da linha.
Static lNumReferencia   As String           'N�mero de refer�ncia.
Dim lPoint          As String
    
    
Err.Clear
On Error GoTo TrataErro
    lPoint = "01"
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
            
    '1. Grava registro para usu�rio referente � tabela P0042900 e grava registro na tabela do SQL-Server.
    lPoint = "02"
    If lPriVez = False Then
        lPoint = "03"
        lNumLinha = 0
        lNosNumero = String(20, "0")
        lNumItem = String(4, "0")
        lNumReferencia = String(6, "0")
        If pSohValidacao = False Then
            lPriVez = True
        Else
            lPriVez = False
        End If
    End If
    lPoint = "04"
    If pstcProposta.RegNosNumero = lNosNumero And pstcProposta.RegNumReferencia = lNumReferencia And pstcProposta.RegNumItem = lNumItem Then
        'N�o precisa gravar o P0042900.
        lPoint = "05"
    Else
        lPoint = "06"
        'a) Inicializa indicador de n�mero de linha.
        lNumLinha = 0
        'b) Grava registro para usu�rio.
        '===1) C�digo do registro.
        lRegistro = "P0042900"
        lPoint = "07"
        With pstcProposta
            '===2) Nosso n�mero.
            .RegNosNumero = Left$(.RegNosNumero & Space(20), 20)
            lRegistro = lRegistro & .RegNosNumero
            '===3) Refer�ncia.
            .RegNumReferencia = Left$(.RegNumReferencia & Space(6), 6)
            lRegistro = lRegistro & .RegNumReferencia
            '===4) N�mero do item.
            .RegNumItem = Left$(.RegNumItem & Space(4), 4)
            lRegistro = lRegistro & .RegNumItem
            '===5) Nome do arquivo de envio.
            pNomArqEnvio = Left$(pNomArqEnvio & Space(12), 12)
            lRegistro = lRegistro & pNomArqEnvio
            '===6) Data e hora de envio.
            pDatHorEnvio = Left$(pDatHorEnvio & Space(14), 14)
            lRegistro = lRegistro & pDatHorEnvio
            '===7) Nome do segurado.
            .RegNomSegurado = Left$(.RegNomSegurado & Space(60), 60)
            lRegistro = lRegistro & .RegNomSegurado
            '===8) Tipo de emiss�o.
            .RegTipEmissao = Left$(.RegTipEmissao & Space(3), 3)
            lRegistro = lRegistro & .RegTipEmissao
            '===9) Data de in�cio de vig�ncia.
            .RegDatVigInicio = Left$(.RegDatVigInicio & Space(8), 8)
            lRegistro = lRegistro & .RegDatVigInicio
            '===10) Data de t�rmino de vig�ncia.
            .RegDatVigTermino = Left$(.RegDatVigTermino & Space(8), 8)
            lRegistro = lRegistro & .RegDatVigTermino
            '===12) C�digo do ve�culo.
            .RegCodVeiculo = Left$(.RegCodVeiculo & Space(8), 8)
            lRegistro = lRegistro & .RegCodVeiculo
            '===13) Nome do ve�culo.
            .RegNomVeiculo = Left$(.RegNomVeiculo & Space(60), 60)
            lRegistro = lRegistro & .RegNomVeiculo
            '===14) Ano de fabrica��o do ve�culo.
            .RegAnoFabricacao = Left$(.RegAnoFabricacao & Space(4), 4)
            lRegistro = lRegistro & .RegAnoFabricacao
            '===16) Ano de modelo do ve�culo.
            .RegAnoModelo = Left$(.RegAnoModelo & Space(4), 4)
            lRegistro = lRegistro & .RegAnoModelo
            '===17) C�digo da placa.
            .RegCodPlaca = Left$(.RegCodPlaca & Space(8), 8)
            lRegistro = lRegistro & .RegCodPlaca
            '===18) C�digo do chassi.
            .RegCodChassi = Left$(.RegCodChassi & Space(20), 20)
            lRegistro = lRegistro & .RegCodChassi
            '===19) C�digo do chassi estrangeiro.
            .RegCodChaEstrang = Left$(.RegCodChaEstrang & Space(20), 20)
            lRegistro = lRegistro & .RegCodChaEstrang
            '===20) Nome do arquivo de retorno.
            If Len(pEndArqRetorno) < 12 Then
                pEndArqRetorno = pEndArqRetorno & Space(12)
            End If
            lRegistro = lRegistro & Right$(pEndArqRetorno, 12)
            '===21) Data e hora do arquivo de retorno.
            lDatHorRetorno = Format$(Now, "yyyymmddhhnnss")
            lRegistro = lRegistro & lDatHorRetorno
            '===22) Indicador de proposta.
            pIndProposta = Left$(pIndProposta & Space(1), 1)
            lRegistro = lRegistro & pIndProposta                'Ind_Proposta.
            lRegistro = lRegistro & String(10, "0")             'Num_Apolice.
            lRegistro = lRegistro & String(4, "0")              'Num_Item_Apolice.
            lRegistro = lRegistro & String(8, "0")              'Dat_Emissao.
            lRegistro = lRegistro & Format(pstcProposta.RegNumPI, "0000000000")              'Num_PI.
            If pTemProtocolo = True Then
                lPoint = "08"
                Print #pNumArqRetorno, lRegistro
            End If
            lPoint = "09"
            '===23) Posiciona controles.
            lNosNumero = .RegNosNumero
            lNumReferencia = .RegNumReferencia
            lNumItem = .RegNumItem
            'c) Grava registro P0042900 na base de dados SQL-Server.
            lInsert = "INSERT INTO " & gOwner & "P0042900 (Nosso_Numero, "
            If InStr(1, gOwner, "ftp_") > 0 Then
                lInsert = lInsert & " Cod_Unicidade, "
            End If
            lInsert = lInsert & "Num_Referencia, Num_Item, Nom_Arq_Envio, " & _
                      "Dat_Hor_Envio, Nom_Segurado, Tip_Emissao, Dat_Vig_Inicio, Dat_Vig_Termino, " & _
                      "Cod_Veiculo, Nom_Veiculo, Ano_Fabricacao, Ano_Modelo, Cod_Placa, Cod_Chassi, " & _
                      "Cod_Chassi_Estrang, Nom_Arq_Retorno, Dat_Hor_Retorno, Ind_Proposta, Num_Apolice, " & _
                      "Num_Item_Apolice, Dat_Emissao) VALUES ("
            lInsert = lInsert & "'" & .RegNosNumero & "', "                     'Nosso_Numero.
            If InStr(1, gOwner, "ftp_") > 0 Then
                lInsert = lInsert & .CodUnicidade & ", "                            'Cod Unicidade
            End If
            lInsert = lInsert & "'" & .RegNumReferencia & "', "                 'Num_Referencia.
            lInsert = lInsert & "'" & .RegNumItem & "', "                       'Num_Item.
            lInsert = lInsert & "'" & pNomArqEnvio & "', "                      'Nom_Arq_Envio.
            lInsert = lInsert & "'" & pDatHorEnvio & "', "                      'Dat_Hor_Envio.
            lInsert = lInsert & "'" & gfForAspas(.RegNomSegurado) & "', "       'Nom_Segurado.
            lInsert = lInsert & "'" & .RegTipEmissao & "', "                    'Tip_Emissao.
            lInsert = lInsert & "'" & .RegDatVigInicio & "', "                  'Dat_Vig_Inicio.
            lInsert = lInsert & "'" & .RegDatVigTermino & "', "                 'Dat_Vig_Termino.
            lInsert = lInsert & "'" & .RegCodVeiculo & "', "                    'Cod_Veiculo.
            lInsert = lInsert & "'" & gfForAspas(.RegNomVeiculo) & "', "        'Nom_Veiculo.
            lInsert = lInsert & "'" & .RegAnoFabricacao & "', "                 'Ano_Fabricacao.
            lInsert = lInsert & "'" & .RegAnoModelo & "', "                     'Ano_Modelo.
            lInsert = lInsert & "'" & .RegCodPlaca & "', "                      'Cod_Placa.
            lInsert = lInsert & "'" & .RegCodChassi & "', "                     'Cod_Chassi.
            lInsert = lInsert & "'" & .RegCodChaEstrang & "', "                 'Cod_Chassi_Estrang.
            lInsert = lInsert & "'" & Right$(pEndArqRetorno, 12) & "', "        'Nom_Arq_Retorno.
            lInsert = lInsert & "'" & lDatHorRetorno & "', "                    'Dat_Hor_Retorno.
            lInsert = lInsert & "'" & pIndProposta & "', "                      'Ind_Proposta.
            lInsert = lInsert & "'0000000000', "                                'Num_Apolice.
            lInsert = lInsert & "'0000', "                                      'Num_Item_Apolice.
            lInsert = lInsert & "'00000000')"                                   'Dat_Emissao.
            lPoint = "10"
        End With
        If pSohValidacao = True Then
            lPoint = "11"
            DoEvents
        Else
            lPoint = "12"
            If mfExeSQL(pCN, lInsert, lMensagem) <> 0 Then
                lPoint = "13"
                'Verifica se tem registros com mesma chave na tabela P0042900.
                lSelect = "SELECT Nosso_Numero FROM " & gOwner & "P0042900 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & _
                          "' AND Num_Referencia = '" & pstcProposta.RegNumReferencia & "' AND Num_Item = '" & _
                          pstcProposta.RegNumItem & "' AND Nom_Arq_Envio = '" & pNomArqEnvio & _
                          "' AND Dat_Hor_Envio = '" & pDatHorEnvio & "'"
                If InStr(1, gOwner, "ftp_") > 0 Then
                    lSelect = lSelect & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
                End If
                lPoint = "13"
                If gfObtRegistro(pCN, lSelect, rsP0042900, lMensagem) = False Then
                    lPoint = "14"
                    Call gpGraLog(0, lMensagem)
                    Call gpFecha2(pCN)
                    End
                End If
                lPoint = "15"
                If rsP0042900.RecordCount = 0 Then
                    lPoint = "16"
                    'Se n�o tem registro na tabela P0042900, emite mensagem de erro e encerra processo.
                    Call gpGraLog(0, lMensagem)
                    Call gpFecha2(pCN)
                    End
                End If
                lPoint = "17"
                'Se tem registro na tabela P0042900, exclui poss�veis registros das tabelas P0042900 e
                'P0042901 e tenta incluir novamente.
                lDelete = "DELETE FROM " & gOwner & "P0042900 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & _
                          "' AND Num_Referencia = '" & pstcProposta.RegNumReferencia & "' AND Num_Item = '" & _
                          pstcProposta.RegNumItem & "' AND Nom_Arq_Envio = '" & pNomArqEnvio & _
                          "' AND Dat_Hor_Envio = '" & pDatHorEnvio & "'"
                If InStr(1, gOwner, "ftp_") > 0 Then
                    lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
                End If
                lPoint = "18"
                If mfExeSQL(pCN, lDelete, lMensagem) <> 0 Then
                    lPoint = "19"
                    Call gpGraLog(0, lMensagem)
                    Call gpFecha2(pCN)
                    End
                End If
                lPoint = "20"
                lDelete = "DELETE FROM " & gOwner & "P0042901 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & _
                          "' AND Num_Referencia = '" & pstcProposta.RegNumReferencia & "' AND Num_Item = '" & _
                          pstcProposta.RegNumItem & "' AND Nom_Arq_Envio = '" & pNomArqEnvio & _
                          "' AND Dat_Hor_Envio = '" & pDatHorEnvio & "'"
                If InStr(1, gOwner, "ftp_") > 0 Then
                    lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
                End If
                If mfExeSQL(pCN, lDelete, lMensagem) <> 0 Then
                    lPoint = "21"
                    Call gpGraLog(0, lMensagem)
                    Call gpFecha2(pCN)
                    End
                End If
                lPoint = "22"
                'Tenta incluir novamente.
                If mfExeSQL(pCN, lInsert, lMensagem) <> 0 Then
                    lPoint = "23"
                    Call gpGraLog(0, lMensagem)
                    Call gpFecha2(pCN)
                    End
                End If
                lPoint = "24"
            End If
            lPoint = "25"
        End If
        lPoint = "26"
    End If
    lPoint = "27"

    '2. Grava registro para usu�rio referente � tabela P0042901 e grava registro na tabela do SQL-Server.
    If gfPreenchido(pMensagem) Then
        lPoint = "28"
        lMensagem = Trim$(pMensagem)
        'lNumLinha = 0   ===>>> n�o posicionar lNumLinha = 0 pois � uma vari�vel est�tica.
        Do
        lPoint = "29"
            'a) Grava registro para usu�rio.
            lNumLinha = lNumLinha + 1
            lRegistro = "P0042901"
            lRegistro = lRegistro & pstcProposta.RegNosNumero       'Nosso_Numero.
            lRegistro = lRegistro & pstcProposta.RegNumReferencia   'Num_Referencia.
            lRegistro = lRegistro & pstcProposta.RegNumItem         'Num_Item.
            lRegistro = lRegistro & pNomArqEnvio        'Nom_Arq_Envio.
            lRegistro = lRegistro & pDatHorEnvio        'Dat_Hor_Envio.
            lRegistro = lRegistro & Format$(lNumLinha, "0000")
            If Len(lMensagem) > 100 Then
                lObservacao = Left$(lMensagem, 100)
                lMensagem = Mid$(lMensagem, 101)
            Else
                lObservacao = lMensagem
                lMensagem = ""
            End If
            lObservacao = Left$(lObservacao & Space(100), 100)
            lRegistro = lRegistro & lObservacao
            If pTemProtocolo = True Then
                lPoint = "30"
                Print #pNumArqRetorno, lRegistro
            End If
            lPoint = "31"
            'b) Grava registro P0042901 na base de dados SQL-Server.
            lInsert = "INSERT INTO " & gOwner & "P0042901 (Nosso_Numero, "
            If InStr(1, gOwner, "ftp_") > 0 Then
                lInsert = lInsert & " Cod_Unicidade, "
            End If
            lInsert = lInsert & "Num_Referencia, Num_Item, Nom_Arq_Envio, " & _
                      "Dat_Hor_Envio, Num_Linha, Observacao) VALUES ("
            lInsert = lInsert & "'" & pstcProposta.RegNosNumero & "', "                     'Nosso_Numero.
            If InStr(1, gOwner, "ftp_") > 0 Then
                lInsert = lInsert & pstcProposta.CodUnicidade & ", "                        'Cod Unicidade.
            End If
            lInsert = lInsert & "'" & pstcProposta.RegNumReferencia & "', "                 'Num_Referencia.
            lInsert = lInsert & "'" & pstcProposta.RegNumItem & "', "                       'Num_Item.
            lInsert = lInsert & "'" & pNomArqEnvio & "', "                      'Nom_Arq_Envio.
            lInsert = lInsert & "'" & pDatHorEnvio & "', "                      'Dat_Hor_Envio.
            lInsert = lInsert & "'" & Format$(lNumLinha, "0000") & "', "        'Num_Linha.
            lInsert = lInsert & "'" & gfForAspas(lObservacao) & "')"            'Observacao.
            lPoint = "32"
            If pSohValidacao = True Then
                lPoint = "33"
                DoEvents
            Else
                lPoint = "34"
                If mfExeSQL(pCN, lInsert, lMensagem) <> 0 Then
                    lPoint = "35"
                    Call gpGraLog(0, lMensagem)
                    Call gpFecha2(pCN)
                    End
                End If
                lPoint = "36"
            End If
            lPoint = "37"
            'c) Verifica se ainda precisa gravar registro do tipo P0042901.
            If Not gfPreenchido(lMensagem) Then
                lPoint = "38"
                Exit Do
            End If
            lPoint = "39"
        Loop
        lPoint = "40"
    End If
    
    
SAIDA:
    Err.Clear
    On Error GoTo 0
    Exit Sub
    
TrataErro:
    Call gpGraLog(0, "mpGraRetorno(" & lPoint & "| Arquivo:" & pNomArqEnvio & " ) Erro: " & Err & "-" & Error)
    
End Sub

Public Function gfFase1(ByVal pNomArqEnvio As String, _
                        ByVal pDatHorEnvio As String, _
                        ByVal pTemProtocolo As Boolean, _
                        ByVal pSohValidacao As Boolean, _
                        ByRef pEndCopEntrada As String, _
                        ByRef pNumCopEntrada As Integer, _
                        ByRef pEndArqRetorno As String, _
                        ByRef pNumArqRetorno As Integer, _
                        ByRef pQuaPropostas As Integer, _
                        ByRef pstcProposta As stcA28V300, _
                        ByRef pColProposta As Collection, _
                        ByRef pCN As ADODB.Connection) As Boolean
    'Fun��o: Fase 1 - Processa arquivo de entrada.

Dim lMensagem       As String   'Mensagem.
Dim lPriVez         As Boolean  'Primeira vez.
Dim lRegistro       As String   'Registro.
Dim lTemErro        As Boolean  'Indica que houve erro na proposta.
Dim lTemP0042200    As Boolean  'Indica que tem registro P0042200.
Dim lstcProposta    As stcA28V300
Dim lPoint          As String
Dim lRst            As ADODB.Recordset
Dim lRst2           As ADODB.Recordset
Dim lConexaoEAPDB As ADODB.Connection
Dim lContador       As Integer
Dim lAntNosNumero   As String   'Registro anterior P0042100: nosso n�mero.  ***ANTIGO mAntNosNumero
Dim lTarifaCorte    As Long
Err.Clear
On Error GoTo TrataErro
    
    gfFase1 = False
    '1. Processa arquivo.
    lPriVez = True
'Inicializa a cole��o de propostas a serem processadas
    lPoint = "01"
    
    lTemErro = False
    lTemP0042200 = False
    pQuaPropostas = 0
    
    Do
        lPoint = "02"
        Line Input #pNumCopEntrada, lRegistro
        lPoint = "03"
        If gfPreenchido(lRegistro) Then     'N�o considerar registro em branco.
            lPoint = "04"
            lRegistro = UCase$(Trim(lRegistro))
            Select Case Left$(lRegistro, 8)
                Case "CORRETOR", "USUARIO ", "PROPOSTA", "COTACAO "
                    lPoint = "05"
                    'J� processado na verifica��o do arquivo de transmiss�o.
                Case "P0042100"
                    lPoint = "06"
                    If lPriVez = True Then
                        lPoint = "07"
                        Set pstcProposta = New stcA28V300
                        lPriVez = False
                    Else
                        lPoint = "08"
                        'Se n�o � o primeiro registro e n�o houve erro no registro anterior,
                        'coloca na matriz de propostas o nosso n�mero.
                        If lTemErro = True Then
                            lPoint = "09"
                            Call mpExcRegistros(pSohValidacao, pstcProposta, pCN)
                            lTemErro = False
                        Else
                            lPoint = "10"
                            If lTemP0042200 = True Then
                                lPoint = "11"
                                pQuaPropostas = pQuaPropostas + 1
                                'ReDim Preserve mProposta(pQuaPropostas)
                                'mProposta(pQuaPropostas) = mRegNosNumero
                                Set lstcProposta = New stcA28V300
                                lstcProposta.RegNosNumero = pstcProposta.RegNosNumero
                                lstcProposta.CodUnicidade = pstcProposta.CodUnicidade
                                lstcProposta.TipTransmissao = pstcProposta.TipTransmissao
                                pColProposta.Add lstcProposta   'N�o informar chave... (impossivel controlar o conteudo dos arquivos recebidos pelos corretores, pode haver duplicidade....)
                                lTemP0042200 = False
                            Else
                                lPoint = "12"
                                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                                  pTemProtocolo, "Proposta sem registro de item.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                                Call mpExcRegistros(pSohValidacao, pstcProposta, pCN)
                            End If
                        End If
                    End If
                    lPoint = "13"
                    With pstcProposta
                        .NomArqEnvio = pNomArqEnvio
                        .RegNosNumero = Mid(lRegistro, 9, 20)
                        'Mesmo dado do campo === VM - Custo de emiss�o.
                        'Com mesmo tratamento da fun�ao PosInsert
                        If IsNumeric(Mid$(lRegistro, 704, 11)) Then
                            lPoint = "14"
                            .CodUnicidade = Format$(CDbl(Mid$(lRegistro, 704, 11)) / 100, "standard")
                        Else
                            lPoint = "15"
                            .CodUnicidade = 0
                        End If
                        If InStr(1, pNomArqEnvio, ".P10") Or InStr(1, pNomArqEnvio, ".014") > 0 Then
                            .TipTransmissao = eTipTransmissao_Corretor
                        Else
                            .TipTransmissao = eTipTransmissao_Automatic
                        End If
                        lPoint = "16"
                        .RegNumReferencia = Mid(lRegistro, 29, 6)
                        .RegNomSegurado = Mid(lRegistro, 46, 40) & String(20, " ")
                        .RegDatVigInicio = Mid(lRegistro, 448, 8)
                        .RegDatVigTermino = Mid(lRegistro, 456, 8)
                        .RegAnoFabricacao = "0000"
                        .RegAnoModelo = "0000"
                        .RegCodChassi = String(20, " ")
                        .RegCodChaEstrang = String(20, " ")
                        .RegCodPlaca = String(8, " ")
                        .RegCodVeiculo = String(8, "0")
                        .RegNomVeiculo = String(60, " ")
                        .RegNumItem = "0000"
                        .RegTipEmissao = "000"
                        .RegUsuarioTransm = Mid(lRegistro, 969, 6)
                        .RegCodProduto = Mid(lRegistro, 465, 3)
                        .RegNumPI = Val(Mid(lRegistro, 1001, 10))
                        Set .gCN_DB = pCN
                    End With
                    If mfGraP0042100(pSohValidacao, lRegistro, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "17"
                        lTemErro = True
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                         pTemProtocolo, "Erro ao gravar registro de dados comuns.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                    lPoint = "21"
                    lAntNosNumero = pstcProposta.RegNosNumero
                Case "P0042200"
                    lPoint = "22"
                    With pstcProposta
                    '    .RegNosNumero = *** Usa o mesmo obtido no [Case "P0042100"]
                    '    .CodUnicidade = *** Usa o mesmo obtido no [Case "P0042100"]
                        .RegNumItem = Mid(lRegistro, 29, 4)
                        .RegTipEmissao = Mid(lRegistro, 34, 3)
                        .RegCodVeiculo = Mid(lRegistro, 103, 8)
                        .RegCodPlaca = Mid(lRegistro, 139, 7)
                        .RegCodChassi = Mid(lRegistro, 147, 20)
                        .RegCodChaEstrang = Mid(lRegistro, 167, 20)
                        .RegAnoModelo = Mid(lRegistro, 133, 4)
                        .RegAnoFabricacao = Mid(lRegistro, 129, 4)
                        .RegNomVeiculo = String(60, " ")
                    End With
                    If mfGraP0042200(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "23"
                        lTemErro = True
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro do item.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Else
                        lPoint = "24"
                        lTemP0042200 = True
                    End If
                Case "P0042300"
                    lPoint = "25"
                    If mfGraP0042300(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "26"
                        lTemErro = True
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro de observa��o do item.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                         pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                Case "P0042600"
                    lPoint = "27"
                    If mfGraP0042600(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "28"
                        lTemErro = True
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro de cobertura do item.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                Case "P0042700"
                    lPoint = "29"
                    If mfGraP0042700(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "30"
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro de desconto do item.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                Case "P0042800"
                    lPoint = "31"
                    If InStr(1, gOwner, "ftp_") > 0 Then
                        lPoint = "32"
                    '***Layout desconhecido na transmiss�o
                        'Esta op��o � desnecess�ria, pois isto j� � verificado na fun��o mfVerEntrada.
                        'Se ocorrer erro, encerrar o programa para corre��o.
                        Call gpGraLog(0, "FTE0009 - Registro inv�lido no arquivo " & pEndCopEntrada & _
                                         " (indicador do registro desconhecido)." & vbLf & vbLf & _
                                         vbLf & vbLf & lRegistro)
                    Else
                        lPoint = "33"
                        If mfGraP0042800(pSohValidacao, lRegistro, lAntNosNumero, pCN, lMensagem) = False Then
                            lPoint = "34"
                            Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                              pTemProtocolo, "Erro ao gravar registro de parcela da proposta.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                            Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                              pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                            Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                              pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        End If
                    End If
                Case "TABAJUPR"
                    lPoint = "35"
                    If mfGraTabAjustePremio(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "36"
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro de ajuste de pr�mio.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                Case "P0042601"
                    lPoint = "37"
                    If mfGraP0042601(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "38"
                        lTemErro = True
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro de adicionais.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                Case "HIROTCAL"
                    lPoint = "39"
                    If mfGraTAB_HIST_ROTEIRO_CALCULO(pSohValidacao, lRegistro, lAntNosNumero, pstcProposta, pCN, lMensagem) = False Then
                        lPoint = "40"
                        lTemErro = True
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, "Erro ao gravar registro de hist�rico do roteiro de c�lculo", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, lMensagem, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                        Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro, pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    End If
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                Case Else
                    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                    'lPoint = "37"
                    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                    'lPoint = "39"
                    lPoint = "41"
                    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                    'Esta op��o � desnecess�ria, pois isto j� � verificado na fun��o mfVerEntrada.
                    'Se ocorrer erro, encerrar o programa para corre��o.
                    Call gpGraLog(0, "FTE0009 - Registro inv�lido no arquivo " & pEndCopEntrada & _
                                     " (indicador do registro desconhecido)." & vbLf & vbLf & _
                                     vbLf & vbLf & lRegistro)
            End Select
            'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
            'lPoint = "38"
            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
            'lPoint = "40"
            lPoint = "41"
            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
            'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
            If EOF(pNumCopEntrada) Then
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                'lPoint = "39"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'lPoint = "41"
                lPoint = "42"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                Exit Do
            End If
        End If
        ''CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
        'lPoint = "40"
        'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
        'lPoint = "42"
        lPoint = "43"
        'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
        ''CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    Loop
    lTarifaCorte = 965
    If pSohValidacao Then
        If pstcProposta.RegCodProduto >= lTarifaCorte Then
            gSelect = " exec [dbo].proc_GetProxPI 0"
            
            If Not gfObtRegistro(pCN, gSelect, lRst, lMensagem) Then
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                                  pTemProtocolo, " ===>>> " & lRegistro & ". Erro ao vincular com PI", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
            End If
            If Not lRst.EOF Then
                gInsert = " Insert into dbo.Tab_Vinculo_Proposta_PI (Nosso_Numero, Num_PI, Data , Hora, Usuario) values ( "
                gInsert = gInsert & mfFormatarCamposSQL(pstcProposta.RegNosNumero) & ","
                gInsert = gInsert & mfFormatarCamposSQL(lRst("Num_PI")) & ","
                gInsert = gInsert & " convert(varchar,getdate(),112) ,"
                gInsert = gInsert & " replace(left(convert(varchar,getdate(),114),8),':','') ,"
                gInsert = gInsert & mfFormatarCamposSQL(pstcProposta.RegUsuarioTransm) & ")"
        
                pstcProposta.RegNumPI = lRst("num_pi")
                If gfExeSQL(pCN, gInsert, lMensagem) <> 0 Then
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                                  pTemProtocolo, " ===>>> " & lRegistro & ". Erro ao vincular com PI.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                End If
            Else
                Call gpGraLog(0, "busca PI EOF")
            End If
        End If
    ElseIf pNomArqEnvio Like "*P10" Then
        If pstcProposta.RegCodProduto >= lTarifaCorte Then
             If Not gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, gPWDBasEAPDB, lConexaoEAPDB, lMensagem) Then
               Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                pTemProtocolo, " ===>>> " & lRegistro & ". Erro ao abrir base de dados", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
             End If
            gSelect = " select * from Tab_Vinculo_Proposta_PI where nosso_numero = " & mfFormatarCamposSQL(pstcProposta.RegNosNumero)
            If Not gfObtRegistro(lConexaoEAPDB, gSelect, lRst, lMensagem) Then
                On Error Resume Next
                Shell "net send tjgomes " & App.EXEName & " - ERRO " & gSelect & " - " & lMensagem
                Shell "net send tjgomes " & App.EXEName & " - ERRO " & gSelect & " - " & lMensagem
                On Error GoTo 0
                Call gpGraLog(0, lMensagem)
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                                  pTemProtocolo, " ===>>> " & lRegistro & ". Erro ao vincular com PI", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
            End If
            lContador = 0
            If Not lRst.EOF Then
Retorno:
                gSelect = " exec " & gPropTabelaCorporativo & "proc_StartFluxoEmissaoTransmissao " & mfFormatarCamposSQL(lRst("Nosso_numero")) & "," & lRst("Num_PI")
                If Not gfObtRegistro(pCN, gSelect, lRst2, lMensagem) Then
                    On Error Resume Next
                    Shell "net send tjgomes " & App.EXEName & " - ERRO " & gSelect & " - " & lMensagem
                    Shell "net send tjgomes " & App.EXEName & " - ERRO " & gSelect & " - " & lMensagem
                    On Error GoTo 0
                End If
                lContador = lContador + 1
                If lContador = 10 Then GoTo TrataErro
                If lRst2("Protocolo") = -1 Then GoTo Retorno
            End If
        End If
    ElseIf pNomArqEnvio Like "*014" Then
        If Not gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, gPWDBasEAPDB, lConexaoEAPDB, lMensagem) Then
          Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
           pTemProtocolo, " ===>>> " & lRegistro & ". Erro ao abrir base de dados", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
        End If
        gInsert = " Insert into dbo.Tab_Vinculo_Proposta_PI (Nosso_Numero, Num_PI, Data , Hora, Usuario) values ( "
        gInsert = gInsert & mfFormatarCamposSQL(pstcProposta.RegNosNumero) & ","
        gInsert = gInsert & mfFormatarCamposSQL(pstcProposta.RegNumPI) & ","
        gInsert = gInsert & " convert(varchar,getdate(),112) ,"
        gInsert = gInsert & " replace(left(convert(varchar,getdate(),114),8),':','') ,"
        gInsert = gInsert & mfFormatarCamposSQL(pstcProposta.RegUsuarioTransm) & ")"
        If gfExeSQL(lConexaoEAPDB, gInsert, lMensagem) <> 0 Then
            Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                          pTemProtocolo, " ===>>> " & lRegistro & ". Erro ao vincular com PI.", pstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
        End If
retorno2:
        gSelect = " exec " & gPropTabelaCorporativo & "proc_StartFluxoEmissaoTransmissao " & mfFormatarCamposSQL(pstcProposta.RegNosNumero) & "," & pstcProposta.RegNumPI
        If Not gfObtRegistro(pCN, gSelect, lRst2, lMensagem) Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & gSelect & " - " & lMensagem
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & gSelect & " - " & lMensagem
            On Error GoTo 0
        End If
        lContador = lContador + 1
        If lContador = 10 Then GoTo TrataErro
        If lRst2("Protocolo") = -1 Then GoTo retorno2
    End If
    
    
    'Verifica se �ltima proposta deve ser colocada tamb�m na matriz.
    If Val(pstcProposta.RegNosNumero) <> 0 Then
        'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
        'lPoint = "41"
        lPoint = "42"
        'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
        'Se n�o � o primeiro registro e n�o houve erro no registro anterior,
        'coloca na matriz de propostas o nosso n�mero.
        If lTemErro = True Then
            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
            'lPoint = "42"
            lPoint = "43"
            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
            Call mpExcRegistros(pSohValidacao, pstcProposta, pCN)
            lTemErro = False
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pstcProposta.RegNosNumero
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pstcProposta.RegNosNumero
            On Error GoTo 0
        Else
            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
            'lPoint = "43"
                lPoint = "44"
            'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
            If lTemP0042200 = True Then
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'lPoint = "44"
                lPoint = "45"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                pQuaPropostas = pQuaPropostas + 1
                'ReDim Preserve mProposta(pQuaPropostas)
                'mProposta(pQuaPropostas) = mRegNosNumero
                Set lstcProposta = New stcA28V300
                lstcProposta.NomArqEnvio = pstcProposta.NomArqEnvio
                lstcProposta.RegNosNumero = pstcProposta.RegNosNumero
                lstcProposta.CodUnicidade = pstcProposta.CodUnicidade
                lstcProposta.TipTransmissao = pstcProposta.TipTransmissao
                pColProposta.Add lstcProposta   'N�o informar chave... (impossivel controlar o conteudo dos arquivos recebidos pelos corretores, pode haver duplicidade....)
                lTemP0042200 = False
            Else
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'lPoint = "45"
                lPoint = "46"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                ''Call mpGraRetorno("2", "Proposta sem registro de item.")
                Call mpExcRegistros(pSohValidacao, pstcProposta, pCN)
            End If
        End If
    End If
    
'*** Finalizado com sucesso
    gfFase1 = True
    
SAIDA:
    Err.Clear
    On Error GoTo 0
    Exit Function
    
TrataErro:
    Call gpGraLog(0, "gfFase1(" & lPoint & ") Erro: " & Err & "-" & Error)
    GoTo SAIDA
    
End Function

Private Function mfFase3(ByVal pNomArqEnvio As String, _
                         ByVal pDatHorEnvio As String, _
                         ByVal pSohValidacao As Boolean, _
                         ByRef pEndArqRetorno As String, _
                         ByRef pNumArqRetorno As Integer, _
                         ByRef pQuaPropostas As Integer, _
                         ByRef pColProposta As Collection, _
                         ByRef pCN As ADODB.Connection) As Boolean
    'Fun��o: Fase 3 - Cria arquivo para processamento.

Dim lCalCodVerificacao  As String           'C�digo de verifica��o (calculado).
Dim lCalculo1           As String           'TEMPOR�RIO - c�lculo 1.
Dim lCalculo2           As String           'TEMPOR�RIO - c�lculo 2.
Dim lCalculo3           As String           'TEMPOR�RIO - c�lculo 3.
Dim lCalculo4           As String           'TEMPOR�RIO - c�lculo 4.
Dim lCalculo5           As String           'TEMPOR�RIO - c�lculo 5.
Dim lI                  As Integer          'Utilizado com For...Next.
Dim lMensagem           As String           'Mensagem.
Dim lRegCodVerificacao  As String           'C�digo de verifica��o (do registro).
Dim rsP0042100          As ADODB.Recordset  'Registro: P0042100.
Dim rsP0042200          As ADODB.Recordset  'Registro: P0042200.
Dim rsP0042600          As ADODB.Recordset  'Registro: P0042600.
Dim rsP0042700          As ADODB.Recordset  'Registro: P0042700.
Dim lSelect             As String
Dim lUpdate             As String
Dim lstcProposta        As stcA28V300
Dim lPoint      As String

Err.Clear
On Error GoTo TrataErro

    mfFase3 = False

    lPoint = "01"
    For lI = 1 To pQuaPropostas
        '1. Posiciona informa��es.
        'mRegNosNumero = mProposta(lI)
        lPoint = "02"
        Set lstcProposta = pColProposta(lI)
        lRegCodVerificacao = String(6, "0")

        '2. Processa propostas.
        Do
            'a) Obt�m registro de dados comuns da proposta.
            lPoint = "03"
            lSelect = "SELECT * FROM " & gOwner & "P0042100 WHERE Nosso_Numero = '" & lstcProposta.RegNosNumero & "'"
            If InStr(1, gOwner, "ftp_") > 0 Then
                lSelect = lSelect & " AND Cod_Unicidade = " & lstcProposta.CodUnicidade
            End If
            lPoint = "04"
            If gfObtRegistro(pCN, lSelect, rsP0042100, lMensagem) = False Then
                Call gpGraLog(0, lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
                End
            End If
            lPoint = "05"
            If rsP0042100.EOF = True Then
                lPoint = "06"
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, "Registro de dados comuns n�o localizado.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Exit Do
            End If
    
            'b) Posiciona controles.
            lPoint = "07"
            With lstcProposta
                .RegDatVigInicio = Format$(rsP0042100!Dat_Vig_Inicio, "00000000")
                .RegDatVigTermino = Format$(rsP0042100!Dat_Vig_Termino, "00000000")
                .RegNomSegurado = Left$(Trim$(rsP0042100!NOM_SEGURADO) & Space(60), 60)
                .RegNumReferencia = Format$(rsP0042100!Num_Referencia, "000000")
            End With
            lPoint = "08"
            lRegCodVerificacao = Format$(rsP0042100!Val_Cus_Emis_VM, "000000")

            'c) Obt�m registros dos itens.
            lPoint = "09"
            lSelect = "SELECT * FROM " & gOwner & "P0042200 WHERE Nosso_Numero = '" & lstcProposta.RegNosNumero & "' "
            If InStr(1, gOwner, "ftp_") > 0 Then
                lSelect = lSelect & " AND Cod_Unicidade = " & lstcProposta.CodUnicidade
            End If
            lSelect = lSelect & " ORDER BY Num_Item"
            lPoint = "10"
            If gfObtRegistro(pCN, lSelect, rsP0042200, lMensagem) = False Then
                lPoint = "11"
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, "Erro ao obter registros dos itens da proposta.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Exit Do
            End If

            'd) Obt�m registros de coberturas dos itens.
            lPoint = "12"
            lSelect = "SELECT * FROM " & gOwner & "P0042600 WHERE Nosso_Numero = '" & lstcProposta.RegNosNumero & "' "
            If InStr(1, gOwner, "ftp_") > 0 Then
                lSelect = lSelect & " AND Cod_Unicidade = " & lstcProposta.CodUnicidade
            End If
            lSelect = lSelect & " ORDER BY Num_Item"
            lPoint = "13"
            If gfObtRegistro(pCN, lSelect, rsP0042600, lMensagem) = False Then
                lPoint = "14"
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, "Erro ao obter registros das coberturas dos itens da proposta.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Exit Do
            End If

            'e) Obt�m registros de descontos dos itens.
            lPoint = "15"
            lSelect = "SELECT * FROM " & gOwner & "P0042700 WHERE Nosso_Numero = '" & lstcProposta.RegNosNumero & "' "
            If InStr(1, gOwner, "ftp_") > 0 Then
                lSelect = lSelect & " AND Cod_Unicidade = " & lstcProposta.CodUnicidade
            End If
            lSelect = lSelect & " ORDER BY Num_Item"
            lPoint = "16"
            If gfObtRegistro(pCN, lSelect, rsP0042700, lMensagem) = False Then
                lPoint = "17"
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, "Erro ao obter registros dos descontos dos itens da proposta.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Exit Do
            End If
            lPoint = "18"
            '===>>>   GoTo PULA       'N�O CONSISTIR AINDA UNICIDADE - 12/11/2004.

            'Obs.: O processo de c�lculo do c�digo de unicidade estava com erro, pois n�o estava
            '      considerando 3 informa��es: tipo do documento de identifica��o quando se tratava de
            '      pessoa f�sica, nome do logradouro do endere�o do segurado e nome do logradouro do
            '      endere�o de cobran�a.
            '      Desta forma, o sistema calcula o c�digo de unicidade da forma correta, por�m, se o
            '      c�digo calculado n�o � igual ao c�digo informado, o sistema calcula novamente da forma
            '      incorreta. Neste caso, se o c�digo calculado n�o � igual ao c�digo informado, emite
            '      mensagem de erro. Este processo deve ser exclu�do em fevereiro de 2005, quando todos os
            '      corretores devem estar com o sistema devidamente atualizado.
            
            'f) Calcula e confere c�digo de verifica��o da unicidade do registro.
            If mfCalCodUnicidade(lstcProposta.RegNosNumero, rsP0042100, rsP0042200, _
                                 rsP0042600, rsP0042700, pCN, lCalCodVerificacao, lMensagem) = False Then
                lPoint = "19"
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, "Erro ao calcular c�digo de verifica��o da proposta - " & _
                                       "mfCalCodUnicidade.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Exit Do
            End If
            lPoint = "20"
            'Call mpGraRetorno("2", "C�digo de verifica��o gravado no registro transmitido = " & _
            '                        lRegCodVerificacao)
            'Call mpGraRetorno("2", "C�digo de verifica��o calculado (mfCalCodUnicidade) = " & _
            '                        lCalCodVerificacao)
            If lCalCodVerificacao = lRegCodVerificacao Then         'TEMPOR�RIO.
                GoTo Pula                                           'TEMPOR�RIO.
            End If                                                  'TEMPOR�RIO.
            lCalculo1 = lCalCodVerificacao
            lPoint = "22"
            If lCalCodVerificacao <> lRegCodVerificacao Then
                'Habilitar as linhas abaixo em fevereiro de 2005.   'TEMPOR�RIO.
                'Call mpGraRetorno("2", "C�digo de verifica��o inv�lido.")
                'Call mpGraRetorno("2", "Registro = " & lRegCodVerificacao)
                'Call mpGraRetorno("2", "Calculado = " & lCalCodVerificacao)

                'Obs.: As linhas seguintes dever�o ser exclu�das em fevereiro de 2005.
                lPoint = "23"
                If mfCalCodUniXXXXX1(1, lstcProposta.RegNosNumero, rsP0042100, rsP0042200, _
                                     rsP0042600, rsP0042700, pCN, lCalCodVerificacao, lMensagem) = False Then
                    lPoint = "24"
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, "Erro ao calcular c�digo de verifica��o da proposta - " & _
                                      "mfCalCodUniXXXXX1 - 1.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Exit Do
                End If
                lPoint = "25"
                'Call mpGraRetorno("2", "C�digo de verifica��o calculado (mfCalCodUniXXXXX1 - 1) = " & _
                '                        lCalCodVerificacao)
                If lCalCodVerificacao = lRegCodVerificacao Then
                    GoTo Pula
                End If
                lCalculo2 = lCalCodVerificacao
                lPoint = "26"
                If mfCalCodUniXXXXX1(2, lstcProposta.RegNosNumero, rsP0042100, rsP0042200, _
                                     rsP0042600, rsP0042700, pCN, lCalCodVerificacao, lMensagem) = False Then
                    lPoint = "27"
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, "Erro ao calcular c�digo de verifica��o da proposta - " & _
                                      "mfCalCodUniXXXXX1 - 2.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Exit Do
                End If
                'Call mpGraRetorno("2", "C�digo de verifica��o calculado (mfCalCodUniXXXXX1 - 2) = " & _
                '                        lCalCodVerificacao)
                lPoint = "28"
                If lCalCodVerificacao = lRegCodVerificacao Then
                    GoTo Pula
                End If
                lCalculo3 = lCalCodVerificacao
                lPoint = "29"
                If mfCalCodUniXXXXX2(1, lstcProposta.RegNosNumero, rsP0042100, rsP0042200, _
                                     rsP0042600, rsP0042700, pCN, lCalCodVerificacao, lMensagem) = False Then
                    lPoint = "30"
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, "Erro ao calcular c�digo de verifica��o da proposta - " & _
                                      "mfCalCodUniXXXXX2 - 1.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Exit Do
                End If
                'Call mpGraRetorno("2", "C�digo de verifica��o calculado (mfCalCodUniXXXXX2 - 1) = " & _
                '                        lCalCodVerificacao)
                lPoint = "31"
                If lCalCodVerificacao = lRegCodVerificacao Then
                    GoTo Pula
                End If
                lCalculo4 = lCalCodVerificacao
                lPoint = "32"
                If mfCalCodUniXXXXX2(2, lstcProposta.RegNosNumero, rsP0042100, rsP0042200, _
                                     rsP0042600, rsP0042700, pCN, lCalCodVerificacao, lMensagem) = False Then
                    lPoint = "33"
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, "Erro ao calcular c�digo de verifica��o da proposta - " & _
                                      "mfCalCodUniXXXXX2 - 2.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                      lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                    Exit Do
                End If
                'Call mpGraRetorno("2", "C�digo de verifica��o calculado (mfCalCodUniXXXXX2 - 2) = " & _
                '                        lCalCodVerificacao)
                lPoint = "34"
                If lCalCodVerificacao = lRegCodVerificacao Then
                    GoTo Pula
                End If
        '***** - Inibido divergencias no codigo de verifica��o. ABAIXO
            '23/02/05
                lPoint = "35"
                lCalculo5 = lCalCodVerificacao
'                Call mpGraRetorno("2", "C�digo de verifica��o inv�lido.")
'                Call mpGraRetorno("2", "Registro = " & lRegCodVerificacao & ".")
'                'Call mpGraRetorno("2", "Calculado = " & lCalCodVerificacao)
'                Call mpGraRetorno("2", "Calculado = " & lCalculo1 & "/" & lCalculo2 & "/" & lCalculo3 & _
'                                       "/" & lCalculo4 & "/" & lCalculo5 & ".")
'                Exit Do
        '***** - Inibido divergencias no codigo de verifica��o. ACIMA
                'Obs.: As linhas acima dever�o ser exclu�das em fevereiro de 2005.

            End If

Pula:       'TEMPOR�RIO.

            'g) Grava registro de dados comuns.
            lPoint = "36"
            rsP0042100.MoveFirst
            'If mfRegDT1101D_Comum(rsP0042100, rsP0042200, rsP0042600, lMensagem) = False Then
            '    Call mpGraRetorno("2", "Erro ao transferir o registro de dados comuns da proposta " & _
            '                           "para o sistema.")
            '    Call mpGraRetorno("2", lMensagem)
            '    Exit Do
            'End If

            'h) Grava registros de itens.
            lPoint = "37"
            rsP0042200.MoveFirst
            lPoint = "38"
            While Not rsP0042200.EOF
                lPoint = "39"
                With lstcProposta
                    .RegAnoFabricacao = Format$(rsP0042200!Ano_Fabricacao, "0000")
                    .RegAnoModelo = Format$(rsP0042200!Ano_Modelo, "0000")
                    .RegCodChassi = rsP0042200!Cod_Chassi
                    .RegCodChaEstrang = rsP0042200!Cod_Chassi_Estrang
                    .RegCodChaEstrang = Left$(.RegCodChaEstrang & Space(20), 20)
                    .RegCodPlaca = rsP0042200!Cod_Placa
                    .RegCodVeiculo = rsP0042200!Cod_Veiculo
                    .RegNomVeiculo = String(60, " ")
                    .RegNumItem = Format$(rsP0042200!Num_Item, "0000")
                    .RegTipEmissao = Format$(rsP0042200!Tip_Emissao, "000")
                End With
                lPoint = "40"
                'If mfRegDT1101D_Item(rsP0042100, rsP0042200, rsP0042600, rsP0042700, lMensagem) = False _
                '   Then
                '    Call mpGraRetorno("2", "Erro ao transferir os registros dos itens da proposta " & _
                '                           "para o sistema.")
                '    Call mpGraRetorno("2", lMensagem)
                '    Exit Do
                'End If
                'Desabilitado temporariamente. (24/02/05 - Shiba)
                'If mfVerNormas(rsP0042100, rsP0042200, rsP0042600, rsP0042700, lMensagem) = False Then
                '    Call mpGraRetorno("2", "Erro ao verificar normas de aceita��o.")
                '    Call mpGraRetorno("2", lMensagem)
                '    Exit Do
                'End If
                rsP0042200.MoveNext
            Wend
            lPoint = "41"
            'i) Atualiza o controle do registro processado.
            lUpdate = "UPDATE " & gOwner & "P0042100 SET Sit_Processamento = 1 WHERE Nosso_Numero = '" & _
                      lstcProposta.RegNosNumero & "' "
            If InStr(1, gOwner, "ftp_") > 0 Then
                lUpdate = lUpdate & " AND Cod_Unicidade = " & lstcProposta.CodUnicidade
            End If
            lPoint = "42"
            If mfExeSQL(pCN, lUpdate, lMensagem) <> 0 Then
                lPoint = "43"
                With lstcProposta
                    .RegAnoFabricacao = "0000"
                    .RegAnoModelo = "0000"
                    .RegCodChassi = String(" ", 20)
                    .RegCodChaEstrang = String(" ", 20)
                    .RegCodPlaca = String(" ", 8)
                    .RegCodVeiculo = String("0", 8)
                    .RegNomVeiculo = String(" ", 60)
                    .RegNumItem = "0000"
                    .RegTipEmissao = "000"
                End With
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, "Erro ao atualizar controle do registro processado.", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "2", _
                                  lstcProposta.gTemProtocolo, lMensagem, lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
                Exit Do
            End If
            lPoint = "44"
            'j) Grava registro de retorno - registro encaminhado para processamento.
            If gfPreenchido(pEndArqRetorno) = True Then
            Call mpGraRetorno(pNomArqEnvio, pDatHorEnvio, pSohValidacao, "1", lstcProposta.gTemProtocolo, " ", lstcProposta, pEndArqRetorno, pNumArqRetorno, pCN)
            End If
            Exit Do
        Loop
        lPoint = "45"
    Next lI
        lPoint = "46"
    mfFase3 = True
    
SAIDA:
    Err.Clear
    On Error GoTo 0
    Exit Function
    
TrataErro:
    Call gpGraLog(0, "mfFase3(" & lPoint & "| Arquivo:" & pNomArqEnvio & " ) Erro: " & Err & "-" & Error)
    GoTo SAIDA
    
End Function

Private Function mfPosInsert(ByVal pOpcao As Byte, ByVal pNomCampo As String, _
                             ByVal pRegistro As String, ByVal pPosInicial As Integer, _
                             ByVal pTamanho As Integer, ByRef pInsert As String, _
                             ByRef pMensagem As String) As Boolean
    'Fun��o: posiciona campo no comando INSERT.

    'Par�metros de entrada...pOpcao........1 = campo num�rico - consiste e emite mensagem.
    '                                      2 = campo num�rico - preenche com zero se registro incompleto
    '                                          ou campo n�o num�rico.
    '                                      3 = indicador (S ou N).
    '                                      4 = campo alfanum�rico.
    '                                      5 = campo num�rico - preenche com zero se registro incompleto
    '                                          ou campo n�o num�rico - considera 2 casas decimais.
    '                                      6 = campo alfanum�rico com conte�do num�rico - consiste e
    '                                          emite mensagem.
    '                        pNomCampo.....Nome do campo.
    '                        pRegistro.....Registro de entrada.
    '                        pPosInicial...Posi��o inicial do campo no registro de entrada.
    '                        pTamanho......Tamanho do campo no registro de entrada.
    'Par�metros de sa�da.....pInsert.......Comando INSERT.
    '                        pMensagem.....Mensagem.

    Dim lAuxiliar   As String       'Auxiliar.

    mfPosInsert = False

    Select Case pOpcao
        Case 1  'Campo num�rico - consiste e emite mensagem.
            If Len(Trim(pRegistro)) < pPosInicial Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " n�o preenchido(a)."
                Exit Function
            End If
            If Len(Trim(pRegistro)) < (pPosInicial + pTamanho - 1) Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " incompleto(a)."
                Exit Function
            End If
            If Not IsNumeric(Mid$(pRegistro, pPosInicial, pTamanho)) Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " n�o num�rico(a)."
                Exit Function
            End If
            pInsert = pInsert & Mid$(pRegistro, pPosInicial, pTamanho) & ", "
            Debug.Print pNomCampo & " = " & Mid$(pRegistro, pPosInicial, pTamanho)
        Case 2  'Campo num�rico - coloca zero se campo n�o preenchido ou n�o num�rico.
            If Len(Trim(pRegistro)) < (pPosInicial + pTamanho - 1) Then
                pInsert = pInsert & "0, "
                Debug.Print pNomCampo & " = 0 "
            Else
                If IsNumeric(Mid$(pRegistro, pPosInicial, pTamanho)) Then
                    pInsert = pInsert & Mid$(pRegistro, pPosInicial, pTamanho) & ", "
                    Debug.Print pNomCampo & " = " & Mid$(pRegistro, pPosInicial, pTamanho)
                Else
                    pInsert = pInsert & "0, "
                    Debug.Print pNomCampo & " = 0"
                End If
            End If
        Case 3  'Indicador (S ou N).
            If pTamanho <> 1 Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " com tamanho diferente de 1."
                Exit Function
            End If
            If Len(Trim(pRegistro)) < pPosInicial Then
                pInsert = pInsert & "'S', "
                Debug.Print pNomCampo & " = S"
            Else
                pInsert = pInsert & "'" & Mid$(pRegistro, pPosInicial, 1) & "', "
                Debug.Print pNomCampo & " = " & Mid$(pRegistro, pPosInicial, 1)
            End If
        Case 4  'Campo alfanum�rico.
            Select Case Len(Trim(pRegistro))
                Case Is < pPosInicial
                    pInsert = pInsert & "'', "
                    Debug.Print pNomCampo & " = ''"
                Case Else 'pPosInicial To (pPosInicial + pTamanho)
                    'pInsert = pInsert & "'" & gfForAspas(Mid$(pRegistro, pPosInicial)) & "', "
                    'Debug.Print pNomCampo & " = " & gfForAspas(Mid$(pRegistro, pPosInicial))
                'Case Is > (pPosInicial + pTamanho)
                    pInsert = pInsert & "'" & gfForAspas(Mid$(pRegistro, pPosInicial, pTamanho)) & "', "
                    Debug.Print pNomCampo & " = " & gfForAspas(Mid$(pRegistro, pPosInicial, pTamanho))
            End Select
        Case 5  'Campo num�rico - considera 2 casas decimais.
            If Len(Trim(pRegistro)) < (pPosInicial + pTamanho - 1) Then
                pInsert = pInsert & "0, "
                Debug.Print pNomCampo & " = 0"
            Else
                If IsNumeric(Mid$(pRegistro, pPosInicial, pTamanho)) Then
                    lAuxiliar = Format$(CDbl(Mid$(pRegistro, pPosInicial, pTamanho)) / 100, "standard")
                    pInsert = pInsert & gfForValor(1, lAuxiliar) & ", "
                    Debug.Print pNomCampo & " = " & gfForValor(1, lAuxiliar)
                Else
                    pInsert = pInsert & "0, "
                    Debug.Print pNomCampo & " = 0"
                End If
            End If
        Case 6  'Campo alfanum�rico com conte�do num�rico - consiste e emite mensagem.
            If Len(Trim(pRegistro)) < pPosInicial Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " n�o preenchido(a)."
                Exit Function
            End If
            If Len(Trim(pRegistro)) < (pPosInicial + pTamanho - 1) Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " incompleto."
                Exit Function
            End If
            If Not IsNumeric(Mid$(pRegistro, pPosInicial, pTamanho)) Then
                pMensagem = "Registro desconsiderado. " & pNomCampo & " n�o num�rico."
                Exit Function
            End If
            pInsert = pInsert & "'" & Mid$(pRegistro, pPosInicial, pTamanho) & "', "
            Debug.Print pNomCampo & " = " & Mid$(pRegistro, pPosInicial, pTamanho)
        Case 7  'Campo CNPJ/CPF: aceita numerico ou alfanumerico, insere como string.
            If Len(Trim(pRegistro)) < (pPosInicial + pTamanho - 1) Then
                pInsert = pInsert & "'" & String(pTamanho, "0") & "', "
                Debug.Print pNomCampo & " = '" & String(pTamanho, "0") & "'"
            Else
                lAuxiliar = Trim$(Mid$(pRegistro, pPosInicial, pTamanho))
                If IsNumeric(lAuxiliar) Then
                    lAuxiliar = Right$(String(pTamanho, "0") & lAuxiliar, pTamanho)
                Else
                    lAuxiliar = Left$(lAuxiliar & Space(pTamanho), pTamanho)
                End If
                pInsert = pInsert & "'" & lAuxiliar & "', "
                Debug.Print pNomCampo & " = '" & lAuxiliar & "'"
            End If
    End Select

    mfPosInsert = True
End Function

Private Function mfGraP0042100(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042100 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lCodCorretor    As String   'C�digo do corretor.
Dim lCodProduto     As Integer  'C�digo do produto.
Dim lPosInicial     As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho        As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert         As String

    mfGraP0042100 = False

    '1. Verifica nosso n�mero e refer�ncia.
    If Not gfPreenchido(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro de dados comuns."
        Exit Function
    End If
    If Not IsNumeric(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro de dados comuns."
        Exit Function
    End If
    If Len(Trim(pstcProposta.RegNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro de dados " & _
                    "comuns."
        Exit Function
    End If
    If Not gfPreenchido(pstcProposta.RegNumReferencia) Then
        pMensagem = "Refer�ncia n�o preenchida."
        Exit Function
    End If
    If Not IsNumeric(pstcProposta.RegNumReferencia) Then
        pMensagem = "Refer�ncia n�o num�rica."
        Exit Function
    End If
    If Len(Trim(pstcProposta.RegNumReferencia)) <> 6 Then
        pMensagem = "Refer�ncia inv�lida - tamanho diferente de 6 posi��es."
        Exit Function
    End If

    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042100 (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
        lInsert = lInsert & " Tip_Transmissao, "
    End If
    lInsert = lInsert & " Num_Referencia, Cod_Ativo, Tip_Documento, " & _
              "Sit_Documento, Sit_Processamento, Cod_Segurado, Nom_Segurado, Tip_Pessoa, CNPJ_CPF, " & _
              "End_Tip_Logradouro, End_Nom_Logradouro, End_Complemento, End_Bairro, End_Cidade, " & _
              "End_UF, End_CEP, End_Telefones, Cob_Diferente, Cob_Tip_Logradouro, " & _
              "Cob_Nom_Logradouro, Cob_Complemento, Cob_Bairro, Cob_Cidade, Cob_UF, Cob_CEP, "
                
              'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Fevereiro\2014
              'Cod_Produto passou a ser o �ltimo campo no arquivo e a ter 4 D�gitos
              
              '"Cob_Telefones, Dat_Vig_Inicio, Dat_Vig_Termino, Prazo_Iden, Cod_Produto, "
    lInsert = lInsert & " Cob_Telefones, Dat_Vig_Inicio, Dat_Vig_Termino, Prazo_Iden, " & _
              "Cod_Protocolo, Cod_Sequencia, Qtd_Itens, Pag_Ant_Ind, Pag_Ant_Chq_Banco, " & _
              "Pag_Ant_Chq_Agenc, Pag_Ant_Chq_Conta, Pag_Ant_Chq_Numero, Pag_Ant_Bloqueto, " & _
              "Pag_Ant_Valor, For_Pagamento, Carne_Cod_Banco, Deb_Cod_Banco, Deb_Cod_Agencia, " & _
              "Deb_Cod_Conta, Deb_Dia, Ind_Ajuste, Cor1_Codigo, Cor1_Cms_Casco, Cor1_Cms_RC, " & _
              "Cor1_Cms_APP, Cor2_Codigo, Cor2_Cms_Casco, Cor2_Cms_RC, Cor2_Cms_APP, Cor3_Codigo, " & _
              "Cor3_Cms_Casco, Cor3_Cms_RC, Cor3_Cms_APP, Per_Cms_Cotacao, Cod_Unid_Prod, " & _
              "Cod_Produtor, Ind_Cosseguro, Cos1_Codigo, Cos1_Percentual, Cos2_Codigo, " & _
              "Cos2_Percentual, Cos3_Codigo, Cos3_Percentual, Cos4_Codigo, Cos4_Percentual, " & _
              "Cos5_Codigo, Cos5_Percentual, Ind_Cod_Banco, Ind_Cod_Agencia, Ind_Cod_Conta, " & _
              "Cus_Emissao, Cus_Emi_Parcelado, Cod_Registro, Dat_Emissao, Val_Pre_Liquido_VM, " & _
              "Val_Cus_Emis_VM, Val_IOF_VM, Tip_Pre_Min_Endo_VM, Tip_Pre_Min_Parc_VM, " & _
              "Qtd_Parcelas_VM, Per_Juros_VM, Ven_Parcela1_VM, Val_Parcela1_VM, Val_Parcelas_VM, " & _
              "Val_Pre_Liquido_VD, Val_Cus_Emis_VD, Val_IOF_VD, Tip_Pre_Min_Endo_VD, " & _
              "Tip_Pre_Min_Parc_VD, Qtd_Parcelas_VD, Per_Juros_VD, Ven_Parcela1_VD, Val_Parcela1_VD, " & _
              "Val_Parcelas_VD, Atu_Num_Apolice, Num_Endosso, Jur_Ant_01, Jur_Ant_02, Jur_Ant_03, " & _
              "Jur_Ant_04, Jur_Ant_05, Jur_Ant_06, Jur_Ant_07, Jur_Ant_08, Jur_Ant_09, Jur_Ant_10, " & _
              "Jur_Ant_11, Jur_Ant_12, Jur_Pos_01, Jur_Pos_02, Jur_Pos_03, Jur_Pos_04, Jur_Pos_05, " & _
              "Jur_Pos_06, Jur_Pos_07, Jur_Pos_08, Jur_Pos_09, Jur_Pos_10, Jur_Pos_11, Jur_Pos_12, "
              
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Fevereiro\2014
    lInsert = lInsert & "Dat_Alt, Cod_User_Alt, Cod_Usu_Transmissao, Ind_CondGerais, Ind_Reentrada, " & _
                "Nosso_Numero_Original,Ind_FinanciadoBco,Ind_Funcionario,Num_Matricula, "

        'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Fevereiro\2014
    lInsert = lInsert & " Ind_PEP, Cod_Cargo_PEP, Cod_Iden_Estado_Civil, Email, Score, Valor_Verba_Comercial, " & _
                        " Cod_Empresa, Ind_Cob_Provisoria, Dat_Solic_Cob_Prov, Cod_Produto, " & _
                        " Ind_ClienteFoco, Ind_FuncionarioFoco, Ind_ExCliente, Cod_Grupo_Seg ) VALUES ("
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Fevereiro\2014
    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    'Inclus�o dos campos: Cliente foco, Funcion�rio foco, Ex Cliente
    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    
    '=== Nosso n�mero - Nosso_Numero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function
    End If

    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
        lInsert = lInsert & pstcProposta.TipTransmissao & " , "
    End If
    
    '=== Refer�ncia - Num_Referencia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 6
    If mfPosInsert(1, "N�mero de refer�ncia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function
    End If

    '=== Indicador de ativo - Cod_Ativo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(3, "Indicador de ativo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function
    End If

    '=== Tipo do documento - Tip_Documento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo do documento", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function
    End If

    '=== Situa��o do documento - Sit_Documento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Situa��o do documento", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function
    End If

    '=== Situa��o do processamento - Sit_Processamento (sempre dever ser zero).
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    lInsert = lInsert & "0, "

    '=== C�digo do segurado - Cod_Segurado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(4, "C�digo do segurado", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function
    End If

    '=== Nome do segurado - Nom_Segurado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 40
    If mfPosInsert(4, "Nome do segurado", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function
    End If

    '=== Tipo de pessoa.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo de pessoa", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Tip_Pessoa.
    End If

    '=== CNPJ/CPF.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    'mobjstcTabCotacao.NUMDOCTOSEG = Mid(pRegistro, lPosInicial, lTamanho)
    If mfPosInsert(7, "CNPJ/CPF", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'CNPJ_CPF.
    End If

    '=== Endere�o do segurado - tipo do logradouro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(4, "Endere�o do segurado - tipo do logradouro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'End_Tip_Logradouro.
    End If

    '=== Endere�o do segurado - nome do logradouro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 50
    If mfPosInsert(4, "Endere�o do segurado - nome do logradouro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'End_Nom_Logradouro.
    End If

    '=== Endere�o do segurado - complemento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "Endere�o do segurado - complemento", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'End_Complemento.
    End If

    '=== Endere�o do segurado - bairro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Endere�o do segurado - bairro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'End_Bairro.
    End If

    '=== Endere�o do segurado - cidade.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Endere�o do segurado - bairro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'End_Cidade.
    End If

    '=== Endere�o do segurado - unidade da federa��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(4, "Endere�o do segurado - unidade da federa��o", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'End_UF.
    End If

    '=== Endere�o do segurado - CEP.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Endere�o do segurado - CEP", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'End_CEP.
    End If

    '=== Endere�o do segurado - telefones.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Endere�o do segurado - telefones", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'End_Telefones.
    End If

    '=== Indicador de endere�o de cobran�a diferente.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de endere�o de cobran�a diferente", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cob_Diferente.
    End If

    '=== Endere�o de cobran�a - tipo do logradouro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(4, "Endere�o de cobran�a - tipo do logradouro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cob_Tip_Logradouro.
    End If

    '=== Endere�o de cobran�a - nome do logradouro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 50
    If mfPosInsert(4, "Endere�o de cobran�a - nome do logradouro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cob_Nom_Logradouro.
    End If

    '=== Endere�o de cobran�a - complemento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "Endere�o de cobran�a - complemento", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cob_Complemento.
    End If

    '=== Endere�o de cobran�a - bairro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Endere�o de cobran�a - bairro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cob_Bairro.
    End If

    '=== Endere�o de cobran�a - cidade.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Endere�o de cobran�a - bairro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cob_Cidade.
    End If

    '=== Endere�o de cobran�a - unidade da federa��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(4, "Endere�o de cobran�a - unidade da federa��o", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cob_UF.
    End If

    '=== Endere�o de cobran�a - CEP.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Endere�o de cobran�a - CEP", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cob_CEP.
    End If

    '=== Endere�o de cobran�a - telefones.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Endere�o de cobran�a - telefones", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cob_Telefones.
    End If

    '=== In�cio de vig�ncia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "In�cio de vig�ncia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Dat_Vig_Inicio.
    End If

    '=== T�rmino de vig�ncia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "T�rmino de vig�ncia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Dat_Vig_Termino.
    End If

    '=== Tipo do prazo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo do prazo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Prazo_Iden.
    End If
    
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Fevereiro\2014
    'Cod_Produto passou a ser o �ltimo campo no arquivo e a ter 4 D�gitos
    'Mant�m linhas de posicionamento para n�o inviabilizar a leitura correta da linha do arquivo
'    '=== C�digo do produto.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    
'    If mfPosInsert(2, "C�digo do produto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
'       Then
'        Exit Function                                                           'Cod_Produto.
'    End If
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Fevereiro\2014
    
    '=== C�digo do protocolo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If Len(pRegistro) >= 1014 Then
        If mfPosInsert(2, "C�digo do protocolo", pRegistro, 1014, 7, lInsert, pMensagem) = _
            False Then
            Exit Function                                                           'Cod_Protocolo.
        End If
    ElseIf Mid(pRegistro, lPosInicial, 3) = 493 Then
        lInsert = lInsert & "49301, "
    Else
        If mfPosInsert(2, "C�digo do protocolo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
            False Then
            Exit Function                                                           'Cod_Protocolo.
        End If
    End If

    '=== C�digo da seq��ncia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da seq��ncia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Sequencia.
    End If

    '=== Quantidade de itens.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "Quantidade de itens", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Qtd_Itens.
    End If

    '=== Indicador de pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de pagamento antecipado", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Ind.
    End If

    '=== C�digo do banco do cheque do pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do banco do cheque do pagamento antecipado", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Chq_Banco.
    End If

    '=== C�digo da ag�ncia do cheque do pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo da ag�ncia do cheque do pagamento antecipado", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Chq_Agenc.
    End If

    '=== C�digo da conta do cheque do pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(2, "C�digo da conta do cheque do pagamento antecipado", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Chq_Conta.
    End If

    '=== N�mero do cheque do pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 6
    If mfPosInsert(2, "N�mero do cheque do pagamento antecipado", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Chq_Numero.
    End If

    '=== N�mero do bloqueto do pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "N�mero do bloqueto do pagamento antecipado", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Bloqueto.
    End If

    '=== Valor do pagamento antecipado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 9
    If mfPosInsert(5, "Valor do pagamento antecipado", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pag_Ant_Valor.
    End If

    '=== Forma de pagamento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Forma de pagamento", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'For_Pagamento.
    End If

    '=== C�digo do banco para carn�.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do banco para carn�", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Carne_Cod_Banco.
    End If

    '=== C�digo do banco para d�bito em conta.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do banco para d�bito em conta", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Deb_Cod_Banco.
    End If

    '=== C�digo da ag�ncia para d�bito em conta.
    'lCodCorretor = Format(Mid(lNosNumero, 13, 7), "0000000")
    'lPosCorretor = InStr(29, pRegistro, lCodCorretor, 1)
    'If lPosCorretor = 547 Then
    '    lTamanho = 4
    'ElseIf lPosCorretor = 548 Then
    lCodProduto = Format(Mid(pRegistro, 465, 3), "000")
    lPosInicial = lPosInicial + lTamanho
    'If lCodProduto >= 870 Then
        lTamanho = 5
    'Else
        'lTamanho = 4
    'End If
    If mfPosInsert(2, "C�digo da ag�ncia para d�bito em conta", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Deb_Cod_Agencia.
    End If

    '=== C�digo da conta para d�bito em conta.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(2, "C�digo da ag�ncia para d�bito em conta", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Deb_Cod_Conta.
    End If

    '=== Dia para d�bito em conta.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Dia para d�bito em conta", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Deb_Dia.
    End If

    '=== Indicador de ajuste.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de ajuste", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Ajuste.
    End If

    '=== C�digo do corretor 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(2, "C�digo do corretor 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cor1_Codigo.
    End If

    '=== Comiss�o de casco do corretor 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de casco do corretor 1", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor1_Cms_Casco.
    End If

    '=== Comiss�o de RC do corretor 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de RC do corretor 1", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor1_Cms_RC.
    End If

    '=== Comiss�o de APP do corretor 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de APP do corretor 1", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor1_Cms_APP.
    End If

    '=== C�digo do corretor 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(2, "C�digo do corretor 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cor2_Codigo.
    End If

    '=== Comiss�o de casco do corretor 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de casco do corretor 2", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor2_Cms_Casco.
    End If

    '=== Comiss�o de RC do corretor 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de RC do corretor 2", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor2_Cms_RC.
    End If

    '=== Comiss�o de APP do corretor 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de APP do corretor 2", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor2_Cms_APP.
    End If

    '=== C�digo do corretor 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(2, "C�digo do corretor 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cor3_Codigo.
    End If

    '=== Comiss�o de casco do corretor 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de casco do corretor 3", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor3_Cms_Casco.
    End If

    '=== Comiss�o de RC do corretor 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de RC do corretor 3", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor3_Cms_RC.
    End If

    '=== Comiss�o de APP do corretor 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de APP do corretor 3", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cor3_Cms_APP.
    End If

    '=== Comiss�o de cota��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Comiss�o de cota��o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Per_Cms_Cotacao.
    End If

    '=== C�digo da unidade produtica.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo da unidade produtica", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Unid_Prod.
    End If

    '=== C�digo do produtor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo do produtor", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Produtor.
    End If

    '=== Indicador de cosseguro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de cosseguro", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Cosseguro.
    End If

    '=== C�digo da cosseguradora 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da cosseguradora 1", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cos1_Codigo.
    End If

    '=== Percentual da cosseguradora 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual da cosseguradora 1", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cos1_Percentual.
    End If

    '=== C�digo da cosseguradora 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da cosseguradora 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cos2_Codigo.
    End If

    '=== Percentual da cosseguradora 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual da cosseguradora 2", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cos2_Percentual.
    End If

    '=== C�digo da cosseguradora 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da cosseguradora 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cos3_Codigo.
    End If

    '=== Percentual da cosseguradora 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual da cosseguradora 3", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cos3_Percentual.
    End If

    '=== C�digo da cosseguradora 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da cosseguradora 4", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cos4_Codigo.
    End If

    '=== Percentual da cosseguradora 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual da cosseguradora 4", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cos4_Percentual.
    End If

    '=== C�digo da cosseguradora 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da cosseguradora 5", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cos5_Codigo.
    End If

    '=== Percentual da cosseguradora 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual da cosseguradora 5", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cos5_Percentual.
    End If

    '=== C�digo do banco do indicador do seguro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do banco do indicador do seguro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Ind_Cod_Banco.
    End If

    '=== C�digo da ag�ncia do indicador do seguro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo da ag�ncia do indicador do seguro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Ind_Cod_Agencia.
    End If

    '=== C�digo da conta do indicador do seguro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(2, "C�digo da conta do indicador do seguro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Ind_Cod_Conta.
    End If

    '=== Custo de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 9
    If mfPosInsert(5, "Custo de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cus_Emissao.
    End If

    '=== Indicador de custo de emiss�o parcelado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de custo de emiss�o parcelado", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cus_Emi_Parcelado.
    End If

    '=== C�digo de registro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo de registro", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Registro.
    End If

    '=== Data de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Data de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Dat_Emissao.
    End If

    '=== VM - Pr�mio l�quido.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio l�quido", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Pre_Liquido_VM.
    End If

    '=== VM - Custo de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Custo de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Cus_Emis_VM.
    End If

    '=== VM - IOF.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - IOF", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Val_IOF_VM.
    End If

    '=== VM - Indicador de pr�mio m�nimo de endosso.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "VM - Indicador de pr�mio m�nimo de endosso", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Tip_Pre_Min_Endo_VM.
    End If

    '=== VM - Indicador de pr�mio m�nimo de parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "VM - Indicador de pr�mio m�nimo de parcela", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Tip_Pre_Min_Parc_VM.
    End If

    '=== VM - Quantidade de parcelas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "VM - Quantidade de parcelas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Qtd_Parcelas_VM.
    End If

    '=== VM - Percentual de juros.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "VM - Percentual de juros", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Per_Juros_VM.
    End If

    '=== VM - Vencimento da primeira parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "VM - Vencimento da primeira parcela", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Ven_Parcela1_VM.
    End If

    '=== VM - Valor da primeira parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Valor da primeira parcela", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Parcela1_VM.
    End If

    '=== VM - Valor das demais parcelas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Valor das demais parcelas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Parcelas_VM.
    End If

    '=== VD - Pr�mio l�quido.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio l�quido", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Pre_Liquido_VD.
    End If

    '=== VD - Custo de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Custo de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Cus_Emis_VD.
    End If

    '=== VD - IOF.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - IOF", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Val_IOF_VD.
    End If

    '=== VD - Indicador de pr�mio m�nimo de endosso.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "VD - Indicador de pr�mio m�nimo de endosso", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Tip_Pre_Min_Endo_VD.
    End If

    '=== VD - Indicador de pr�mio m�nimo de parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "VD - Indicador de pr�mio m�nimo de parcela", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Tip_Pre_Min_Parc_VD.
    End If

    '=== VD - Quantidade de parcelas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "VD - Quantidade de parcelas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Qtd_Parcelas_VD.
    End If

    '=== VD - Percentual de juros.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "VD - Percentual de juros", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Per_Juros_VD.
    End If

    '=== VD - Vencimento da primeira parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "VD - Vencimento da primeira parcela", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Ven_Parcela1_VD.
    End If

    '=== VD - Valor da primeira parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Valor da primeira parcela", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Parcela1_VD.
    End If

    '=== VD - Valor das demais parcelas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Valor das demais parcelas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Parcelas_VD.
    End If

    '=== N�mero da ap�lice atual.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(2, "N�mero da ap�lice atual", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Atu_Num_Apolice.
    End If

    '=== N�mero do endosso.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 6
    If mfPosInsert(4, "N�mero do endosso", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Num_Endosso.
    End If

    '=== Juro antecipado 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_01.
    End If

    '=== Juro antecipado 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_02.
    End If

    '=== Juro antecipado 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_03.
    End If

    '=== Juro antecipado 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 4", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_04.
    End If

    '=== Juro antecipado 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 5", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_05.
    End If

    '=== Juro antecipado 6.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 6", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_06.
    End If

    '=== Juro antecipado 7.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 7", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_07.
    End If

    '=== Juro antecipado 8.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 8", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_08.
    End If

    '=== Juro antecipado 9.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 9", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Jur_Ant_09.
    End If

    '=== Juro antecipado 10.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 10", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Ant_10.
    End If

    '=== Juro antecipado 11.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 11", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Ant_11.
    End If

    '=== Juro antecipado 12.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro antecipado 12", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Ant_12.
    End If

    '=== Juro postecipado 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_01.
    End If

    '=== Juro postecipado 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_02.
    End If

    '=== Juro postecipado 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_03.
    End If

    '=== Juro postecipado 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 4", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_04.
    End If

    '=== Juro postecipado 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 5", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_05.
    End If

    '=== Juro postecipado 6.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 6", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_06.
    End If

    '=== Juro postecipado 7.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 7", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_07.
    End If

    '=== Juro postecipado 8.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 8", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_08.
    End If

    '=== Juro postecipado 9.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 9", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_09.
    End If

    '=== Juro postecipado 10.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 10", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_10.
    End If

    '=== Juro postecipado 11.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 11", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_11.
    End If

    '=== Juro postecipado 12.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Juro postecipado 12", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Jur_Pos_12.
    End If

    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If

    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If

    '=== C�digo do usu�rio de transmiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(4, "C�digo do usu�rio de transmiss�o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Usu_Transmissao.
    End If
    If Len(pRegistro) >= 979 Then
        lPosInicial = lPosInicial + lTamanho
        lTamanho = 1
        If mfPosInsert(2, "Cod Gerais", pRegistro, lPosInicial, lTamanho, lInsert, _
           pMensagem) = False Then
            Exit Function                                                           'Ind_CondGerais
        End If
    Else
        lInsert = lInsert & "1, "
    End If
    
    If Len(pRegistro) > 979 Then
        lPosInicial = lPosInicial + lTamanho
        lTamanho = 1
        If mfPosInsert(2, "Ind Reentrada", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
             Exit Function                                                           'Ind_Reentrada
        End If
    Else
        lInsert = lInsert & "2, "
    End If
    
    If Len(pRegistro) >= 981 Then
        lPosInicial = lPosInicial + lTamanho
        lTamanho = 20
        If mfPosInsert(4, "Nosso_Numero_Original", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
             Exit Function                                                           'Nosso_Numero_Original
        End If
    Else
        lInsert = lInsert & "'', "
    End If
    
    lPosInicial = lPosInicial + lTamanho
    'pi E LOTE
    lTamanho = 13
    lPosInicial = lPosInicial + lTamanho
    
    'cod_protocolo
    lTamanho = 7
    If Len(pRegistro) >= 1021 Then
        lPosInicial = lPosInicial + lTamanho
        lTamanho = 2
        If mfPosInsert(2, "Ind_FinanciadoBco", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
             Exit Function                                                           'Nosso_Numero_Original
        End If
    Else
        lInsert = lInsert & "2, "
    End If
    
    If Len(pRegistro) >= 1021 Then
        lPosInicial = lPosInicial + lTamanho
        lTamanho = 2
        If mfPosInsert(2, "Ind_Funcionario", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
             Exit Function                                                           'Nosso_Numero_Original
        End If
    Else
        lInsert = lInsert & "0, "
    End If
    
    If Len(pRegistro) >= 1021 Then
        lPosInicial = lPosInicial + lTamanho
        lTamanho = 20
        If mfPosInsert(4, "Num_Matricula", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
             Exit Function                                                           'Nosso_Numero_Original
        End If
    Else
        lInsert = lInsert & "'', "
    End If
           
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Novembro\2013
    '=== Indicador Pessoa Politicamente Exposta
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador Pessoa Politicamente Exposta", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_PEP.
    End If
    
    '=== C�digo do Cargo da Pessoa Politicamente Exposta
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo do Cargo da Pessoa Politicamente Exposta", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Cargo_PEP.
    End If
    
    '=== C�digo de Identifica��o do Estado Civil
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "C�digo de Identifica��o do Estado Civil", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Estado_Civil.
    End If
    
    '=== Email
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 100
    If mfPosInsert(4, "Email", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Email.
    End If
    
    'CyberTools - Ari - 1831:Syas Kit - Alterar tamanho do campo Score na tb...42100 - Mar�o/2014
    '=== Score
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "Score", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Score.
    End If
    'CyberTools - Ari - 1831:Syas Kit - Alterar tamanho do campo Score na tb...42100 - Mar�o/2014
    
    '=== Valor Verba Comercial
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(5, "Valor Verba Comercial", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Valor_Verba_Comercial.
    End If
    
    '=== C�digo da Empresa
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "C�digo da Empresa", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Empresa.
    End If
    
    '=== Indicador Cobran�a Provis�ria
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador Cobran�a Provis�ria", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Cob_Provisoria.
    End If
    
    '=== Data Solicita��o da Cobran�a Provis�ria
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data Solicita��o da Cobran�a Provis�ria", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Dat_Solic_Cob_Prov.
    End If
        
    '=== C�digo do produto.
    'Altera��o para 4 Digitos
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo do produto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Produto.
    End If
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Novembro\2013
    
    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Cliente foco", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
        Then
        Exit Function
    End If
    
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Funcion�rio foco", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
        Then
        Exit Function
    End If
    
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Ex Cliente", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
        Then
        Exit Function
    End If
    
    'CyberTools - Ari - Task 4363:Transmiss�o - Novos Campos - Novembro\2014
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(2, "Cod_Grupo_Seg", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
        Then
        Exit Function
    End If
    'CyberTools - Ari - Task 4363:Transmiss�o - Novos Campos - Novembro\2014
    
    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
        
        '2. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            'Provavelmente este erro ocorra por duplicidade de registro.
            'Neste caso, exclui os registros correspondentes e tenta incluir novamente.
            'Excluir a partir da �ltima tabela por causa dos relacionamentos.
            pMensagem = " "
            Call mpExcRegistros(pSohValidacao, pstcProposta, pCN)
            'Tenta incluir mais uma vez.
            If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
                On Error Resume Next
                Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
                Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
                On Error GoTo 0
                Exit Function
            End If
        End If
    End If
    
SAIDA:
    mfGraP0042100 = True
End Function
Private Function mfGraP0042200(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042200 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String

    mfGraP0042200 = False

    '1. Verifica nosso n�mero.
    If Not gfPreenchido(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro do item."
        Exit Function
    End If
    If Not IsNumeric(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro do item."
        Exit Function
    End If
    If Len(Trim(pstcProposta.RegNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro do item."
        Exit Function
    End If
    If pstcProposta.RegNosNumero <> pAntNosNumero Then
        pMensagem = "Registro do item com nosso n�mero (" & pstcProposta.RegNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042200 (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Sit_Item, Tip_Emissao, Num_Vistoria, " & _
              "Cod_Iden_Vistoria, Lib_Cod_Produto, Lib_Cod_Protocolo, Lib_Cod_Sequencia, " & _
              "Ren_Num_Apolice, Ren_Num_Item, Ren_Con_Seguradora, Ren_Con_Apolice, Ren_Con_Item, " & _
              "Ind_Sinistro, Cod_Regiao, CEP_Regiao, Cod_Veiculo, Cod_FIPE, Val_FIPE, " & _
              "Ano_Fabricacao, Ano_Modelo, Cod_Iden_0km, Ext_0km, Cod_Placa, Cod_Chassi, " & _
              "Cod_Chassi_Estrang, Tip_Combustivel, Nom_Proprietario, Tip_Lim_Guincho, " & _
              "Val_Lim_Guincho, Tip_Cobertura, Cod_Iden_Fat_Ajuste, Val_Fat_Ajuste, Tip_Produto, " & _
              "Carro_Reserva, Cod_Iden_Questionario, Cod_Iden_Des_Extr, Cod_Iden_Vidros, " & _
              "Cod_Iden_Acessorios, Cod_Aces_1, Val_IS_Aces_1, Cod_Aces_2, Val_IS_Aces_2, " & _
              "Cod_Aces_3, Val_IS_Aces_3, Cod_Aces_4, Val_IS_Aces_4, Cod_Aces_5, Val_IS_Aces_5, " & _
              "Soc_Dirigente, Cod_Iden_Beneficiario, Nom_Beneficiario, Ace_Fabrica, " & _
              "Cod_Iden_Ar_Condic, Cod_Iden_Dir_Hidra, Cod_Iden_Ban_Couro, Cod_Iden_Cam_Autom, " & _
              "Cod_Iden_Fre_ABS, Cod_Iden_Air_Bag, Cod_Iden_Cla_Particular, Cla_Particular, " & _
              "Cod_Categoria, Val_Cus_Emissao, Per_IOF, Pr_Casco_VM, Pr_Acessorios_VM, " & _
              "Pr_Des_Extr_VM, Pr_Ass_24hs_VM, Pr_Carro_Reserva_VM, Pr_Vidros_VM, Pr_RCDM_VM, " & _
              "Pr_RCDC_VM, Pr_RCMO_VM, Pr_APP_VM, Pr_Ext_0km_VM, Val_Franquia_VM, Pr_Liquido_VM, " & _
              "Val_IOF_VM, Pr_Total_VM, Pr_Casco_VD, Pr_Acessorios_VD, Pr_Des_Extr_VD, " & _
              "Pr_Ass_24hs_VD, Pr_Carro_Reserva_VD, Pr_Vidros_VD, Pr_RCDM_VD, Pr_RCDC_VD, " & _
              "Pr_RCMO_VD, Pr_APP_VD, Pr_Ext_0km_VD, Val_Franquia_VD, Pr_Liquido_VD, Val_IOF_VD, " & _
              "Pr_Total_VD, Num_Perfil, Nom_Condutor, Cod_RG, Cod_CPF, Cod_Iden_Relacao, " & _
              "Dsc_Outra_Relacao, Cod_Est_Civil, Cod_Iden_Sexo, Dat_Nasc, Dat_Pri_Habilit, " & _
              "Cod_Iden_Pessoas, Cod_Iden_Garagem, Cod_Iden_Utiliza, Cod_Iden_Disp_Seg_1, " & _
              "Cod_Iden_Disp_Seg_2, Cod_Iden_Disp_Seg_3, Cod_Iden_Disp_Seg_4, Cod_Iden_Disp_Seg_5, " & _
              "Cod_Iden_Avaria, Ctrl_Cotacao1, Ctrl_Cotacao2, Ctrl_Proposta, Qtd_Renovacoes, " & _
              "Qtd_Ren_Sem_Sin, Qtd_Ren_Com_Sin, Clausula1, Clausula2, Clausula3, Atu_Num_Apolice, "
              
    lInsert = lInsert & "Atu_Num_Item , Num_Endosso, Dat_Emissao, Dat_Alt, Cod_User_Alt, Prazo_Iden, "

    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Outubro\2013
    'CyberTools - Ari - Task 2683:P28V101 - Transmiss�o - Campos: Pr_DesExtra e Ind_PropCorretor - Junho\2014
    'Inclus�o do campo Cod_Caracterizacao (Caracteriza��o do uso do ve�culo)
    'CyberTools - Ari - Task 3127:P28V101 - Novos campos: Zero Km, Extens�o de Per�metro e Isen��o Tribut�ria - Julho\2014
    'Inclus�o dos campos da Concession�ria, Extens�o de Per�metro e Isen��o Tribut�ria
    'CyberTools - Ari - Task 4048:Transmiss�o: Implementar campos novos nos projetos. -  Outubro\2014
    lInsert = lInsert & " Ind_Adap_Gas, LMI_Kit_Gas, Cod_Iden_Cob_Perda_Fat, Ind_Chassi_Remarcado, " & _
                        " Cod_Iden_Uso_Veic, Perc_Limitador, Val_Pr_App_Morte, Val_Pr_App_Inv, Val_Pr_App_DMH, " & _
                        " Val_Franq_1, Val_Franq_2,  Val_Franq_3, Cep_Local_trabalho, Ind_Util_Veic_Trabalho, " & _
                        " Ind_Util_Exer_Trabalho, Ind_Util_Veic_escola, Ind_Garag_Residencia, Ind_Garag_Trabalho, " & _
                        " Ind_Garag_escola, Val_KM_Mensal, Val_KM_distancia, Pr_Ass_24hs, Pr_Carro_Reserva, Pr_Vidros, " & _
                        " Pr_Perda_Faturamento, DDDTelResidencialRastreador, TelResidencialRastreador, DDDCelRastreador, " & _
                        " CelRastreador, DDDTelComercialRastreador, TelComercialRastreador, " & _
                        " NmContatoRastreador, IndVistoria, NrRenavam, NrCNH, " & _
                        " Cod_Caracterizacao, Ind_PropCorretor, " & _
                        " Dat_SaidaNF, Nom_Concessionaria, Cnpj_Concessionaria, DDD_Concessionaria, " & _
                        " Tel_Concessionaria, Num_NotaFiscal, " & _
                        " Tip_ExtensaoPerimetro, Ind_ExtCobPerimetro, Dat_InicioVigencia, Dat_FinalVigencia, " & _
                        " Ind_TributoIsencao , Ind_BenificiarioIsencao, PermiteRastreador, UF_Veiculo, " & _
                        " Pr_ExtPerCasco, Pr_ExtPerRCDC, Pr_ExtPerRCDM, Pr_ExtPerRCMO, Pr_ExtPerAPPInv, " & _
                        " Pr_ExtPerAppMorte, Pr_ExtPerAppDMH, Pr_ExtPerAcess " & _
                        " ) VALUES ("
    'CyberTools - Ari - Task 4048:Transmiss�o: Implementar campos novos nos projetos. -  Outubro\2014
    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    'CyberTools - Ari - Task 3127:P28V101 - Novos campos: Zero Km, Extens�o de Per�metro e Isen��o Tribut�ria - Julho\2014
    'CyberTools - Ari - Task 2683:P28V101 - Transmiss�o - Campos: Pr_DesExtra e Ind_PropCorretor - Junho\2014
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Outubro\2013
              
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    '=== Situa��o do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Situa��o do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Sit_Item.
    End If
    '=== Tipo de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "Tipo de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Tip_Emissao.
    End If
    '=== N�mero da vistoria.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(2, "N�mero da vistoria", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Num_Vistoria.
    End If
    '=== Indicador de vistoria.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de vistoria", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Vistoria.
    End If
    '=== C�digo do produto de libera��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If Len(pRegistro) >= 1038 Then
        If mfPosInsert(2, "C�digo do produto de libera��o", pRegistro, 1035, 4, lInsert, _
           pMensagem) = False Then
            Exit Function                                                           'Lib_Cod_Produto.
        End If
    Else
        If mfPosInsert(2, "C�digo do produto de libera��o", pRegistro, lPosInicial, lTamanho, lInsert, _
           pMensagem) = False Then
            Exit Function                                                           'Lib_Cod_Produto.
        End If
    End If
    '=== C�digo do protocolo de libera��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do protocolo de libera��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Lib_Cod_Protocolo.
    End If
    '=== C�digo da seq��ncia de libera��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da seq��ncia de libera��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Lib_Cod_Sequencia.
    End If
    '=== N�mero da ap�lice de renova��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(2, "N�mero da ap�lice de renova��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Ren_Num_Apolice.
    End If
    '=== N�mero do item da ap�lice de renova��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "N�mero do item da ap�lice de renova��o", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Ren_Num_Item.
    End If
    '=== C�digo da seguradora da renova��o de cong�nere.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da seguradora da renova��o de cong�nere", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Ren_Con_Seguradora.
    End If
    '=== N�mero da ap�lice da renova��o de cong�nere.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(4, "N�mero da ap�lice da renova��o de cong�nere", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Ren_Con_Apolice.
    End If
    '=== N�mero do item da ap�lice da renova��o de cong�nere.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(4, "N�mero do item da ap�lice da renova��o de cong�nere", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Ren_Con_Item.
    End If
    '=== Indicador de sinistro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de sinistro", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Sinistro.
    End If
    '=== C�digo da regi�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo da regi�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Regiao.
    End If
    '=== CEP da regi�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "CEP da regi�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'CEP_Regiao.
    End If
    '=== C�digo do ve�culo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "C�digo do ve�culo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Veiculo.
    End If
    '=== C�digo FIPE.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 7
    If mfPosInsert(2, "C�digo FIPE", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_FIPE.
    End If
    '=== Valor FIPE.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Valor FIPE", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Val_FIPE.
    End If
    '=== Ano de fabrica��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "Ano de fabrica��o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Ano_Fabricacao.
    End If
    '=== Ano de modelo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "Ano de modelo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Ano_Modelo.
    End If
    '=== Indicador de ve�culo 0 km.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de ve�culo 0 km", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cod_Iden_0km.
    End If
    '=== Indicador de cobertura de extens�o para ve�culo 0 km.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de cobertura de extens�o para ve�culo 0 km", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Ext_0km.
    End If
    '=== C�digo da placa.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "C�digo da placa", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Placa.
    End If
    '=== C�digo do chassi.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "C�digo do chassi", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Chassi.
    End If
    '=== C�digo do chassi estrangeiro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "C�digo do chassi estrangeiro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Chassi_Estrang.
    End If
    '=== Tipo do combust�vel.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo do combust�vel", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Tip_Combustivel.
    End If
    '=== Nome do propriet�rio.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Nome do propriet�rio", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Nom_Proprietario.
    End If
    '=== Tipo do limite de guincho.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    
    If Len(pRegistro) = 1040 Then
        If mfPosInsert(2, "Tipo do limite de guincho", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
           = False Then
            Exit Function                                                           'Tip_Lim_Guincho.
        End If
    Else
        If mfPosInsert(2, "Tipo do limite de guincho", pRegistro, 1041, 2, lInsert, pMensagem) = False Then
            Exit Function                                                           'Carro_Reserva.
        End If
    End If
        
    '=== Valor do limite de guincho.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Valor do limite de guincho", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Lim_Guincho.
    End If
    '=== Tipo de cobertura.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo de cobertura", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Tip_Cobertura.
    End If
    '=== Indicador de fator de ajuste.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de fator de ajuste", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Fat_Ajuste.
    End If
    '=== Valor do fator de ajuste.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "Valor do fator de ajuste", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Val_Fat_Ajuste.
    End If
    '=== Tipo do produto.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo do produto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Tip_Produto.
    End If
    '=== Indicador da cobertura de carro reserva.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If Len(pRegistro) = 1038 Then
        If mfPosInsert(2, "Indicador da cobertura de carro reserva", pRegistro, lPosInicial, lTamanho, _
           lInsert, pMensagem) = False Then
            Exit Function                                                           'Carro_Reserva.
        End If
    Else
        If mfPosInsert(2, "Indicador da cobertura de carro reserva", pRegistro, 1039, 2, lInsert, pMensagem) = False Then
            Exit Function                                                           'Carro_Reserva.
        End If
    End If
    '=== Indicador do question�rio de avalia��o de risco.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do question�rio de avalia��o de risco", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Questionario.
    End If
    '=== Indicador da cobertura de despesas extraordin�rias.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador da cobertura de despesas extraordin�rias", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Des_Extr.
    End If
    '=== Indicador da cobertura de vidros.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador da cobertura de vidros", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Vidros.
    End If
    '=== Indicador da cobertura de acess�rios.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador da cobertura de acess�rios", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Acessorios.
    End If
    '=== C�digo do acess�rio 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do acess�rio 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Aces_1.
    End If
    '=== Import�ncia segurada do acess�rio 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Import�ncia segurada do acess�rio 1", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS_Aces_1.
    End If
    '=== C�digo do acess�rio 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do acess�rio 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Aces_2.
    End If
    '=== Import�ncia segurada do acess�rio 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Import�ncia segurada do acess�rio 2", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS_Aces_2.
    End If
    '=== C�digo do acess�rio 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do acess�rio 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Aces_3.
    End If
    '=== Import�ncia segurada do acess�rio 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Import�ncia segurada do acess�rio 3", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS_Aces_3.
    End If
    '=== C�digo do acess�rio 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do acess�rio 4", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Aces_4.
    End If
    '=== Import�ncia segurada do acess�rio 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Import�ncia segurada do acess�rio 4", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS_Aces_4.
    End If
    '=== C�digo do acess�rio 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "C�digo do acess�rio 5", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Aces_5.
    End If
    '=== Import�ncia segurada do acess�rio 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Import�ncia segurada do acess�rio 5", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS_Aces_5.
    End If
    '=== Indicador da cl�usula de s�cio/dirigente.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador da cl�usula de s�cio/dirigente", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Soc_Dirigente.
    End If
    '=== Indicador de benefici�rio.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de benefici�rio", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cod_Iden_Beneficiario.
    End If
    '=== Nome do benefici�rio.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "Nome do benefici�rio", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Nom_Beneficiario.
    End If
    '=== Indicador de acess�rios de f�brica.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de acess�rios de f�brica", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Ace_Fabrica.
    End If
    '=== Indicador de ar condicionado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de ar condicionado", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Ar_Condic.
    End If
    '=== Indicador de dire��o hidr�ulica.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de dire��o hidr�ulica", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Dir_Hidra.
    End If
    '=== Indicador de bancos de couro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de bancos de couro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Ban_Couro.
    End If
    '=== Indicador de c�mbio autom�tico.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de c�mbio autom�tico", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Cam_Autom.
    End If
    '=== Indicador de freios ABS.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de freios ABS", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Fre_ABS.
    End If
    '=== Indicador de air bag.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de air bag", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Air_Bag.
    End If
    '===  Indicador de cl�usula particular.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de cl�usula particular", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Cla_Particular.
    End If
    '=== C�digo da cl�usula particular.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(4, "C�digo da cl�usula particular", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cla_Particular.
    End If
    '=== Categoria.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Categoria", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Categoria.
    End If
    '=== Custo de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Custo de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Val_Cus_Emissao.
    End If
    '=== Percentual de IOF.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual de IOF", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Per_IOF.
    End If
    '=== VM - Pr�mio de casco.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de casco", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_Casco_VM.
    End If
    '=== VM - Pr�mio de acess�rios.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de acess�rios", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Pr_Acessorios_VM.
    End If
    '=== VM - Pr�mio de despesas extraordin�rias.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de despesas extraordin�rias", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Pr_Des_Extr_VM.
    End If
    '=== VM - Pr�mio de assist�ncia 24 horas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de assist�ncia 24 horas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Ass_24hs_VM.
    End If
    '=== VM - Pr�mio de carro reserva.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de carro reserva", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Carro_Reserva_VM.
    End If
    '=== VM - Pr�mio de vidros.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de vidros", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_Vidros_VM.
    End If
    '=== VM - Pr�mio de RC-DM.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de RC-DM", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_RCDM_VM.
    End If
    '=== VM - Pr�mio de RC-DC.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de RC-DC", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_RCDC_VM.
    End If
    '=== VM - Pr�mio de RC-MO.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de RC-MO", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_RCMO_VM.
    End If
    '=== VM - Pr�mio de APP.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de APP", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_APP_VM.
    End If
    '=== VM - Pr�mio de extens�o para ve�culo 0 km.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio de extens�o para ve�culo 0 km", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Pr_Ext_0km_VM.
    End If
    '=== VM - Valor da franquia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Valor da franquia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Franquia_VM.
    End If
    '=== VM - Pr�mio l�q�ido.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio l�q�ido", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_Liquido_VM.
    End If
    '=== VM - Valor do IOF.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Valor do IOF", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Val_IOF_VM.
    End If
    '=== VM - Pr�mio total.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VM - Pr�mio total", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Pr_Total_VM.
    End If
    '=== VD - Pr�mio de casco.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de casco", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_Casco_VD.
    End If
    '=== VD - Pr�mio de acess�rios.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de acess�rios", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Pr_Acessorios_VD.
    End If
    '=== VD - Pr�mio de despesas extraordin�rias.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de despesas extraordin�rias", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Pr_Des_Extr_VD.
    End If
    '=== VD - Pr�mio de assist�ncia 24 horas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de assist�ncia 24 horas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Ass_24hs_VD.
    End If
    '=== VD - Pr�mio de carro reserva.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de carro reserva", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Carro_Reserva_VD.
    End If
    '=== VD - Pr�mio de vidros.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de vidros", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_Vidros_VD.
    End If
    
    '=== VD - Pr�mio de RC-DM.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de RC-DM", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_RCDM_VD.
    End If
    
    '=== VD - Pr�mio de RC-DC.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de RC-DC", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_RCDC_VD.
    End If
    
    '=== VD - Pr�mio de RC-MO.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de RC-MO", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_RCMO_VD.
    End If
    
    '=== VD - Pr�mio de APP.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de APP", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_APP_VD.
    End If
    
    '=== VD - Pr�mio de extens�o para ve�culo 0 km.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio de extens�o para ve�culo 0 km", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Pr_Ext_0km_VD.
    End If
    
    '=== VD - Valor da franquia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Valor da franquia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Franquia_VD.
    End If
    
    '=== VD - Pr�mio l�q�ido.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio l�q�ido", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Pr_Liquido_VD.
    End If
    
    '=== VD - Valor do IOF.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Valor do IOF", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Val_IOF_VD.
    End If
    
    '=== VD - Pr�mio total.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "VD - Pr�mio total", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Pr_Total_VD.
    End If
    
    '=== N�mero do perfil.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(2, "N�mero do perfil", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Num_Perfil.
    End If
    
    '=== Nome do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 30
    If mfPosInsert(4, "Nome do condutor", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Nom_Condutor.
    End If
    
    '=== RG do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "RG do condutor", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_RG.
    End If
    
    '=== CPF do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(4, "CPF do condutor", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_CPF.
    End If
    
    '=== Indicador da rela��o do condutor com o proponente.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(1, "Indicador da rela��o do condutor com o proponente", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Relacao.
    End If
    
    '=== Descri��o de outra rela��o do condutor com o proponente.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "Descri��o de outra rela��o do condutor com o proponente", pRegistro, lPosInicial, _
       lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Dsc_Outra_Relacao.
    End If
    
    '=== Estado civil do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(4, "Estado civil do condutor", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Cod_Est_Civil.
    End If
    
    '=== Sexo do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(4, "Sexo do condutor", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Iden_Sexo.
    End If
    
    '=== Data de nascimento do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Data de nascimento do condutor", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Nasc.
    End If
    
    '=== Data da primeira habilita��o do condutor.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Data da primeira habilita��o do condutor", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Dat_Pri_Habilit.
    End If
    
    '=== Indicador de pessoas entre 18 e 24 anos.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de pessoas entre 18 e 24 anos", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Pessoas.
    End If
    
    '=== Indicador de estacionamento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(4, "Indicador de estacionamento", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Garagem.
    End If
    
    '=== Indicador de utiliza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(4, "Indicador de utiliza��o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Utiliza.
    End If
    
    '=== Indicador do dispositivo de seguran�a 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do dispositivo de seguran�a 1", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Disp_Seg_1.
    End If
    
    '=== Indicador do dispositivo de seguran�a 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do dispositivo de seguran�a 2", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Disp_Seg_2.
    End If
    
    '=== Indicador do dispositivo de seguran�a 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do dispositivo de seguran�a 3", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Disp_Seg_3.
    End If
    
    '=== Indicador do dispositivo de seguran�a 4.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do dispositivo de seguran�a 4", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Disp_Seg_4.
    End If
    
    '=== Indicador do dispositivo de seguran�a 5.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do dispositivo de seguran�a 5", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Cod_Iden_Disp_Seg_5.
    End If
    
    '=== Indicador de avarias.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de avarias", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Avaria.
    End If
    
    '=== Controle de cota��o 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 40
    If mfPosInsert(4, "Controle de cota��o 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ctrl_Cotacao1.
    End If
    
    '=== Controle de cota��o 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 40
    If mfPosInsert(4, "Controle de cota��o 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ctrl_Cotacao2.
    End If
    
    '=== Controle de proposta.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 70
    If mfPosInsert(4, "Controle de proposta", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ctrl_Proposta.
    End If
    
    '=== Quantidade de renova��es.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Quantidade de renova��es", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) _
       = False Then
        Exit Function                                                           'Qtd_Renovacoes.
    End If
    
    '=== Quantidade de renova��es sem sinistro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Quantidade de renova��es sem sinistro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Qtd_Ren_Sem_Sin.
    End If
    
    '=== Quantidade de renova��es com sinistro.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Quantidade de renova��es com sinistro", pRegistro, lPosInicial, lTamanho, _
       lInsert, pMensagem) = False Then
        Exit Function                                                           'Qtd_Ren_Com_Sin.
    End If
    
    '=== Cl�usula 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(4, "Cl�usula 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Clausula1.
    End If
    
    '=== Cl�usula 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(4, "Cl�usula 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Clausula2.
    End If
    
    '=== Cl�usula 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(4, "Cl�usula 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Clausula3.
    End If
    
    '=== N�mero da ap�lice atual.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(2, "N�mero da ap�lice atual", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Atu_Num_Apolice.
    End If
            
    '=== N�mero do item da ap�lice atual.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "N�mero do item da ap�lice atual", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Atu_Num_Item.
    End If
    
    '=== N�mero do endosso.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 6
    If mfPosInsert(4, "N�mero do endosso", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Num_Endosso.
    End If
    
    '=== Data de emiss�o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Data de emiss�o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Dat_Emissao.
    End If
    
    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If
    
    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If
    
    '==== Prazo
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Tipo de prazo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Prazo_iden.
    End If
    
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Novembro\2013
    
    'If mfPosCampo(2, "c�digo do produto de libera��o", rsP0042200!Lib_Cod_Produto, 4, 0, _
    'If mfPosCampo(2, "indicador de carro reserva", Format(rsP0042200!Carro_Reserva, "00"), 2, 0, pMensagem) = _
    'If mfPosCampo(2, "tipo de limite de guincho", rsP0042200!Tip_Lim_Guincho, 2, 0, pMensagem) = _

     lPosInicial = lPosInicial + 8
    
    '=== Adapta��o para G�s.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Adapta��o para G�s", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Adap_Gas.
    End If
    
    '=== LMI Kit G�s.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "LMI Kit G�s", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'LMI_Kit_Gas.
    End If
    
    '=== C�digo de Identifica��o Cobertura Perda de Faturamento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "C�digo de Identifica��o Cobertura Perda de Faturamento", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Cob_Perda_Fat.
    End If
    
    '=== Indicador Chassi Remarcado.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador Chassi Remarcado", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Chassi_Remarcado.
    End If
    
    '=== C�digo de Identifica��o do Uso do Ve�culo.
    lPosInicial = lPosInicial + lTamanho
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    'lTamanho = 1
    lTamanho = 2
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    If mfPosInsert(2, "C�digo de Identifica��o do Uso do Ve�culo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Uso_Veic.
    End If
    
    '=== Percentual Limitador.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(5, "Percentual Limitador", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Perc_Limitador.
    End If
    
    '=== Valor Pr App Morte.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "Valor Pr App Morte", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Pr_App_Morte.
    End If
    
    '=== Valor Pr App Inv.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "Valor Pr App Inv", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Pr_App_Inv.
    End If
    
    '=== Valor Pr App DMH.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "Valor Pr App DMH", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Pr_App_DMH.
    End If
    
    '=== Valor Franquia 1.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "Valor Franquia 1", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Franq_1.
    End If
    
    '=== Valor Franquia 2.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "Valor Franquia 2", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Franq_2.
    End If
    
    '=== Valor Franquia 3.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 15
    If mfPosInsert(5, "Valor Franquia 3", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_Franq_3.
    End If
    
    '=== Cep do Local de Trabalho.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Cep do Local de Trabalho", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cel_Local_trabalho.
    End If
    
    '=== Indicador de Utiliza��o Ida e Volta do Ve�culo no Trabalho.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Indicador de Utiliza��o Ida e Volta do Ve�culo no Trabalho", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Util_Veic_Trabalho.
    End If
    
    '=== Indicador de Utiliza��o Exerc�cio do Ve�culo no Trabalho.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Indicador de Utiliza��o Exerc�cio do Ve�culo no Trabalho", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Util_Exer_Trabalho.
    End If
    
    '=== Indicador de Utiliza��o Ida e Volta do Ve�culo na Escola.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Indicador de Utiliza��o Ida e Volta do Ve�culo na Escola", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Util_Veic_escola.
    End If
    
    '=== Indicador de Garagem para o Ve�culo na Resid�ncia.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Indicador de Garagem para o Ve�culo na Resid�ncia", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Garag_Residencia.
    End If
    
    '=== Indicador de Garagem para o Ve�culo no Trabalho.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Indicador de Garagem para o Ve�culo no Trabalho", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Garag_Trabalho.
    End If
    
    '=== Indicador de Garagem para o Ve�culo na Escola.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Indicador de Garagem para o Ve�culo na Escola", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Ind_Garag_escola.
    End If
    
    '=== Quilometragem do Ve�culo Mensal.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(5, "Quilometragem do Ve�culo Mensal", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_KM_Mensal.
    End If
    
    '=== Dist�ncia at� o Trabalho em KM.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(5, "Dist�ncia at� o Trabalho em KM", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Val_KM_distancia.
    End If

    '=== Pr�mio de assist�ncia 24 horas.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio de assist�ncia 24 horas", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Ass_24hs.
    End If
    
    '=== Pr�mio de Carro Reserva
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Carro Reserva", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Carro_Reserva.
    End If
    
    '=== Pr�mio Vidros
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Vidros", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Vidros.
    End If
    
    '=== Pr�mio Perda Faturamento
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Perda Faturamento ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_Perda_Faturamento.
    End If
    
    '=== DDDTelResidencialRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "DDDTelResidencialRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== TelResidencialRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 9
    If mfPosInsert(2, "TelResidencialRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== DDDCelRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "DDDCelRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== CelRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 9
    If mfPosInsert(2, "CelRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== DDDTelComercialRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "DDDTelComercialRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== TelComercialRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 9
    If mfPosInsert(2, "TelComercialRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== NmContatoRastreador
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 60
    If mfPosInsert(4, "NmContatoRastreador ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    
    '=== IndVistoria
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "IndVistoria ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Novembro\2013

    'CyberTools - TFS 2022 - Mar�o\2014
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(4, "N�mero do RENAVAM ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If

    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(4, "N�mero do CNH ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    'CyberTools - TFS 2022 - Mar�o\2014
    
    'CyberTools - TFS 2214 - Abril\2014
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 5
    If mfPosInsert(2, "C�digo da Caracteriza��o do Uso do Ve�culo ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    'CyberTools - TFS 2214 - Abril\2014
    
    'CyberTools - Ari - Task 2683:P28V101 - Transmiss�o - Campos: Pr_DesExtra e Ind_PropCorretor - Junho\2014
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador Carteira do Pr�prio Corretor ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function
    End If
    'CyberTools - Ari - Task 2683:P28V101 - Transmiss�o - Campos: Pr_DesExtra e Ind_PropCorretor - Junho\2014

    'CyberTools - Ari - Task 3127:P28V101 - Novos campos: Zero Km, Extens�o de Per�metro e Isen��o Tribut�ria - Julho\2014
    '--Data de Sa�da do Ve�culo da Concession�ria
'   Dat_SaidaNF         float,
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Data de Sa�da do Ve�culo da Concession�ria", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                   'Dat_SaidaNF
    End If
         
    '--Nome da concession�ria
'   Nom_Concessionaria  varchar(100),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 100
    If mfPosInsert(4, "Nome da Concession�ria ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                   'Nom_Concessionaria
    End If

    '--CNPJ da concession�ria
'   Cnpj_Concessionaria decimal(14,0),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(7, "CNPJ da Concession�ria", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                   'Cnpj_Concessionaria
    End If

    '--DDD do telefone da Concession�ria
'   DDD_Concessionaria  numeric(3),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 3
    If mfPosInsert(2, "DDD do Telefone da Concessionaria ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
       Exit Function                                    'DDD_Concessionaria
    End If

    '--Telefone da concession�ria
'   Tel_Concessionaria  numeric(9),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 9
    If mfPosInsert(2, "Telefone da Concession�ria ", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                   'Tel_Concessionaria
    End If

    '--N�mero da Nota Fiscal
'   Num_NotaFiscal      numeric(20)
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 20
    If mfPosInsert(4, "N�mero da Nota Fiscal", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                   'Num_NotaFiscal
    End If

    '--0 - Sem informa��o, 1 - Pa�ses Am�rica do Sul, 2 - Tr�s Am�ricas
'   Tip_ExtensaoPerimetro   numeric(1),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Tipo Extens�o do Per�metro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                           'Tip_ExtensaoPerimetro
    End If

    '--0 - Sem informa��o, 1 - Casco, 2 - RCF
'   Ind_ExtCobPerimetro     numeric(1),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador da Cobertura de Extens�o de Per�metro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                           'Ind_ExtCobPerimetro
    End If

    'Data in�cio da vig�ncia Extens�o de Per�metro
'   Dat_InicioVigencia      float,
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(2, "Data Inicial da vig�ncia Extens�o de Per�metro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                            'Dat_InicioVigencia
    End If

    'Data final da vig�ncia Extens�o de Per�metro
'   Dat_FinalVigencia       Float
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 10
    If mfPosInsert(2, "Data Final da vig�ncia Extens�o de Per�metro", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                             'Dat_FinalVigencia
    End If

    '--0 - Sem Informa��o, 1 - ICMS, 2 - IPI, 3 - ICMS, 4 - ICMS e IPI
'   Ind_TributoIsencao      numeric(1),
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador de Tributo da Isen��o Triut�ria", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                           'Ind_TributoIsencao
    End If

    '--0 - Sem Informa��o, 1 - PcD - Pessoa com Defici�ncia, 2 - T�xi, 3 - Ve�culo Oficial
'   Ind_BenificiarioIsencao numeric(1)
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador do Benefici�rio da Isen��o Triut�ria", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                           'Ind_BenificiarioIsencao
    End If
    'CyberTools - Ari - Task 3127:P28V101 - Novos campos: Zero Km, Extens�o de Per�metro e Isen��o Tribut�ria - Julho\2014

    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    'PermiteRastreador numeric(1)
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Permite Rastreador ?", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                           'PermiteRastreador
    End If
    
    'UF_Veiculo varchar(2)
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(4, "UF do Ve�culo", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                           'UF_Veiculo
    End If
    'Cyber - Ari - Task 3247:P28V200 - Gerenciador - Nova Tabela YTAB_FAT_RASTREADOR, Alterar a YTAB_OFERTA_RASTREADOR - Agosto\2014
    
    'CyberTools - Ari - Task 4048:Transmiss�o: Implementar campos novos nos projetos. -  Outubro\2014
    '=== Pr�mio Ext Per Casco
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per Casco", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerCasco.
    End If
    
    '=== Pr�mio Ext Perc RCDC
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Perc RCDC", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerRCDC.
    End If
    
    '=== Pr�mio Ext Per RCDM
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per RCDM", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerRCDM.
    End If
    
    '=== Pr�mio Ext Per RCMO
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per RCMO", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerRCMO.
    End If
    
    '=== Pr�mio Ext Per APPInv
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per APPInv", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerAPPInv.
    End If
    
    '=== Pr�mio Ext Per AppMorte
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per AppMorte", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerAppMorte.
    End If
    
    '=== Pr�mio Ext Per AppDMH
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per AppDMH", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerAppDMH.
    End If
    
    '=== Pr�mio Ext Per Acess
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 13
    If mfPosInsert(5, "Pr�mio Ext Per Acess", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pr_ExtPerAcess.
    End If
    'CyberTools - Ari - Task 4048:Transmiss�o: Implementar campos novos nos projetos. -  Outubro\2014
    
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
        
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraP0042200 = True
    
End Function

'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
Private Function mfGraP0042601(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042601 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String

    mfGraP0042601 = False

    '1. Verifica nosso n�mero.
    If Not gfPreenchido(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro do item."
        Exit Function
    End If
    If Not IsNumeric(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro do item."
        Exit Function
    End If
    If Len(Trim(pstcProposta.RegNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro do item."
        Exit Function
    End If
    If pstcProposta.RegNosNumero <> pAntNosNumero Then
        pMensagem = "Registro do item com nosso n�mero (" & pstcProposta.RegNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If
    
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042601 (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Tip_Adic_Veic, Cod_Adic_Veic, Val_IS, " & _
                        " Dat_Alt, Cod_User_Alt)" & _
                        " VALUES ("
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    
    '=== Tipo Adicional do Ve�culo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "Tipo Adicional do Ve�culo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Tip_Adic_Veic.
    End If
    
    '=== C�digo do Adicional do Ve�culo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(2, "C�digo do Adicional do Ve�culo", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Adic_Veic.
    End If
    
    '=== Valor do IS.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Valor do IS", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS.
    End If
    
    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If
    
    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If
        
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
        
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraP0042601 = True
    
End Function
'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013

'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
Private Function mfGraTAB_HIST_ROTEIRO_CALCULO(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro TAB_HIST_ROTEIRO_CALCULO na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String

    mfGraTAB_HIST_ROTEIRO_CALCULO = False

    '1. Verifica nosso n�mero.
    If Not gfPreenchido(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro do item."
        Exit Function
    End If
    If Not IsNumeric(pstcProposta.RegNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro do item."
        Exit Function
    End If
    If Len(Trim(pstcProposta.RegNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro do item."
        Exit Function
    End If
    If pstcProposta.RegNosNumero <> pAntNosNumero Then
        pMensagem = "Registro do item com nosso n�mero (" & pstcProposta.RegNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If
    
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "TAB_HIST_ROTEIRO_CALCULO (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Cod_Premio, Cod_Chave, Dsc_Chave, Val_Anterior,   " & _
                        " Val_A_Aplicar, Val_Final, Cod_Roteiro_Tipo, Ordem)" & _
                        " VALUES ("
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    
    '=== C�digo do Pr�mio
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "C�digo do Pr�mio", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Premio.
    End If
    
    '=== C�digo da Chave.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "C�digo da Chave", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Cod_Chave.
    End If
    
    '=== Descri��o da Chave.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 200
    If mfPosInsert(4, "Descri��o da Chave", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dsc_Chave.
    End If
    
    '=== Valor Anterior.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(5, "Valor Anterior", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Anterior.
    End If
    
    '=== Valor � Aplicar.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(5, "Valor � Aplicar", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_A_Aplicar.
    End If
        
    '=== Valor Final.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 12
    If mfPosInsert(5, "Valor Final", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_Final.
    End If
    
    '=== C�digo do Roteiro Tipo.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "C�digo do Roteiro Tipo", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Roteiro_Tipo.
    End If
            
    '=== Ordem.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(1, "Ordem", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Ordem.
    End If
            
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
        
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraTAB_HIST_ROTEIRO_CALCULO = True
    
End Function
'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014


Private Function mfGraP0042300(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042300 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lNosNumero  As String   'Nosso n�mero.
Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String

    mfGraP0042300 = False

    '1. Verifica nosso n�mero.
    lNosNumero = Mid$(pRegistro, 9, 20)
    If Not gfPreenchido(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro de observa��o do item."
        Exit Function
    End If
    If Not IsNumeric(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro de observa��o do item."
        Exit Function
    End If
    If Len(Trim(lNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro de " & _
                    "observa��o do item."
        Exit Function
    End If
    If lNosNumero <> pAntNosNumero Then
        pMensagem = "Registro de observa��o do item com nosso n�mero (" & lNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042300 (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Num_Linha, Observacao, Dat_Alt, " & _
              "Cod_User_Alt) VALUES ("
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    '=== N�mero da linha.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero da linha", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Num_Linha.
    End If
    '=== Observa��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 120
    If mfPosInsert(4, "Observa��o", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Observacao.
    End If
    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If
    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
        
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraP0042300 = True
End Function
Private Function mfGraP0042600(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042600 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lNosNumero  As String   'Nosso n�mero.
Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String

    mfGraP0042600 = False

    '1. Verifica nosso n�mero.
    lNosNumero = Mid$(pRegistro, 9, 20)
    If Not gfPreenchido(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro de cobertura do item."
        Exit Function
    End If
    If Not IsNumeric(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro de cobertura do item."
        Exit Function
    End If
    If Len(Trim(lNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro de " & _
                    "cobertura do item."
        Exit Function
    End If
    If lNosNumero <> pAntNosNumero Then
        pMensagem = "Registro de cobertura do item com nosso n�mero (" & lNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If

    '2. Monta comando INSERT.
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042600 (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Cod_Cobert, Tip_Produto, " & _
              "Cod_Iden_Cobert, Cod_Niv_IS, Val_IS, Dat_Alt, Cod_User_Alt) VALUES ("
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    '=== C�digo da cobertura.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(1, "C�digo da cobertura", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Cobert.
    End If
    '=== Tipo do produto.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(1, "Tipo do produto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Tip_Produto.
    End If
    '=== Indicador da cobertura.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Indicador da cobertura", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Iden_Cobert.
    End If
    '=== N�vel da import�ncia segurada.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "N�vel da import�ncia segurada", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_Niv_IS.
    End If
    '=== Valor da import�ncia segurada.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Valor da import�ncia segurada", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Val_IS.
    End If
    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If
    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
        
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraP0042600 = True
    
End Function
Private Function mfGraTabAjustePremio(ByVal pSohValidacao As Boolean, _
                                      ByVal pRegistro As String, _
                                      ByVal pAntNosNumero As String, _
                                      ByRef pstcProposta As stcA28V300, _
                                      ByRef pCN As ADODB.Connection, _
                                      ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042200 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lNosNumero  As String   'Nosso n�mero.
Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String

    mfGraTabAjustePremio = False

    '1. Verifica nosso n�mero.
    lNosNumero = Mid$(pRegistro, 9, 20)
    If Not gfPreenchido(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro de cobertura do item."
        Exit Function
    End If
    If Not IsNumeric(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro de cobertura do item."
        Exit Function
    End If
    If Len(Trim(lNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro de " & _
                    "cobertura do item."
        Exit Function
    End If
    If lNosNumero <> pAntNosNumero Then
        pMensagem = "Registro de cobertura do item com nosso n�mero (" & lNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If

    '2. Monta comando INSERT.
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "tab_ajuste_premio (Num_Proposta, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Pre_Auto, Pre_Acessorio, " & _
            " Pre_Rdm, Pre_Rdp, Pre_App, Pre_Rmo, Ind_Premio_Net, Pre_Soc, Pre_Desp_Ext,Pre_App_DMH,Pre_App_Inv, " & _
            " Pre_App_Morte, Pre_PerdaFat, Pre_ExtPer_Casco, Pre_ExtPer_RCDM, Pre_ExtPer_RCDC, Pre_ExtPer_Aces, " & _
            " Pre_ExtPer_APPMorte, Pre_ExtPer_AppInv, Pre_ExtPer_AppDMH, Pre_Ass24h, Pre_CarroReserva, Pre_Vidros ) VALUES ("
    '=== Num_Proposta
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    '=== Pr�mio Auto
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Pr�mio Auto", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Auto.
    End If
    '=== Pr�mio Acess�rio
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Pr�mio Access�rio", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Acessorio
    End If
    '=== Pr�mio RC DM
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Pr�mio RCDM", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Rdm
    End If
    '=== Pr�mio RC DC
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Pr�mio RCDC", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Rdp
    End If
    
    '=== Pr�mio App
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Pr�mio App", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_App
    End If
    '=== Pr�mio RCMO
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Pr�mio RCMO", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Rmo
    End If
    '=== Indicador de pr�mio NET
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(2, "Ind Premio Net", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Ind_Premio_Net
    End If
    '=== Pr�mio Soc
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio Soc", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Soc
    End If
    '=== Pr�mio Desp Ext
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio Desp.", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Desp_Ext
    End If
    
    
    '=== Pr�mio app dmh
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio app dmh", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_App_DMH
    End If
    
    '=== Pr�mio app inv
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio app inv", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_App_Inv
    End If
    
    '=== Pr�mio app morte
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio app morte", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_App_Morte
    End If
    '=== Pr�mio perda de faturamento
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio perda de faturamento", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_PerdaFat
    End If
    '=== Pr�mio ext de perimetro casco
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro casco", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_Casco
    End If
    
    '=== Pr�mio ext de perimetro rc dm
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro rc dm", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_RCDM
    End If
    
    '=== Pr�mio ext de perimetro rc dc
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro rc dc", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_RCDC
    End If
    
    '=== Pr�mio ext de perimetro acess
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro rc dc", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_Aces
    End If
    
    '=== Pr�mio ext de perimetro app morte
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro app morte", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_APPMorte
    End If
    
    '=== Pr�mio ext de perimetro app inv
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro app inv", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_AppInv
    End If
    
    '=== Pr�mio ext de perimetro app dmh
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio extensao de perimetro app dmh", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_ExtPer_AppDMH
    End If
    
    '=== Pr�mio ass 24h
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio ass 24h", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Ass24h
    End If
    
    '=== Pr�mio carro reserva
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio carro reserva", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_CarroReserva
    End If
    
    '=== Pr�mio vidros
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Premio vidros", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Pre_Vidros
    End If
    
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
    
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraTabAjustePremio = True
    
End Function

Private Function mfGraP0042700(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pstcProposta As stcA28V300, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042700 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lNosNumero  As String   'Nosso n�mero.
Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String
    
    mfGraP0042700 = False

    '1. Verifica nosso n�mero.
    lNosNumero = Mid$(pRegistro, 9, 20)
    If Not gfPreenchido(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro de desconto do item."
        Exit Function
    End If
    If Not IsNumeric(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro de desconto do item."
        Exit Function
    End If
    If Len(Trim(lNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro de " & _
                    "desconto do item."
        Exit Function
    End If
    If lNosNumero <> pAntNosNumero Then
        pMensagem = "Registro de desconto do item com nosso n�mero (" & lNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If

    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & "ftp_"
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042700 (Nosso_Numero, "
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & " Cod_Unicidade, "
    End If
    lInsert = lInsert & " Num_Item, Cod_Desc, Cod_Classe_Desc, Per_Desc, " & _
              "Dat_Alt, Cod_User_Alt) VALUES ("
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    '=== DV/ Cod Unicidade - Cod_Unicidade.
    If InStr(1, gOwner, "ftp_") > 0 Then
        lInsert = lInsert & pstcProposta.CodUnicidade & " , "
    End If
    '=== N�mero do item.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(1, "N�mero do item", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Num_Item.
    End If
    '=== C�digo do desconto.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(1, "C�digo do desconto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Desc.
    End If
    '=== Classe de desconto.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(2, "Classe de desconto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Cod_Classe_Desc.
    End If
    '=== Percentual de desconto.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 4
    If mfPosInsert(5, "Percentual de desconto", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Per_Desc.
    End If
    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If
    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
    'Verifica se pode incluir o registro novo (caso n�o esteja em processo de emiss�o)
        If InStr(1, gOwner, "ftp_") > 0 Then
            If pstcProposta.gPodeIncluir = False Then
                GoTo SAIDA
            End If
        End If
    
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) <> 0 Then
            On Error Resume Next
            Shell "net send tjgomes " & App.EXEName & " - ERRO " & pMensagem
            Shell "net send mosilva " & App.EXEName & " - ERRO " & pMensagem
            On Error GoTo 0
            Exit Function
        End If
    End If
SAIDA:
    mfGraP0042700 = True
    
End Function
Private Function mfGraP0042800(ByVal pSohValidacao As Boolean, _
                               ByVal pRegistro As String, _
                               ByVal pAntNosNumero As String, _
                               ByRef pCN As ADODB.Connection, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: grava registro P0042800 na base de dados SQL-Server.

    'Par�metro de entrada...pRegistro...Registro de entrada.
    'Par�metro de sa�da.....pMensagem...Mensagem.

Dim lNosNumero  As String   'Nosso n�mero.
Dim lPosInicial As Integer  'Posi��o inicial do campo no registro de entrada.
Dim lTamanho    As Integer  'Tamanho do campo no registro de entrada.
Dim lInsert     As String
    
    mfGraP0042800 = False

    '1. Verifica nosso n�mero.
    lNosNumero = Mid$(pRegistro, 9, 20)
    If Not gfPreenchido(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o preenchido no registro de parcelamento."
        Exit Function
    End If
    If Not IsNumeric(lNosNumero) Then
        pMensagem = "Nosso n�mero n�o num�rico no registro de parcelamento."
        Exit Function
    End If
    If Len(Trim(lNosNumero)) <> 20 Then
        pMensagem = "Nosso n�mero inv�lido - tamanho diferente de 20 posi��es no registro de " & _
                    "parcelamento."
        Exit Function
    End If
    If lNosNumero <> pAntNosNumero Then
        pMensagem = "Registro de parcelamento com nosso n�mero (" & lNosNumero & _
                    ") diferente do nosso n�mero do registro de dados comuns anterior (" & _
                    pAntNosNumero & ")."
        Exit Function
    End If

    '2. Monta comando INSERT.
    If Not gfPreenchido(gOwner) Then
        gOwner = "" & gPropTabelaCorporativo & ""
    End If
    '2. Monta comando INSERT.
    lInsert = "INSERT INTO " & gOwner & "P0042800 (Nosso_Numero, Tip_Cob_Casco, Num_Parc, Dat_Venc, Val_Parcela, " & _
              "Dat_Alt, Cod_User_Alt) VALUES ("
    '=== Nosso n�mero.
    lPosInicial = 9
    lTamanho = 20
    If mfPosInsert(6, "Nosso n�mero", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False Then
        Exit Function                                                           'Nosso_Numero.
    End If
    '=== Tipo da cobertura de casco.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 1
    If mfPosInsert(1, "Tipo da cobertura de casco", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Tip_Cob_Casco.
    End If
    '=== N�mero da parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 2
    If mfPosInsert(1, "N�mero da parcela", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Num_Parc.
    End If
    '=== Data de vencimento.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(2, "Data de vencimento", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = _
       False Then
        Exit Function                                                           'Dat_Venc.
    End If
    '=== Valor da parcela.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 11
    If mfPosInsert(5, "Valor da parcela", pRegistro, lPosInicial, lTamanho, lInsert, pMensagem) = False _
       Then
        Exit Function                                                           'Val_Parcela.
    End If
    '=== Data da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 14
    If mfPosInsert(2, "Data da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Dat_Alt.
    End If
    '=== Usu�rio da �ltima atualiza��o.
    lPosInicial = lPosInicial + lTamanho
    lTamanho = 8
    If mfPosInsert(4, "Usu�rio da �ltima atualiza��o", pRegistro, lPosInicial, lTamanho, lInsert, _
       pMensagem) = False Then
        Exit Function                                                           'Cod_User_Alt.
    End If
    'Encerra comando.
    lTamanho = Len(lInsert)
    lInsert = Left$(lInsert, lTamanho - 2) & ")"

    If pSohValidacao = True Then
        DoEvents
    Else
        '3. Executa comando.
        If mfExeSQL(pCN, lInsert, pMensagem) = 0 Then
            mfGraP0042800 = True
        End If
    End If
    
End Function
Private Sub mpExcRegistros(ByVal pSohValidacao As Boolean, _
                           ByRef pstcProposta As stcA28V300, _
                           ByRef pCN As ADODB.Connection)
    'Procedure: exclui registros da proposta em processamento (gstcProposta).
Dim lMensagem       As String   'Mensagem.
Dim lDelete         As String

    If pSohValidacao = True Then
        GoTo SAIDA
    End If

    lDelete = "DELETE FROM " & gOwner & "tab_ajuste_premio WHERE Num_Proposta = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
    lDelete = "DELETE FROM " & gOwner & "P0042700 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
    lDelete = "DELETE FROM " & gOwner & "P0042600 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
    lDelete = "DELETE FROM " & gOwner & "P0042400 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
    lDelete = "DELETE FROM " & gOwner & "P0042300 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
    lDelete = "DELETE FROM " & gOwner & "P0042200 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
    lDelete = "DELETE FROM " & gOwner & "P0042100 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    lDelete = "DELETE FROM " & gOwner & "P0042601 WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
    
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    lDelete = "DELETE FROM " & gOwner & "TAB_HIST_ROTEIRO_CALCULO WHERE Nosso_Numero = '" & pstcProposta.RegNosNumero & "'"
    If InStr(1, gOwner, "ftp_") > 0 Then
        lDelete = lDelete & " AND Cod_Unicidade = " & pstcProposta.CodUnicidade
    End If
    'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
    
    Call mfExeSQL(pCN, lDelete, lMensagem)
    
SAIDA:
    Exit Sub
    
End Sub

Private Function mfCalCodUnicidade(ByVal pNosNumero As String, _
                                   ByVal pP0042100 As ADODB.Recordset, _
                                   ByVal pP0042200 As ADODB.Recordset, _
                                   ByVal pP0042600 As ADODB.Recordset, _
                                   ByVal pP0042700 As ADODB.Recordset, _
                                   ByRef pCN As ADODB.Connection, _
                                   ByRef pCodVerificacao As String, ByRef pMensagem As String)
    'Fun��o: Calcula c�digo de verifica��o da unicidade.

    'Obs.: Esta fun��o foi copiada do programa P28V100 e adaptada para a situa��o do programa P28V300.

    'Par�metros de entrada...pNosNumero........Nosso n�mero.
    '                        pP0042100.........Registros P0042100.
    '                        pP0042200.........Registros P0042200.
    '                        pP0042400.........Registros P0042400.
    '                        pP0042500.........Registros P0042500.
    'Par�metros de sa�da.....pCodVerificacao...C�digo de verifica��o.
    '                        pMensagem.........Mensagem.

Dim lAuxiliar           As String           'Auxiliar.
Dim lCampo1()           As String           'Campos utilizados para dividir a seq��ncia em campos de
                                            '10 posi��es cada.
Dim lCampo2()           As Integer          'Campos com totais das somas das posi��es de lCampo1.
Dim lClaBonus           As Byte             'Classe do b�nus.
Dim lDatEmiDocumento    As String           'Pessoa f�sica: data de emiss�o do documento.
Dim lI                  As Integer          'Utilizado com For...Next.
Dim lIS_APPDMH          As Double           'Import�ncia segurada de APP - DMH.
Dim lIS_APPInvalidez    As Double           'Import�ncia segurada de APP - invalidez.
Dim lIS_APPMorte        As Double           'Import�ncia segurada de APP - Morte.
Dim lIS_Casco           As Double           'Import�ncia segurada de casco.
Dim lIS_RCDC            As Double           'Import�ncia segurada de RC-DC.
Dim lIS_RCDM            As Double           'Import�ncia segurada de RC-DM.
Dim lIS_RCMO            As Double           'Import�ncia segurada de RC-MO.
Dim lNivRCDC            As Byte             'N�vel de cobertura RC-DC.
Dim lNivRCDM            As Byte             'N�vel de cobertura RC-DM.
Dim lNumDocumento       As String           'Pessoa f�sica: n�mero do documento.
Dim lOrgEmiDocumento    As String           'Pessoa f�sica: �rg�o emissor do documento.
Dim lPerDesAPP          As Double           'Percentual de desconto de APP.
Dim lPerDesBonus        As Double           'Percentual de desconto de b�nus.
Dim lPerDesCasco        As Double           'Percentual de desconto de casco.
Dim lPerDesFidelidade   As Double           'Percentual de desconto de fidelidade.
Dim lPerDesFrota        As Double           'Percentual de desconto de frota.
Dim lPerDesPerfil       As Double           'Percentual de desconto de perfil.
Dim lPerDesRC           As Double           'Percentual de desconto de RC.
Dim lRamAtividade       As String           'Pessoa jur�dica: ramo de atividade.
Dim lResto              As Byte             'Resto da divis�o.
Dim lResultado          As Integer          'Resultado da divis�o.
Dim lSequencia          As String           'Seq��ncia para c�lculo do c�digo de unicidade.
Dim lTamanho            As Double           'Tamanho.
Dim lTipDocumento       As String           'Pessoa f�sica: tipo do documento.
Dim lTotal              As Double           'Total.
Dim rsP0042300          As ADODB.Recordset  'Registro P0042300.
Dim lSelect             As String
    mfCalCodUnicidade = False

    '1. Obt�m registro de dados comuns.
    '   J� foi obtido o registro de dados comuns - pP0042100.

    '2. Obt�m registro de identifica��o do segurado.
    lSelect = "SELECT * FROM P0042300 WHERE Nosso_Numero = '" & pNosNumero & _
              "' AND Num_Item = 0 AND Num_Linha = 0"
    If gfObtRegistro(pCN, lSelect, rsP0042300, pMensagem) = False Then
        Exit Function
    End If
    Select Case pP0042100!Tip_Pessoa
        Case 1      'Pessoa jur�dica.
            Do
                'a) Registro de identifica��o do segurado.
                If rsP0042300.RecordCount = 0 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                lTamanho = Len(Trim$(rsP0042300!Observacao))
                If lTamanho = 0 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                'b) Ramo de atividade - 2 posi��es num�ricas.
                If lTamanho < 3 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 2, 2)) Then
                    lRamAtividade = Mid$(rsP0042300!Observacao, 2, 2)
                Else
                    lRamAtividade = "00"
                End If
                Exit Do
            Loop
        Case 2      'Pessoa f�sica.
            lTipDocumento = "00"
            lNumDocumento = String(20, " ")
            lOrgEmiDocumento = String(20, " ")
            lDatEmiDocumento = String(8, "0")
            Do
                'a) Registro de identifica��o do segurado.
                If rsP0042300.RecordCount = 0 Then
                    Exit Do
                End If
                lTamanho = Len(Trim$(rsP0042300!Observacao))
                If lTamanho = 0 Then
                    Exit Do
                End If
                'b) Tipo do documento - 2 posi��es num�ricas.
                If lTamanho < 3 Then
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 2, 2)) Then
                    lTipDocumento = Mid$(rsP0042300!Observacao, 2, 2)       'CORRIGIDO.
                End If
                'c) N�mero do documento - 20 posi��es.
                If lTamanho = 3 Then
                    Exit Do
                End If
                If lTamanho < 23 Then
                    lNumDocumento = Mid$(rsP0042300!Observacao, 4)
                    While Len(lNumDocumento) < 20
                        lNumDocumento = lNumDocumento & " "
                    Wend
                Else
                    lNumDocumento = Mid$(rsP0042300!Observacao, 4, 20)
                End If
                'd) �rg�o emissor do documento - 20 posi��es.
                If lTamanho = 23 Then
                    Exit Do
                End If
                If lTamanho < 43 Then
                    lOrgEmiDocumento = Mid$(rsP0042300!Observacao, 24)
                    While Len(lOrgEmiDocumento) < 20
                        lOrgEmiDocumento = lOrgEmiDocumento & " "
                    Wend
                Else
                    lOrgEmiDocumento = Mid$(rsP0042300!Observacao, 24, 20)
                End If
                'e) Data de emiss�o do documento - 8 posi��es num�ricas.
                If lTamanho < 51 Then
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 44, 8)) Then
                    lDatEmiDocumento = Mid$(rsP0042300!Observacao, 44, 8)
                End If
                Exit Do
            Loop
    End Select
    Call gpFecha1(rsP0042300)

    '3. Inicia seq��ncia para c�lculo do c�digo de unicidade com dados comuns.
    '===001) Nosso n�mero......................................................(20 posi��es - total = 20).
    lSequencia = pP0042100!NOSSO_NUMERO
    '===002) Refer�ncia.........................................................(6 posi��es - total = 26).
    lSequencia = lSequencia & Format$(pP0042100!Num_Referencia, "000000")
    '===003) C�digo do corretor.................................................(7 posi��es - total = 33).
    lSequencia = lSequencia & Format$(pP0042100!Cor1_Codigo, "0000000")
    '===004) C�digo do produto (tarifa).........................................(4 posi��es - total = 37).
    lSequencia = lSequencia & Format$(pP0042100!Cod_Produto, "0000")
    '===005) C�digo da unidade de neg�cios......................................(5 posi��es - total = 42).
    lSequencia = lSequencia & Format$(pP0042100!COD_UNID_PROD, "00000")
    '===006) C�digo do produtor.................................................(5 posi��es - total = 47).
    lSequencia = lSequencia & Format$(pP0042100!Cod_Produtor, "00000")
    '===007) Nome do proponente (segurado)....................................(60 posi��es - total = 107).
    lAuxiliar = UCase$(pP0042100!NOM_SEGURADO)
    If Len(lAuxiliar) > 60 Then
        lAuxiliar = Left$(lAuxiliar, 60)
    Else
        While Len(lAuxiliar) < 60
            lAuxiliar = lAuxiliar & " "
        Wend
    End If
    lSequencia = lSequencia & lAuxiliar
    '===008) C�digo do segurado................................................(7 posi��es - total = 114).
    If gfPreenchido(pP0042100!COD_SEGURADO) Then
        If IsNumeric(pP0042100!COD_SEGURADO) Then
            lAuxiliar = Format$(Val(pP0042100!COD_SEGURADO), "0000000")
        Else
            lAuxiliar = String(7, "0")
        End If
    Else
        lAuxiliar = String(7, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===009) Tipo de pessoa.....................................................(1 posi��o - total = 115).
    '===010) Identifica��o....................................................(61 posi��es - total = 176).
    Select Case pP0042100!Tip_Pessoa
        Case 1
            'a) Tipo de pessoa.
            lAuxiliar = "J"
            'b) CNPJ - 14 posi��es num�ricas.
            lAuxiliar = lAuxiliar & gfForCNPJ(CStr(pP0042100!CNPJ_CPF), 14)
            'c) Ramo de atividade - 2 posi��es num�ricas.
            lAuxiliar = lAuxiliar & lRamAtividade
            'd) Completa com espa�os.
            lAuxiliar = lAuxiliar & String(45, " ")
        Case 2
            'a) Tipo de pessoa.
            lAuxiliar = "F"
            'b) CPF - 11 posi��es num�ricas.
            lAuxiliar = lAuxiliar & Format$(pP0042100!CNPJ_CPF, "00000000000")
            'c) Tipo do documento - 2 posi��es num�ricas.
            lAuxiliar = lAuxiliar & lTipDocumento
            'd) N�mero do documento - 20 posi��es.
            lAuxiliar = lAuxiliar & lNumDocumento
            'e) �rg�o emissor do documento - 20 posi��es.
            lAuxiliar = lAuxiliar & lOrgEmiDocumento
            'f) Data de emiss�o do documento - 8 posi��es num�ricas (aaaammdd).
            lAuxiliar = lAuxiliar & lDatEmiDocumento
    End Select
    lSequencia = lSequencia & lAuxiliar
    '===011) Endere�o do segurado - logradouro................................(73 posi��es - total = 249).
    lAuxiliar = ""
    If gfPreenchido(pP0042100!End_Tip_Logradouro) Then
        lAuxiliar = Trim$(pP0042100!End_Tip_Logradouro) & " "
    End If
    If gfPreenchido(pP0042100!End_Nom_Logradouro) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!End_Nom_Logradouro) & " "       'CORRIGIDO.
    End If
    If gfPreenchido(pP0042100!End_Complemento) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!End_Complemento)
    End If
    If Len(lAuxiliar) > 73 Then
        lAuxiliar = Left$(lAuxiliar, 73)
    Else
        While Len(lAuxiliar) < 73
            lAuxiliar = lAuxiliar & " "
        Wend
    End If
    lSequencia = lSequencia & lAuxiliar
    '===012) Endere�o do segurado - bairro....................................(30 posi��es - total = 279).
    If gfPreenchido(pP0042100!End_Bairro) Then
        lAuxiliar = pP0042100!End_Bairro
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===013) Endere�o do segurado - cidade....................................(30 posi��es - total = 309).
    If gfPreenchido(pP0042100!End_Cidade) Then
        lAuxiliar = pP0042100!End_Cidade
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===014) Endere�o do segurado - unidade da federa��o.......................(2 posi��es - total = 311).
    If gfPreenchido(pP0042100!End_UF) Then
        lAuxiliar = pP0042100!End_UF
        While Len(lAuxiliar) < 2
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(2, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===015) Endere�o do segurado - CEP........................................(8 posi��es - total = 319).
    If gfPreenchido(pP0042100!End_CEP) Then
        lAuxiliar = pP0042100!End_CEP
        While Len(lAuxiliar) < 8
            lAuxiliar = "0" & lAuxiliar
        Wend
    Else
        lAuxiliar = String(8, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===016) Endere�o do segurado - telefones.................................(30 posi��es - total = 349).
    If gfPreenchido(pP0042100!End_Telefones) Then
        lAuxiliar = pP0042100!End_Telefones
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===017) Endere�o de cobran�a - logradouro................................(73 posi��es - total = 422).
    lAuxiliar = ""
    If gfPreenchido(pP0042100!Cob_Tip_Logradouro) Then
        lAuxiliar = Trim$(pP0042100!Cob_Tip_Logradouro) & " "
    End If
    If gfPreenchido(pP0042100!Cob_Nom_Logradouro) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!Cob_Nom_Logradouro) & " "       'CORRIGIDO.
    End If
    If gfPreenchido(pP0042100!Cob_Complemento) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!Cob_Complemento)
    End If
    If Len(lAuxiliar) > 73 Then
        lAuxiliar = Left$(lAuxiliar, 73)
    Else
        While Len(lAuxiliar) < 73
            lAuxiliar = lAuxiliar & " "
        Wend
    End If
    lSequencia = lSequencia & lAuxiliar
    '===018) Endere�o de cobran�a - bairro....................................(30 posi��es - total = 452).
    If gfPreenchido(pP0042100!Cob_Bairro) Then
        lAuxiliar = pP0042100!Cob_Bairro
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===019) Endere�o de cobran�a - cidade....................................(30 posi��es - total = 482).
    If gfPreenchido(pP0042100!Cob_Cidade) Then
        lAuxiliar = pP0042100!Cob_Cidade
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===020) Endere�o de cobran�a - unidade da federa��o.......................(2 posi��es - total = 484).
    If gfPreenchido(pP0042100!Cob_UF) Then
        lAuxiliar = pP0042100!Cob_UF
        While Len(lAuxiliar) < 2
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(2, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===021) Endere�o de cobran�a - CEP........................................(8 posi��es - total = 492).
    If gfPreenchido(pP0042100!Cob_CEP) Then
        lAuxiliar = pP0042100!Cob_CEP
        While Len(lAuxiliar) < 8
            lAuxiliar = "0" & lAuxiliar
        Wend
    Else
        lAuxiliar = String(8, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===022) Endere�o de cobran�a - telefones.................................(30 posi��es - total = 522).
    If gfPreenchido(pP0042100!Cob_Telefones) Then
        lAuxiliar = pP0042100!Cob_Telefones
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===023) In�cio de vig�ncia................................................(8 posi��es - total = 530).
    lSequencia = lSequencia & Format$(pP0042100!Dat_Vig_Inicio, "00000000")
    '===024) T�rmino de vig�ncia...............................................(8 posi��es - total = 538).
    lSequencia = lSequencia & Format$(pP0042100!Dat_Vig_Termino, "00000000")
    '===025) Corretagem.......................................................(33 posi��es - total = 571).
    lSequencia = lSequencia & Format$(pP0042100!Cor1_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor1_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cor2_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor2_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cor3_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor3_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===026) Cosseguros.......................................................(50 posi��es - total = 621).
    lSequencia = lSequencia & Format$(pP0042100!Cos1_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos1_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos2_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos2_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos3_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos3_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos4_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos4_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos5_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos5_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===027) Juros ao m�s......................................................(4 posi��es - total = 625).
    Select Case pP0042100!Pag_Ant_Ind
        Case 1, 2       'Pagamento antecipado.
            Select Case pP0042100!Qtd_Parcelas_VM
                Case 0
                    lAuxiliar = "00,00"
                Case 1
                    lAuxiliar = Format$(pP0042100!Jur_Ant_01, "00.00")
                Case 2
                    lAuxiliar = Format$(pP0042100!Jur_Ant_02, "00.00")
                Case 3
                    lAuxiliar = Format$(pP0042100!Jur_Ant_03, "00.00")
                Case 4
                    lAuxiliar = Format$(pP0042100!Jur_Ant_04, "00.00")
                Case 5
                    lAuxiliar = Format$(pP0042100!Jur_Ant_05, "00.00")
                Case 6
                    lAuxiliar = Format$(pP0042100!Jur_Ant_06, "00.00")
                Case 7
                    lAuxiliar = Format$(pP0042100!Jur_Ant_07, "00.00")
                Case 8
                    lAuxiliar = Format$(pP0042100!Jur_Ant_08, "00.00")
                Case 9
                    lAuxiliar = Format$(pP0042100!Jur_Ant_09, "00.00")
                Case 10
                    lAuxiliar = Format$(pP0042100!Jur_Ant_10, "00.00")
                Case 11
                    lAuxiliar = Format$(pP0042100!Jur_Ant_11, "00.00")
                Case 12
                    lAuxiliar = Format$(pP0042100!Jur_Ant_12, "00.00")
            End Select
        Case 9      'Pagamento postecipado.
            Select Case pP0042100!Qtd_Parcelas_VM
                Case 0
                    lAuxiliar = "00,00"
                Case 1
                    lAuxiliar = Format$(pP0042100!Jur_Pos_01, "00.00")
                Case 2
                    lAuxiliar = Format$(pP0042100!Jur_Pos_02, "00.00")
                Case 3
                    lAuxiliar = Format$(pP0042100!Jur_Pos_03, "00.00")
                Case 4
                    lAuxiliar = Format$(pP0042100!Jur_Pos_04, "00.00")
                Case 5
                    lAuxiliar = Format$(pP0042100!Jur_Pos_05, "00.00")
                Case 6
                    lAuxiliar = Format$(pP0042100!Jur_Pos_06, "00.00")
                Case 7
                    lAuxiliar = Format$(pP0042100!Jur_Pos_07, "00.00")
                Case 8
                    lAuxiliar = Format$(pP0042100!Jur_Pos_08, "00.00")
                Case 9
                    lAuxiliar = Format$(pP0042100!Jur_Pos_09, "00.00")
                Case 10
                    lAuxiliar = Format$(pP0042100!Jur_Pos_10, "00.00")
                Case 11
                    lAuxiliar = Format$(pP0042100!Jur_Pos_11, "00.00")
                Case 12
                    lAuxiliar = Format$(pP0042100!Jur_Pos_12, "00.00")
            End Select
    End Select
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===028) Custo da ap�lice.................................................(10 posi��es - total = 635).
    lAuxiliar = Format$(pP0042100!Cus_Emissao, "00000000.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===029) Valor do IOF.....................................................(10 posi��es - total = 645).
    If pP0042100!Val_IOF_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_IOF_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_IOF_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===030) N�mero de parcelas................................................(2 posi��es - total = 647).
    lAuxiliar = Format$(pP0042100!Qtd_Parcelas_VM, "00")
    lSequencia = lSequencia & lAuxiliar
    '===031) Indicador de primeira parcela paga antecipada......................(1 posi��o - total = 648).
    lAuxiliar = Format$(pP0042100!Pag_Ant_Ind, "0")
    lSequencia = lSequencia & lAuxiliar
    '===032) Valor da primeira parcela........................................(10 posi��es - total = 658).
    If pP0042100!Val_Parcela1_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_Parcela1_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_Parcela1_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===033) Valor das demais parcelas........................................(10 posi��es - total = 668).
    If pP0042100!Val_Parcelas_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_Parcelas_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_Parcelas_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===034) Pagamento em bloqueto - n�mero do bloqueto.......................(10 posi��es - total = 678).
    lSequencia = lSequencia & Format$(pP0042100!Pag_Ant_Bloqueto, "0000000000")
    '===035) Pagamento atrav�s de carn�.......................................(11 posi��es - total = 689).
    'a) C�digo do banco.
    lSequencia = lSequencia & Format$(pP0042100!Carne_Cod_Banco, "000")
    'b) Vencimento da primeira parcela.
    lSequencia = lSequencia & Format$(pP0042100!Ven_Parcela1_VM, "00000000")
    '===036) Pagamento atrav�s de d�bito em conta.............................(18 posi��es - total = 707).
    'a) C�digo do banco.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Banco, "000")
    'b) C�digo da ag�ncia.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Agencia, "0000")
    'c) C�digo da conta corrente.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Conta, "000000000")
    'd) Dia para d�bito.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Dia, "00")
    '===037) Juros de mora.....................................................(4 posi��es - total = 711).
    lSequencia = lSequencia & "0450"

    '4. Obt�m dados dos itens - j� foram obtidos os registros dos itens - pP0042200.
    'a) Verifica base de dados.
    If pP0042200.RecordCount = 0 Then
        pMensagem = "FTE0056 - " & gPrefixo & _
                    "N�o localizado registro de item (c�lculo do c�digo de unicidade)."
        Exit Function
    End If
    'b) Coberturas dos itens - j� foram obtidos os registros de coberturas dos itens - pP0042600.
    'c) Descontos dos itens - j� foram obtidos os registros de descontos dos itens - pP0042700.

    '5. Continua seq��ncia para c�lculo do c�digo de unicidade com dados dos itens.
    pP0042200.MoveFirst
    While Not pP0042200.EOF
        'a) Obt�m valores das coberturas.
        lIS_Casco = 0
        lNivRCDM = 0
        lIS_RCDM = 0
        lNivRCDC = 0
        lIS_RCDC = 0
        lIS_RCMO = 0
        lIS_APPMorte = 0
        lIS_APPInvalidez = 0
        lIS_APPDMH = 0
        If pP0042600.RecordCount <> 0 Then
            pP0042600.MoveFirst
            While Not pP0042600.EOF
                If pP0042600!Num_Item = pP0042200!Num_Item Then
                    Select Case pP0042600!Cod_Cobert
                        Case gCobCasco
                            lIS_Casco = pP0042600!Val_IS
                        Case gCobRCDM
                            lNivRCDM = pP0042600!Cod_Niv_IS
                            lIS_RCDM = pP0042600!Val_IS
                        Case gCobRCDC
                            lNivRCDC = pP0042600!Cod_Niv_IS
                            lIS_RCDC = pP0042600!Val_IS
                        Case gCobRCMO
                            lIS_RCMO = pP0042600!Val_IS
                        Case gCobAPPMorte
                            lIS_APPMorte = pP0042600!Val_IS
                        Case gCobAPPInvalidez
                            lIS_APPInvalidez = pP0042600!Val_IS
                        Case gCobAPPDMH
                            lIS_APPDMH = pP0042600!Val_IS
                    End Select
                End If
                pP0042600.MoveNext
            Wend
        End If

        'b) Obt�m percentuais de desconto.
        lClaBonus = 0
        lPerDesAPP = 0
        lPerDesBonus = 0
        lPerDesCasco = 0
        lPerDesFidelidade = 0
        lPerDesFrota = 0
        lPerDesPerfil = 0
        lPerDesRC = 0
        If pP0042700.RecordCount <> 0 Then
            pP0042700.MoveFirst
            While Not pP0042700.EOF
                If pP0042700!Num_Item = pP0042200!Num_Item Then
                    Select Case pP0042700!Cod_Desc
                        Case gDesAPP
                            lPerDesAPP = pP0042700!Per_Desc
                        Case gDesBonus
                            lPerDesBonus = pP0042700!Per_Desc
                            lClaBonus = pP0042700!Cod_Classe_Desc
                        Case gDesCasco
                            lPerDesCasco = pP0042700!Per_Desc
                        Case gDesFidelidade
                            lPerDesFidelidade = pP0042700!Per_Desc
                        Case gDesFrota
                            lPerDesFrota = pP0042700!Per_Desc
                        Case gDesPerfil
                            lPerDesPerfil = pP0042700!Per_Desc
                        Case gDesRC
                            lPerDesRC = pP0042700!Per_Desc
                    End Select
                End If
                pP0042700.MoveNext
            Wend
        End If

        'c) Continua seq��ncia para c�lculo do c�digo de unicidade com dados do item.
        '===038) N�mero do item..................................................(4 posi��es - total = 4).
        lSequencia = lSequencia & Format$(pP0042200!Num_Item, "0000")
        '===039) Tipo de emiss�o.................................................(3 posi��es - total = 7).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Emissao, "000")
        '===040) Tipo do produto..................................................(1 posi��o - total = 8).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Produto, "0")
        '===041) C�digo do ve�culo..............................................(8 posi��es - total = 16).
        lSequencia = lSequencia & pP0042200!Cod_Veiculo
        '===042) C�digo Renavam................................................(10 posi��es - total = 26).
        lSequencia = lSequencia & Format$(pP0042200!Val_Cus_Emissao, "0000000000")
        '===043) Ano de fabrica��o..............................................(4 posi��es - total = 30).
        lSequencia = lSequencia & Format$(pP0042200!Ano_Fabricacao, "0000")
        '===044) Ano de modelo..................................................(4 posi��es - total = 34).
        lSequencia = lSequencia & Format$(pP0042200!Ano_Modelo, "0000")
        '===045) Indicador de ve�culo 0 km.......................................(1 posi��o - total = 35).
        lSequencia = lSequencia & Format$(pP0042200!COD_IDEN_0KM, "0")
        '===046) C�digo da placa................................................(8 posi��es - total = 43).
        lAuxiliar = UCase$(pP0042200!Cod_Placa)
        While Len(lAuxiliar) < 8
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===047) Tipo do combust�vel.............................................(1 posi��o - total = 44).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Combustivel, "0")
        '===048) C�digo da chassi nacional.....................................(20 posi��es - total = 64).
        lAuxiliar = UCase$(pP0042200!Cod_Chassi)
        While Len(lAuxiliar) < 20
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===049) C�digo da chassi estrangeiro..................................(20 posi��es - total = 84).
        lAuxiliar = UCase$(pP0042200!Cod_Chassi_Estrang)
        While Len(lAuxiliar) < 20
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===050) C�digo FIPE....................................................(6 posi��es - total = 90).
        lSequencia = lSequencia & Format$(pP0042200!Cod_FIPE, "000000")
        '===051) Categoria......................................................(2 posi��es - total = 92).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Categoria, "00")
        '===052) CEP de pernoite...............................................(8 posi��es - total = 100).
        lSequencia = lSequencia & Format$(pP0042200!Cep_Regiao, "00000000")
        '===053) Franquia de casco............................................(10 posi��es - total = 110).
        If pP0042200!Val_Franquia_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Val_Franquia_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Val_Franquia_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===054) Indicador de question�rio de avalia��o de risco................(1 posi��o - total = 111).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Questionario, "0")
        '===055) Renova��o Yasuda - n�mero da ap�lice.........................(10 posi��es - total = 121).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Num_Apolice, "0000000000")
        '===056) Renova��o Yasuda - item da ap�lice............................(4 posi��es - total = 125).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Num_Item, "0000")
        '===057) Indicador da exist�ncia do benefici�rio........................(1 posi��o - total = 126).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Beneficiario, "0")
        '===058) Nome do benefici�rio.........................................(20 posi��es - total = 146).
        lAuxiliar = UCase$(pP0042200!Nom_Beneficiario)
        While Len(lAuxiliar) < 20
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===059) Nome do propriet�rio.........................................(30 posi��es - total = 176).
        lAuxiliar = UCase$(pP0042200!Nom_Proprietario)
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===060) Tipo do cobertura..............................................(1 posi��o - total = 177).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Cobertura, "0")
        '===061) Tipo da assist�ncia 24 horas (tipo do limite de guincho).......(1 posi��o - total = 178).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Lim_Guincho, "0")
        '===062) Cl�usula 112 (s�cio/dirigente).................................(1 posi��o - total = 179).
        lSequencia = lSequencia & Format$(pP0042200!Soc_Dirigente, "0")
        '===063) Cobertura de carro reserva.....................................(1 posi��o - total = 180).
        lSequencia = lSequencia & Format$(pP0042200!Carro_Reserva, "0")
        '===064) Cobertura de vidros............................................(1 posi��o - total = 181).
        lSequencia = lSequencia & Format$(pP0042200!COD_IDEN_VIDROS, "0")
        '===065) Cobertura de extens�o para ve�culos 0 km.......................(1 posi��o - total = 182).
        lSequencia = lSequencia & Format$(pP0042200!Ext_0km, "0")
        '===066) Acess�rio de f�brica - ar condicionado.........................(1 posi��o - total = 183).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Ar_Condic, "0")
        '===067) Acess�rio de f�brica - bancos de couro.........................(1 posi��o - total = 184).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Ban_Couro, "0")
        '===068) Acess�rio de f�brica - freios ABS..............................(1 posi��o - total = 185).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Fre_ABS, "0")
        '===069) Acess�rio de f�brica - dire��o hidr�ulica......................(1 posi��o - total = 186).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Dir_Hidra, "0")
        '===070) Acess�rio de f�brica - c�mbio autom�rico.......................(1 posi��o - total = 187).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Cam_Autom, "0")
        '===071) Acess�rio de f�brica - air bag.................................(1 posi��o - total = 188).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Air_Bag, "0")
        '===072) Acess�rios...................................................(65 posi��es - total = 253).
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_1, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_1, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_2, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_2, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_3, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_3, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!Cod_Aces_4, "000")
        lAuxiliar = Format$(pP0042200!Val_IS_Aces_4, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!Cod_Aces_5, "000")
        lAuxiliar = Format$(pP0042200!Val_IS_Aces_5, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===073) Desconto de casco.............................................(4 posi��es - total = 257).
        lAuxiliar = Format$(lPerDesCasco, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===074) Desconto de RCF...............................................(4 posi��es - total = 261).
        lAuxiliar = Format$(lPerDesRC, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===075) Desconto de APP...............................................(4 posi��es - total = 265).
        lAuxiliar = Format$(lPerDesAPP, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===076) Classe de b�nus...............................................(2 posi��es - total = 267).
        lSequencia = lSequencia & Format$(lClaBonus, "00")
        '===077) Percentual de desconto de b�nus...............................(4 posi��es - total = 271).
        lAuxiliar = Format$(lPerDesBonus, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===078) Desconto de frota.............................................(4 posi��es - total = 275).
        lAuxiliar = Format$(lPerDesFrota, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===079) Renova��o de cong�nere - c�digo da seguradora.................(3 posi��es - total = 278).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Con_Seguradora, "000")
        '===080) Renova��o de cong�nere - c�digo da ap�lice...................(15 posi��es - total = 293).
        lAuxiliar = UCase$(pP0042200!Ren_Con_Apolice)
        While Len(lAuxiliar) < 15
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===081) Renova��o de cong�nere - item da ap�lice......................(5 posi��es - total = 298).
        lAuxiliar = UCase$(pP0042200!Ren_Con_Item)
        While Len(lAuxiliar) < 5
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===082) Renova��o de cong�nere - c�digo de identifica��o.............(14 posi��es - total = 312).
        lAuxiliar = ""
        If gfPreenchido(pP0042200!Clausula1) Then
            lAuxiliar = pP0042200!Clausula1
        End If
        If gfPreenchido(pP0042200!Clausula2) Then
            lAuxiliar = lAuxiliar & pP0042200!Clausula2
        End If
        If gfPreenchido(pP0042200!Clausula3) Then
            lAuxiliar = lAuxiliar & pP0042200!Clausula3
        End If
        If Len(lAuxiliar) > 14 Then
            lAuxiliar = Left$(lAuxiliar, 14)
        Else
            While Len(lAuxiliar) < 14
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===083) Renova��o de cong�nere - indicador de sinistro.................(1 posi��o - total = 313).
        lSequencia = lSequencia & Format$(pP0042200!Ind_Sinistro, "0")
        '===084) Import�ncia segurada de casco................................(10 posi��es - total = 323).
        lAuxiliar = Format$(lIS_Casco, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===085) N�vel do cobertura RC-DM......................................(2 posi��es - total = 325).
        lSequencia = lSequencia & Format$(lNivRCDM, "00")
        '===086) Import�ncia segurada de RC-DM................................(10 posi��es - total = 335).
        lAuxiliar = Format$(lIS_RCDM, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===087) N�vel do cobertura RC-DC......................................(2 posi��es - total = 337).
        lSequencia = lSequencia & Format$(lNivRCDC, "00")
        '===088) Import�ncia segurada de RC-DC................................(10 posi��es - total = 347).
        lAuxiliar = Format$(lIS_RCDC, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===089) Import�ncia segurada de RC-MO................................(10 posi��es - total = 357).
        lAuxiliar = Format$(lIS_RCMO, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===090) Import�ncia segurada de APP Morte............................(10 posi��es - total = 367).
        lAuxiliar = Format$(lIS_APPMorte, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===091) Import�ncia segurada de APP Invalidez permanente.............(10 posi��es - total = 377).
        lAuxiliar = Format$(lIS_APPInvalidez, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===092) Import�ncia segurada de APP DMH..............................(10 posi��es - total = 387).
        lAuxiliar = Format$(lIS_APPDMH, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===093) Pr�mio de casco..............................................(10 posi��es - total = 397).
        If pP0042200!Pr_Casco_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Casco_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Casco_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===094) Pr�mio de despesas extraodrin�rias...........................(10 posi��es - total = 407).
        If pP0042200!Pr_Des_Extr_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Des_Extr_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Des_Extr_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===095) Pr�mio de acess�rios.........................................(10 posi��es - total = 417).
        If pP0042200!Pr_Acessorios_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Acessorios_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Acessorios_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===096) Pr�mio de RC-DM..............................................(10 posi��es - total = 427).
        If pP0042200!Pr_RCDM_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCDM_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCDM_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===097) Pr�mio de RC-DC..............................................(10 posi��es - total = 437).
        If pP0042200!Pr_RCDC_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCDC_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCDC_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===098) Pr�mio da cl�usula 112 (s�cio/dirigente).....................(10 posi��es - total = 447).
        lSequencia = lSequencia & "0000000000"
        '===099) Pr�mio de RC-MO..............................................(10 posi��es - total = 457).
        If pP0042200!Pr_RCMO_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCMO_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCMO_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===100) Pr�mio de APP................................................(10 posi��es - total = 467).
        If pP0042200!Pr_APP_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_APP_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_APP_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===101) Pr�mio de assist�ncia 24 horas...............................(10 posi��es - total = 477).
        If pP0042200!Pr_Ass_24hs_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Ass_24hs_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Ass_24hs_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===102) Pr�mio de carro reserva......................................(10 posi��es - total = 487).
        If pP0042200!Pr_Carro_Reserva_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Carro_Reserva_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Carro_Reserva_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===103) Pr�mio de vidros.............................................(10 posi��es - total = 497).
        If pP0042200!Pr_Vidros_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Vidros_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Vidros_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===104) Pr�mio de extens�o para ve�culo 0 km.........................(10 posi��es - total = 507).
        If pP0042200!Pr_Ext_0km_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Ext_0km_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Ext_0km_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===105) Pr�mio l�quido...............................................(10 posi��es - total = 517).
        If pP0042200!Pr_Liquido_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Liquido_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Liquido_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===106) Pr�mio total.................................................(10 posi��es - total = 527).
        If pP0042200!Pr_Total_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Total_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Total_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===107) Question�rio de avalia��o de risco - nome do condutor........(30 posi��es - total = 557).
        lAuxiliar = UCase$(pP0042200!Nom_Condutor)
        If Len(lAuxiliar) > 30 Then
            lAuxiliar = Left$(lAuxiliar, 30)
        Else
            While Len(lAuxiliar) < 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===108) Question�rio de avalia��o de risco - RG do condutor..........(20 posi��es - total = 577).
        lAuxiliar = UCase$(pP0042200!Cod_RG)
        If Len(lAuxiliar) > 20 Then
            lAuxiliar = Left$(lAuxiliar, 20)
        Else
            While Len(lAuxiliar) < 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===109) Question�rio de avalia��o de risco - CPF do condutor.........(11 posi��es - total = 588).
        lAuxiliar = UCase$(pP0042200!Cod_CPF)
        If Len(lAuxiliar) > 11 Then
            lAuxiliar = Left$(lAuxiliar, 11)
        Else
            While Len(lAuxiliar) < 11
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===110) Question�rio - rela��o do condutor com o proponente............(1 posi��o - total = 589).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Relacao, "0")
        '===111) Question�rio - outra rela��o do condutor.....................(20 posi��es - total = 609).
        lAuxiliar = UCase$(pP0042200!Dsc_Outra_Relacao)
        If Len(lAuxiliar) > 20 Then
            lAuxiliar = Left$(lAuxiliar, 20)
        Else
            While Len(lAuxiliar) < 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===112) Question�rio - estado civil do condutor........................(1 posi��o - total = 610).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Est_Civil)
        '===113) Question�rio - sexo do condutor................................(1 posi��o - total = 611).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Sexo)
        '===114) Question�rio - data de nascimento do condutor.................(8 posi��es - total = 619).
        lSequencia = lSequencia & Format$(pP0042200!Dat_Nasc, "00000000")
        '===115) Question�rio - ano da primeira habilita��o do condutor........(4 posi��es - total = 623).
        lSequencia = lSequencia & Format$(pP0042200!Dat_Pri_Habilit, "0000")
        '===116) Question�rio - garagem do ve�culo..............................(1 posi��o - total = 624).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Garagem)
        '===117) Question�rio - utiliza��o do ve�culo...........................(1 posi��o - total = 625).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Utiliza)
        '===118) Question�rio - ve�culo conduzido por pessoas 18 e 24 anos?.....(1 posi��o - total = 626).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Pessoas, "0")
        '===119) Question�rio - dispositivo de seguran�a 1......................(1 posi��o - total = 627).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_1, "0")
        '===120) Question�rio - dispositivo de seguran�a 2......................(1 posi��o - total = 628).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_2, "0")
        '===121) Question�rio - dispositivo de seguran�a 3......................(1 posi��o - total = 629).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_3, "0")
        '===122) Question�rio - dispositivo de seguran�a 4......................(1 posi��o - total = 630).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_4, "0")
        '===123) Question�rio - dispositivo de seguran�a 5......................(1 posi��o - total = 631).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_5, "0")

        'd) Pr�ximo item.
        pP0042200.MoveNext
    Wend

    '6. Preencher o campo de seq��ncia para que o tamanho fique em m�ltiplo de 10.
    lTamanho = Len(lSequencia)
    lResto = lTamanho Mod 10
    If lResto <> 0 Then
        lSequencia = lSequencia & String(10 - lResto, " ")
    End If

    '7. Dividir o campo de seq��ncia em campos de 10 posi��es cada.
    lTamanho = Len(lSequencia)
    lResultado = lTamanho / 10
    ReDim lCampo1(lResultado)
    For lI = 1 To lResultado
        lCampo1(lI) = Mid$(lSequencia, (CDbl((lI - 1)) * 10) + 1, 10)
    Next lI

    '8. Para cada campo de 10 posi��es, transforma cada caracter num valor ASC e soma estes valores.
    ReDim lCampo2(lResultado)
    For lI = 1 To lResultado
        lCampo2(lI) = Asc(Mid(lCampo1(lI), 1, 1)) + Asc(Mid(lCampo1(lI), 2, 1)) + _
                      Asc(Mid(lCampo1(lI), 3, 1)) + Asc(Mid(lCampo1(lI), 4, 1)) + _
                      Asc(Mid(lCampo1(lI), 5, 1)) + Asc(Mid(lCampo1(lI), 6, 1)) + _
                      Asc(Mid(lCampo1(lI), 7, 1)) + Asc(Mid(lCampo1(lI), 8, 1)) + _
                      Asc(Mid(lCampo1(lI), 9, 1)) + Asc(Mid(lCampo1(lI), 10, 1))
        'MsgBox "Resultado " & lI & " = " & lCampo2(lI)
    Next lI

    '9. Somar todos os resultados obtidos.
    lTotal = 0
    For lI = 1 To lResultado
        lTotal = lTotal + lCampo2(lI)
    Next lI

    '10. Resultado: c�digo de verifica��o.
    pCodVerificacao = Right$(Format$(lTotal, "000000"), 6)

    mfCalCodUnicidade = True
End Function

Private Function mfCalCodUniXXXXX1(ByVal pOpcao As Byte, _
                                   ByVal pNosNumero As String, _
                                   ByVal pP0042100 As ADODB.Recordset, _
                                   ByVal pP0042200 As ADODB.Recordset, _
                                   ByVal pP0042600 As ADODB.Recordset, _
                                   ByVal pP0042700 As ADODB.Recordset, _
                                   ByRef pCN As ADODB.Connection, _
                                   ByRef pCodVerificacao As String, ByRef pMensagem As String)
    'Fun��o: Calcula c�digo de verifica��o da unicidade.

    'Obs.: Esta fun��o tem 4 erros. N�o est�o sendo considerados:
    '      1. O tipo do documento para pessoa f�sica.
    '      2. O nome do logradouro do endere�o do segurado.
    '      3. O nome do logradouro do endere�o de cobran�a.
    '      4. O c�digo do produtor.
    '      Manter esta fun��o at� fevereiro de 2005, pois alguns corretores est�o com a vers�o do programa
    '      P28V100 antiga, cujo c�lculo est� com este erro.

    'Obs.: Esta fun��o foi copiada do programa P28V100 e adaptada para a situa��o do programa P28V300.

    'Par�metros de entrada...pOpcao............1 = calcula com data do documento para pessoa f�sica
    '                                              corretamente.
    '                                          2 = calcula com data do documento para pessoa f�sica
    '                                              zerada.
    '                        pNosNumero........Nosso n�mero.
    '                        pP0042100.........Registros P0042100.
    '                        pP0042200.........Registros P0042200.
    '                        pP0042400.........Registros P0042400.
    '                        pP0042500.........Registros P0042500.
    'Par�metros de sa�da.....pCodVerificacao...C�digo de verifica��o.
    '                        pMensagem.........Mensagem.

Dim lAuxiliar           As String           'Auxiliar.
Dim lCampo1()           As String           'Campos utilizados para dividir a seq��ncia em campos de
                                            '10 posi��es cada.
Dim lCampo2()           As Integer          'Campos com totais das somas das posi��es de lCampo1.
Dim lClaBonus           As Byte             'Classe do b�nus.
Dim lDatEmiDocumento    As String           'Pessoa f�sica: data de emiss�o do documento.
Dim lI                  As Integer          'Utilizado com For...Next.
Dim lIS_APPDMH          As Double           'Import�ncia segurada de APP - DMH.
Dim lIS_APPInvalidez    As Double           'Import�ncia segurada de APP - invalidez.
Dim lIS_APPMorte        As Double           'Import�ncia segurada de APP - Morte.
Dim lIS_Casco           As Double           'Import�ncia segurada de casco.
Dim lIS_RCDC            As Double           'Import�ncia segurada de RC-DC.
Dim lIS_RCDM            As Double           'Import�ncia segurada de RC-DM.
Dim lIS_RCMO            As Double           'Import�ncia segurada de RC-MO.
Dim lNivRCDC            As Byte             'N�vel de cobertura RC-DC.
Dim lNivRCDM            As Byte             'N�vel de cobertura RC-DM.
Dim lNumDocumento       As String           'Pessoa f�sica: n�mero do documento.
Dim lOrgEmiDocumento    As String           'Pessoa f�sica: �rg�o emissor do documento.
Dim lPerDesAPP          As Double           'Percentual de desconto de APP.
Dim lPerDesBonus        As Double           'Percentual de desconto de b�nus.
Dim lPerDesCasco        As Double           'Percentual de desconto de casco.
Dim lPerDesFidelidade   As Double           'Percentual de desconto de fidelidade.
Dim lPerDesFrota        As Double           'Percentual de desconto de frota.
Dim lPerDesPerfil       As Double           'Percentual de desconto de perfil.
Dim lPerDesRC           As Double           'Percentual de desconto de RC.
Dim lRamAtividade       As String           'Pessoa jur�dica: ramo de atividade.
Dim lResto              As Byte             'Resto da divis�o.
Dim lResultado          As Integer          'Resultado da divis�o.
Dim lSequencia          As String           'Seq��ncia para c�lculo do c�digo de unicidade.
Dim lTamanho            As Integer          'Tamanho.
Dim lTipDocumento       As String           'Pessoa f�sica: tipo do documento.
Dim lTotal              As Double           'Total.
Dim rsP0042300          As ADODB.Recordset  'Registro P0042300.
Dim lSelect             As String

    mfCalCodUniXXXXX1 = False

    '1. Obt�m registro de dados comuns.
    '   J� foi obtido o registro de dados comuns - pP0042100.

    '2. Obt�m registro de identifica��o do segurado.
    lSelect = "SELECT * FROM P0042300 WHERE Nosso_Numero = '" & pNosNumero & _
              "' AND Num_Item = 0 AND Num_Linha = 0"
    If gfObtRegistro(pCN, lSelect, rsP0042300, pMensagem) = False Then
        Exit Function
    End If
    Select Case pP0042100!Tip_Pessoa
        Case 1      'Pessoa jur�dica.
            Do
                'a) Registro de identifica��o do segurado.
                If rsP0042300.RecordCount = 0 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                lTamanho = Len(Trim$(rsP0042300!Observacao))
                If lTamanho = 0 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                'b) Ramo de atividade - 2 posi��es num�ricas.
                If lTamanho < 3 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 2, 2)) Then
                    lRamAtividade = Mid$(rsP0042300!Observacao, 2, 2)
                Else
                    lRamAtividade = "00"
                End If
                Exit Do
            Loop
        Case 2      'Pessoa f�sica.
            lTipDocumento = "00"
            lNumDocumento = String(20, " ")
            lOrgEmiDocumento = String(20, " ")
            lDatEmiDocumento = String(8, "0")
            Do
                'a) Registro de identifica��o do segurado.
                If rsP0042300.RecordCount = 0 Then
                    Exit Do
                End If
                lTamanho = Len(Trim$(rsP0042300!Observacao))
                If lTamanho = 0 Then
                    Exit Do
                End If
                'b) Tipo do documento - 2 posi��es num�ricas.
                If lTamanho < 3 Then
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 2, 2)) Then
                    lAuxiliar = Mid$(rsP0042300!Observacao, 2, 2) '<<<=== ERRO. Considerar lTipDocumento.
                End If
                'c) N�mero do documento - 20 posi��es.
                If lTamanho = 3 Then
                    Exit Do
                End If
                If lTamanho < 23 Then
                    lNumDocumento = Mid$(rsP0042300!Observacao, 4)
                    While Len(lNumDocumento) < 20
                        lNumDocumento = lNumDocumento & " "
                    Wend
                Else
                    lNumDocumento = Mid$(rsP0042300!Observacao, 4, 20)
                End If
                'd) �rg�o emissor do documento - 20 posi��es.
                If lTamanho = 23 Then
                    Exit Do
                End If
                If lTamanho < 43 Then
                    lOrgEmiDocumento = Mid$(rsP0042300!Observacao, 24)
                    While Len(lOrgEmiDocumento) < 20
                        lOrgEmiDocumento = lOrgEmiDocumento & " "
                    Wend
                Else
                    lOrgEmiDocumento = Mid$(rsP0042300!Observacao, 24, 20)
                End If
                'e) Data de emiss�o do documento - 8 posi��es num�ricas.
                If lTamanho < 51 Then
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 44, 8)) Then
                    lDatEmiDocumento = Mid$(rsP0042300!Observacao, 44, 8)
                End If
                Exit Do
            Loop
    End Select
    Call gpFecha1(rsP0042300)

    '3. Inicia seq��ncia para c�lculo do c�digo de unicidade com dados comuns.
    '===001) Nosso n�mero......................................................(20 posi��es - total = 20).
    lSequencia = pP0042100!NOSSO_NUMERO
    '===002) Refer�ncia.........................................................(6 posi��es - total = 26).
    lSequencia = lSequencia & Format$(pP0042100!Num_Referencia, "000000")
    '===003) C�digo do corretor.................................................(7 posi��es - total = 33).
    lSequencia = lSequencia & Format$(pP0042100!Cor1_Codigo, "0000000")
    '===004) C�digo do produto (tarifa).........................................(4 posi��es - total = 37).
    lSequencia = lSequencia & Format$(pP0042100!Cod_Produto, "0000")
    '===005) C�digo da unidade produtiva........................................(5 posi��es - total = 42).
    lSequencia = lSequencia & Format$(pP0042100!COD_UNID_PROD, "00000")
    '===006) C�digo do produtor.................................................(5 posi��es - total = 47).
    lSequencia = lSequencia & Format$(pP0042100!COD_UNID_PROD, "00000")
    '===007) Nome do proponente (segurado)....................................(60 posi��es - total = 107).
    lAuxiliar = UCase$(pP0042100!NOM_SEGURADO)
    Select Case Len(lAuxiliar)
        Case Is < 60
            While Len(lAuxiliar) <> 60
                lAuxiliar = lAuxiliar & " "
            Wend
        'Case 60
        '   Nada a fazer.
        Case Is > 60
            lAuxiliar = Left$(lAuxiliar, 60)
    End Select
    lSequencia = lSequencia & lAuxiliar
    '===008) C�digo do segurado................................................(7 posi��es - total = 114).
    If gfPreenchido(pP0042100!COD_SEGURADO) Then
        If IsNumeric(pP0042100!COD_SEGURADO) Then
            lAuxiliar = Format$(Val(pP0042100!COD_SEGURADO), "0000000")
        Else
            lAuxiliar = String(7, "0")
        End If
    Else
        lAuxiliar = String(7, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===009) Tipo de pessoa.....................................................(1 posi��o - total = 115).
    '===010) Identifica��o....................................................(61 posi��es - total = 176).
    Select Case pP0042100!Tip_Pessoa
        Case 1
            'a) Tipo de pessoa.
            lAuxiliar = "J"
            'b) CNPJ - 14 posi��es num�ricas.
            lAuxiliar = lAuxiliar & gfForCNPJ(CStr(pP0042100!CNPJ_CPF), 14)
            'c) Ramo de atividade - 2 posi��es num�ricas.
            lAuxiliar = lAuxiliar & lRamAtividade
            'd) Completa com espa�os.
            lAuxiliar = lAuxiliar & String(45, " ")
        Case 2
            'a) Tipo de pessoa.
            lAuxiliar = "F"
            'b) CPF - 11 posi��es num�ricas.
            lAuxiliar = lAuxiliar & Format$(pP0042100!CNPJ_CPF, "00000000000")
            'c) Tipo do documento - 2 posi��es num�ricas.
            lAuxiliar = lAuxiliar & lTipDocumento
            'd) N�mero do documento - 20 posi��es.
            lAuxiliar = lAuxiliar & lNumDocumento
            'e) �rg�o emissor do documento - 20 posi��es.
            lAuxiliar = lAuxiliar & lOrgEmiDocumento
            'f) Data de emiss�o do documento - 8 posi��es num�ricas (aaaammdd).
            Select Case pOpcao
                Case 1      'Calcula com a data de emiss�o do documento correta.
                    lAuxiliar = lAuxiliar & lDatEmiDocumento
                Case 2      'Calcula com a data de emiss�o do documento zerada.
                    lAuxiliar = lAuxiliar & String(8, "0")
            End Select
    End Select
    lSequencia = lSequencia & lAuxiliar
    '===011) Endere�o do segurado - logradouro................................(73 posi��es - total = 249).
    lAuxiliar = ""
    If gfPreenchido(pP0042100!End_Tip_Logradouro) Then
        lAuxiliar = Trim$(pP0042100!End_Tip_Logradouro) & " "
    End If
    If gfPreenchido(pP0042100!End_Nom_Logradouro) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!End_Tip_Logradouro) & " "   '<<<=== ERRO. Deve ser nome do
                                                                            '             logradouro.
    End If
    If gfPreenchido(pP0042100!End_Complemento) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!End_Complemento)
    End If
    Select Case Len(lAuxiliar)
        Case Is < 73
            While Len(lAuxiliar) <> 73
                lAuxiliar = lAuxiliar & " "
            Wend
        'Case 73
        '   Nada a fazer.
        Case Is > 73
            lAuxiliar = Left$(lAuxiliar, 73)
    End Select
    lSequencia = lSequencia & lAuxiliar
    '===012) Endere�o do segurado - bairro....................................(30 posi��es - total = 279).
    If gfPreenchido(pP0042100!End_Bairro) Then
        lAuxiliar = pP0042100!End_Bairro
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===013) Endere�o do segurado - cidade....................................(30 posi��es - total = 309).
    If gfPreenchido(pP0042100!End_Cidade) Then
        lAuxiliar = pP0042100!End_Cidade
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===014) Endere�o do segurado - unidade da federa��o.......................(2 posi��es - total = 311).
    If gfPreenchido(pP0042100!End_UF) Then
        lAuxiliar = pP0042100!End_UF
        If Len(lAuxiliar) < 2 Then
            While Len(lAuxiliar) <> 2
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(2, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===015) Endere�o do segurado - CEP........................................(8 posi��es - total = 319).
    If gfPreenchido(pP0042100!End_CEP) Then
        lAuxiliar = pP0042100!End_CEP
        If Len(lAuxiliar) < 8 Then
            While Len(lAuxiliar) <> 8
                lAuxiliar = "0" & lAuxiliar
            Wend
        End If
    Else
        lAuxiliar = String(8, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===016) Endere�o do segurado - telefones.................................(30 posi��es - total = 349).
    If gfPreenchido(pP0042100!End_Telefones) Then
        lAuxiliar = pP0042100!End_Telefones
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===017) Endere�o de cobran�a - logradouro................................(73 posi��es - total = 422).
    lAuxiliar = ""
    If gfPreenchido(pP0042100!Cob_Tip_Logradouro) Then
        lAuxiliar = Trim$(pP0042100!Cob_Tip_Logradouro) & " "
    End If
    If gfPreenchido(pP0042100!Cob_Nom_Logradouro) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!Cob_Tip_Logradouro) & " "   '<<<=== ERRO. Deve ser nome do
                                                                            '             logradouro.
    End If
    If gfPreenchido(pP0042100!Cob_Complemento) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!Cob_Complemento)
    End If
    Select Case Len(lAuxiliar)
        Case Is < 73
            While Len(lAuxiliar) <> 73
                lAuxiliar = lAuxiliar & " "
            Wend
        'Case 73
        '   Nada a fazer.
        Case Is > 73
            lAuxiliar = Left$(lAuxiliar, 73)
    End Select
    lSequencia = lSequencia & lAuxiliar
    '===018) Endere�o de cobran�a - bairro....................................(30 posi��es - total = 452).
    If gfPreenchido(pP0042100!Cob_Bairro) Then
        lAuxiliar = pP0042100!Cob_Bairro
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===019) Endere�o de cobran�a - cidade....................................(30 posi��es - total = 482).
    If gfPreenchido(pP0042100!Cob_Cidade) Then
        lAuxiliar = pP0042100!Cob_Cidade
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===020) Endere�o de cobran�a - unidade da federa��o.......................(2 posi��es - total = 484).
    If gfPreenchido(pP0042100!Cob_UF) Then
        lAuxiliar = pP0042100!Cob_UF
        If Len(lAuxiliar) < 2 Then
            While Len(lAuxiliar) <> 2
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(2, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===021) Endere�o de cobran�a - CEP........................................(8 posi��es - total = 492).
    If gfPreenchido(pP0042100!Cob_CEP) Then
        lAuxiliar = pP0042100!Cob_CEP
        If Len(lAuxiliar) < 8 Then
            While Len(lAuxiliar) <> 8
                lAuxiliar = "0" & lAuxiliar
            Wend
        End If
    Else
        lAuxiliar = String(8, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===022) Endere�o de cobran�a - telefones.................................(30 posi��es - total = 522).
    If gfPreenchido(pP0042100!Cob_Telefones) Then
        lAuxiliar = pP0042100!Cob_Telefones
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===023) In�cio de vig�ncia................................................(8 posi��es - total = 530).
    lSequencia = lSequencia & Format$(pP0042100!Dat_Vig_Inicio, "00000000")
    '===024) T�rmino de vig�ncia...............................................(8 posi��es - total = 538).
    lSequencia = lSequencia & Format$(pP0042100!Dat_Vig_Termino, "00000000")
    '===025) Corretagem.......................................................(33 posi��es - total = 571).
    lSequencia = lSequencia & Format$(pP0042100!Cor1_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor1_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cor2_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor2_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cor3_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor3_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===026) Cosseguros.......................................................(50 posi��es - total = 621).
    lSequencia = lSequencia & Format$(pP0042100!Cos1_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos1_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos2_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos2_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos3_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos3_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos4_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos4_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos5_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos5_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===027) Juros ao m�s......................................................(4 posi��es - total = 625).
    Select Case pP0042100!Pag_Ant_Ind
        Case 1, 2       'Pagamento antecipado.
            Select Case pP0042100!Qtd_Parcelas_VM
                Case 0
                    lAuxiliar = "00,00"
                Case 1
                    lAuxiliar = Format$(pP0042100!Jur_Ant_01, "00.00")
                Case 2
                    lAuxiliar = Format$(pP0042100!Jur_Ant_02, "00.00")
                Case 3
                    lAuxiliar = Format$(pP0042100!Jur_Ant_03, "00.00")
                Case 4
                    lAuxiliar = Format$(pP0042100!Jur_Ant_04, "00.00")
                Case 5
                    lAuxiliar = Format$(pP0042100!Jur_Ant_05, "00.00")
                Case 6
                    lAuxiliar = Format$(pP0042100!Jur_Ant_06, "00.00")
                Case 7
                    lAuxiliar = Format$(pP0042100!Jur_Ant_07, "00.00")
                Case 8
                    lAuxiliar = Format$(pP0042100!Jur_Ant_08, "00.00")
                Case 9
                    lAuxiliar = Format$(pP0042100!Jur_Ant_09, "00.00")
                Case 10
                    lAuxiliar = Format$(pP0042100!Jur_Ant_10, "00.00")
                Case 11
                    lAuxiliar = Format$(pP0042100!Jur_Ant_11, "00.00")
                Case 12
                    lAuxiliar = Format$(pP0042100!Jur_Ant_12, "00.00")
            End Select
        Case 9      'Pagamento postecipado.
            Select Case pP0042100!Qtd_Parcelas_VM
                Case 0
                    lAuxiliar = "00,00"
                Case 1
                    lAuxiliar = Format$(pP0042100!Jur_Pos_01, "00.00")
                Case 2
                    lAuxiliar = Format$(pP0042100!Jur_Pos_02, "00.00")
                Case 3
                    lAuxiliar = Format$(pP0042100!Jur_Pos_03, "00.00")
                Case 4
                    lAuxiliar = Format$(pP0042100!Jur_Pos_04, "00.00")
                Case 5
                    lAuxiliar = Format$(pP0042100!Jur_Pos_05, "00.00")
                Case 6
                    lAuxiliar = Format$(pP0042100!Jur_Pos_06, "00.00")
                Case 7
                    lAuxiliar = Format$(pP0042100!Jur_Pos_07, "00.00")
                Case 8
                    lAuxiliar = Format$(pP0042100!Jur_Pos_08, "00.00")
                Case 9
                    lAuxiliar = Format$(pP0042100!Jur_Pos_09, "00.00")
                Case 10
                    lAuxiliar = Format$(pP0042100!Jur_Pos_10, "00.00")
                Case 11
                    lAuxiliar = Format$(pP0042100!Jur_Pos_11, "00.00")
                Case 12
                    lAuxiliar = Format$(pP0042100!Jur_Pos_12, "00.00")
            End Select
    End Select
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===028) Custo da ap�lice.................................................(10 posi��es - total = 635).
    lAuxiliar = Format$(pP0042100!Cus_Emissao, "00000000.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===029) Valor do IOF.....................................................(10 posi��es - total = 645).
    If pP0042100!Val_IOF_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_IOF_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_IOF_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===030) N�mero de parcelas................................................(2 posi��es - total = 647).
    lAuxiliar = Format$(pP0042100!Qtd_Parcelas_VM, "00")
    lSequencia = lSequencia & lAuxiliar
    '===031) Indicador de primeira parcela paga antecipada......................(1 posi��o - total = 648).
    lAuxiliar = Format$(pP0042100!Pag_Ant_Ind, "0")
    lSequencia = lSequencia & lAuxiliar
    '===032) Valor da primeira parcela........................................(10 posi��es - total = 658).
    If pP0042100!Val_Parcela1_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_Parcela1_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_Parcela1_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===033) Valor das demais parcelas........................................(10 posi��es - total = 668).
    If pP0042100!Val_Parcelas_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_Parcelas_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_Parcelas_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===034) Pagamento em bloqueto - n�mero do bloqueto.......................(10 posi��es - total = 678).
    lSequencia = lSequencia & Format$(pP0042100!Pag_Ant_Bloqueto, "0000000000")
    '===035) Pagamento atrav�s de carn�.......................................(11 posi��es - total = 689).
    'a) C�digo do banco.
    lSequencia = lSequencia & Format$(pP0042100!Carne_Cod_Banco, "000")
    'b) Vencimento da primeira parcela.
    lSequencia = lSequencia & Format$(pP0042100!Ven_Parcela1_VM, "00000000")
    '===036) Pagamento atrav�s de d�bito em conta.............................(18 posi��es - total = 707).
    'a) C�digo do banco.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Banco, "000")
    'b) C�digo da ag�ncia.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Agencia, "0000")
    'c) C�digo da conta corrente.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Conta, "000000000")
    'd) Dia para d�bito.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Dia, "00")
    '===037) Juros de mora.....................................................(4 posi��es - total = 711).
    lSequencia = lSequencia & "0450"

    '4. Obt�m dados dos itens - j� foram obtidos os registros dos itens - pP0042200.
    'a) Verifica base de dados.
    If pP0042200.RecordCount = 0 Then
        pMensagem = "FTE0056 - " & gPrefixo & _
                    "N�o localizado registro de item (c�lculo do c�digo de unicidade)."
        Exit Function
    End If
    'b) Coberturas dos itens - j� foram obtidos os registros de coberturas dos itens - pP0042600.
    'c) Descontos dos itens - j� foram obtidos os registros de descontos dos itens - pP0042700.

    '5. Continua seq��ncia para c�lculo do c�digo de unicidade com dados dos itens.
    pP0042200.MoveFirst
    While Not pP0042200.EOF
        'a) Obt�m valores das coberturas.
        lIS_Casco = 0
        lNivRCDM = 0
        lIS_RCDM = 0
        lNivRCDC = 0
        lIS_RCDC = 0
        lIS_RCMO = 0
        lIS_APPMorte = 0
        lIS_APPInvalidez = 0
        lIS_APPDMH = 0
        If pP0042600.RecordCount <> 0 Then
            pP0042600.MoveFirst
            While Not pP0042600.EOF
                If pP0042600!Num_Item = pP0042200!Num_Item Then
                    Select Case pP0042600!Cod_Cobert
                        Case gCobCasco
                            lIS_Casco = pP0042600!Val_IS
                        Case gCobRCDM
                            lNivRCDM = pP0042600!Cod_Niv_IS
                            lIS_RCDM = pP0042600!Val_IS
                        Case gCobRCDC
                            lNivRCDC = pP0042600!Cod_Niv_IS
                            lIS_RCDC = pP0042600!Val_IS
                        Case gCobRCMO
                            lIS_RCMO = pP0042600!Val_IS
                        Case gCobAPPMorte
                            lIS_APPMorte = pP0042600!Val_IS
                        Case gCobAPPInvalidez
                            lIS_APPInvalidez = pP0042600!Val_IS
                        Case gCobAPPDMH
                            lIS_APPDMH = pP0042600!Val_IS
                    End Select
                End If
                pP0042600.MoveNext
            Wend
        End If

        'b) Obt�m percentuais de desconto.
        lClaBonus = 0
        lPerDesAPP = 0
        lPerDesBonus = 0
        lPerDesCasco = 0
        lPerDesFidelidade = 0
        lPerDesFrota = 0
        lPerDesPerfil = 0
        lPerDesRC = 0
        If pP0042700.RecordCount <> 0 Then
            pP0042700.MoveFirst
            While Not pP0042700.EOF
                If pP0042700!Num_Item = pP0042200!Num_Item Then
                    Select Case pP0042700!Cod_Desc
                        Case gDesAPP
                            lPerDesAPP = pP0042700!Per_Desc
                        Case gDesBonus
                            lPerDesBonus = pP0042700!Per_Desc
                            lClaBonus = pP0042700!Cod_Classe_Desc
                        Case gDesCasco
                            lPerDesCasco = pP0042700!Per_Desc
                        Case gDesFidelidade
                            lPerDesFidelidade = pP0042700!Per_Desc
                        Case gDesFrota
                            lPerDesFrota = pP0042700!Per_Desc
                        Case gDesPerfil
                            lPerDesPerfil = pP0042700!Per_Desc
                        Case gDesRC
                            lPerDesRC = pP0042700!Per_Desc
                    End Select
                End If
                pP0042700.MoveNext
            Wend
        End If

        'c) Continua seq��ncia para c�lculo do c�digo de unicidade com dados do item.
        '===038) N�mero do item..................................................(4 posi��es - total = 4).
        lSequencia = lSequencia & Format$(pP0042200!Num_Item, "0000")
        '===039) Tipo de emiss�o.................................................(3 posi��es - total = 7).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Emissao, "000")
        '===040) Tipo do produto..................................................(1 posi��o - total = 8).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Produto, "0")
        '===041) C�digo do ve�culo..............................................(8 posi��es - total = 16).
        lSequencia = lSequencia & pP0042200!Cod_Veiculo
        '===042) C�digo Renavam................................................(10 posi��es - total = 26).
        lSequencia = lSequencia & Format$(pP0042200!Val_Cus_Emissao, "0000000000")
        '===043) Ano de fabrica��o..............................................(4 posi��es - total = 30).
        lSequencia = lSequencia & Format$(pP0042200!Ano_Fabricacao, "0000")
        '===044) Ano de modelo..................................................(4 posi��es - total = 34).
        lSequencia = lSequencia & Format$(pP0042200!Ano_Modelo, "0000")
        '===045) Indicador de ve�culo 0 km.......................................(1 posi��o - total = 35).
        lSequencia = lSequencia & Format$(pP0042200!COD_IDEN_0KM, "0")
        '===046) C�digo da placa................................................(8 posi��es - total = 43).
        lAuxiliar = UCase$(pP0042200!Cod_Placa)
        If Len(lAuxiliar) < 8 Then
            While Len(lAuxiliar) <> 8
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===047) Tipo do combust�vel.............................................(1 posi��o - total = 44).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Combustivel, "0")
        '===048) C�digo da chassi nacional.....................................(20 posi��es - total = 64).
        lAuxiliar = UCase$(pP0042200!Cod_Chassi)
        If Len(lAuxiliar) < 20 Then
            While Len(lAuxiliar) <> 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===049) C�digo da chassi estrangeiro..................................(20 posi��es - total = 84).
        lAuxiliar = UCase$(pP0042200!Cod_Chassi_Estrang)
        If Len(lAuxiliar) < 20 Then
            While Len(lAuxiliar) <> 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===050) C�digo FIPE....................................................(6 posi��es - total = 90).
        lSequencia = lSequencia & Format$(pP0042200!Cod_FIPE, "000000")
        '===051) Categoria......................................................(2 posi��es - total = 92).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Categoria, "00")
        '===052) CEP de pernoite...............................................(8 posi��es - total = 100).
        lSequencia = lSequencia & Format$(pP0042200!Cep_Regiao, "00000000")
        '===053) Franquia de casco............................................(10 posi��es - total = 110).
        If pP0042200!Val_Franquia_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Val_Franquia_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Val_Franquia_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===054) Indicador de question�rio de avalia��o de risco................(1 posi��o - total = 111).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Questionario, "0")
        '===055) Renova��o Yasuda - n�mero da ap�lice.........................(10 posi��es - total = 121).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Num_Apolice, "0000000000")
        '===056) Renova��o Yasuda - item da ap�lice............................(4 posi��es - total = 125).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Num_Item, "0000")
        '===057) Indicador da exist�ncia do benefici�rio........................(1 posi��o - total = 126).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Beneficiario, "0")
        '===058) Nome do benefici�rio.........................................(20 posi��es - total = 146).
        lAuxiliar = UCase$(pP0042200!Nom_Beneficiario)
        If Len(lAuxiliar) < 20 Then
            While Len(lAuxiliar) <> 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===059) Nome do propriet�rio.........................................(30 posi��es - total = 176).
        lAuxiliar = UCase$(pP0042200!Nom_Proprietario)
        If Len(lAuxiliar) < 30 Then
            While Len(lAuxiliar) <> 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===060) Tipo do cobertura..............................................(1 posi��o - total = 177).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Cobertura, "0")
        '===061) Tipo da assist�ncia 24 horas (tipo do limite de guincho).......(1 posi��o - total = 178).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Lim_Guincho, "0")
        '===062) Cl�usula 112 (s�cio/dirigente).................................(1 posi��o - total = 179).
        lSequencia = lSequencia & Format$(pP0042200!Soc_Dirigente, "0")
        '===063) Cobertura de carro reserva.....................................(1 posi��o - total = 180).
        lSequencia = lSequencia & Format$(pP0042200!Carro_Reserva, "0")
        '===064) Cobertura de vidros............................................(1 posi��o - total = 181).
        lSequencia = lSequencia & Format$(pP0042200!COD_IDEN_VIDROS, "0")
        '===065) Cobertura de extens�o para ve�culos 0 km.......................(1 posi��o - total = 182).
        lSequencia = lSequencia & Format$(pP0042200!Ext_0km, "0")
        '===066) Acess�rio de f�brica - ar condicionado.........................(1 posi��o - total = 183).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Ar_Condic, "0")
        '===067) Acess�rio de f�brica - bancos de couro.........................(1 posi��o - total = 184).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Ban_Couro, "0")
        '===068) Acess�rio de f�brica - freios ABS..............................(1 posi��o - total = 185).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Fre_ABS, "0")
        '===069) Acess�rio de f�brica - dire��o hidr�ulica......................(1 posi��o - total = 186).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Dir_Hidra, "0")
        '===070) Acess�rio de f�brica - c�mbio autom�rico.......................(1 posi��o - total = 187).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Cam_Autom, "0")
        '===071) Acess�rio de f�brica - air bag.................................(1 posi��o - total = 188).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Air_Bag, "0")
        '===072) Acess�rios...................................................(65 posi��es - total = 253).
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_1, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_1, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_2, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_2, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_3, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_3, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!Cod_Aces_4, "000")
        lAuxiliar = Format$(pP0042200!Val_IS_Aces_4, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!Cod_Aces_5, "000")
        lAuxiliar = Format$(pP0042200!Val_IS_Aces_5, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===073) Desconto de casco.............................................(4 posi��es - total = 257).
        lAuxiliar = Format$(lPerDesCasco, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===074) Desconto de RCF...............................................(4 posi��es - total = 261).
        lAuxiliar = Format$(lPerDesRC, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===075) Desconto de APP...............................................(4 posi��es - total = 265).
        lAuxiliar = Format$(lPerDesAPP, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===076) Classe de b�nus...............................................(2 posi��es - total = 267).
        lSequencia = lSequencia & Format$(lClaBonus, "00")
        '===077) Percentual de desconto de b�nus...............................(4 posi��es - total = 271).
        lAuxiliar = Format$(lPerDesBonus, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===078) Desconto de frota.............................................(4 posi��es - total = 275).
        lAuxiliar = Format$(lPerDesFrota, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===079) Renova��o de cong�nere - c�digo da seguradora.................(3 posi��es - total = 278).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Con_Seguradora, "000")
        '===080) Renova��o de cong�nere - c�digo da ap�lice...................(15 posi��es - total = 293).
        lAuxiliar = UCase$(pP0042200!Ren_Con_Apolice)
        If Len(lAuxiliar) < 15 Then
            While Len(lAuxiliar) <> 15
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===081) Renova��o de cong�nere - item da ap�lice......................(5 posi��es - total = 298).
        lAuxiliar = UCase$(pP0042200!Ren_Con_Item)
        If Len(lAuxiliar) < 5 Then
            While Len(lAuxiliar) <> 5
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===082) Renova��o de cong�nere - c�digo de identifica��o.............(14 posi��es - total = 312).
        lAuxiliar = ""
        If gfPreenchido(pP0042200!Clausula1) Then
            lAuxiliar = pP0042200!Clausula1
        End If
        If gfPreenchido(pP0042200!Clausula2) Then
            lAuxiliar = lAuxiliar & pP0042200!Clausula2
        End If
        If gfPreenchido(pP0042200!Clausula3) Then
            lAuxiliar = lAuxiliar & pP0042200!Clausula3
        End If
        Select Case Len(lAuxiliar)
            Case Is < 14
                While Len(lAuxiliar) <> 14
                    lAuxiliar = lAuxiliar & " "
                Wend
            'Case 14
            '   Nada a fazer.
            Case Is > 14
                lAuxiliar = Left$(lAuxiliar, 14)
        End Select
        lSequencia = lSequencia & lAuxiliar
        '===083) Renova��o de cong�nere - indicador de sinistro.................(1 posi��o - total = 313).
        lSequencia = lSequencia & Format$(pP0042200!Ind_Sinistro, "0")
        '===084) Import�ncia segurada de casco................................(10 posi��es - total = 323).
        lAuxiliar = Format$(lIS_Casco, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===085) N�vel do cobertura RC-DM......................................(2 posi��es - total = 325).
        lSequencia = lSequencia & Format$(lNivRCDM, "00")
        '===086) Import�ncia segurada de RC-DM................................(10 posi��es - total = 335).
        lAuxiliar = Format$(lIS_RCDM, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===087) N�vel do cobertura RC-DC......................................(2 posi��es - total = 337).
        lSequencia = lSequencia & Format$(lNivRCDC, "00")
        '===088) Import�ncia segurada de RC-DC................................(10 posi��es - total = 347).
        lAuxiliar = Format$(lIS_RCDC, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===089) Import�ncia segurada de RC-MO................................(10 posi��es - total = 357).
        lAuxiliar = Format$(lIS_RCMO, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===090) Import�ncia segurada de APP Morte............................(10 posi��es - total = 367).
        lAuxiliar = Format$(lIS_APPMorte, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===091) Import�ncia segurada de APP Invalidez permanente.............(10 posi��es - total = 377).
        lAuxiliar = Format$(lIS_APPInvalidez, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===092) Import�ncia segurada de APP DMH..............................(10 posi��es - total = 387).
        lAuxiliar = Format$(lIS_APPDMH, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===093) Pr�mio de casco..............................................(10 posi��es - total = 397).
        If pP0042200!Pr_Casco_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Casco_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Casco_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===094) Pr�mio de despesas extraodrin�rias...........................(10 posi��es - total = 407).
        If pP0042200!Pr_Des_Extr_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Des_Extr_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Des_Extr_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===095) Pr�mio de acess�rios.........................................(10 posi��es - total = 417).
        If pP0042200!Pr_Acessorios_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Acessorios_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Acessorios_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===096) Pr�mio de RC-DM..............................................(10 posi��es - total = 427).
        If pP0042200!Pr_RCDM_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCDM_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCDM_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===097) Pr�mio de RC-DC..............................................(10 posi��es - total = 437).
        If pP0042200!Pr_RCDC_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCDC_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCDC_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===098) Pr�mio da cl�usula 112 (s�cio/dirigente).....................(10 posi��es - total = 447).
        lSequencia = lSequencia & "0000000000"
        '===099) Pr�mio de RC-MO..............................................(10 posi��es - total = 457).
        If pP0042200!Pr_RCMO_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCMO_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCMO_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===100) Pr�mio de APP................................................(10 posi��es - total = 467).
        If pP0042200!Pr_APP_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_APP_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_APP_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===101) Pr�mio de assist�ncia 24 horas...............................(10 posi��es - total = 477).
        If pP0042200!Pr_Ass_24hs_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Ass_24hs_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Ass_24hs_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===102) Pr�mio de carro reserva......................................(10 posi��es - total = 487).
        If pP0042200!Pr_Carro_Reserva_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Carro_Reserva_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Carro_Reserva_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===103) Pr�mio de vidros.............................................(10 posi��es - total = 497).
        If pP0042200!Pr_Vidros_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Vidros_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Vidros_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===104) Pr�mio de extens�o para ve�culo 0 km.........................(10 posi��es - total = 507).
        If pP0042200!Pr_Ext_0km_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Ext_0km_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Ext_0km_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===105) Pr�mio l�quido...............................................(10 posi��es - total = 517).
        If pP0042200!Pr_Liquido_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Liquido_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Liquido_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===106) Pr�mio total.................................................(10 posi��es - total = 527).
        If pP0042200!Pr_Total_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Total_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Total_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===107) Question�rio de avalia��o de risco - nome do condutor........(30 posi��es - total = 557).
        lAuxiliar = UCase$(pP0042200!Nom_Condutor)
        Select Case Len(lAuxiliar)
            Case Is < 30
                While Len(lAuxiliar) <> 30
                    lAuxiliar = lAuxiliar & " "
                Wend
            'Case 30
            '   Nada a fazer.
            Case Is > 30
                lAuxiliar = Left$(lAuxiliar, 30)
        End Select
        lSequencia = lSequencia & lAuxiliar
        '===108) Question�rio de avalia��o de risco - RG do condutor..........(20 posi��es - total = 577).
        lAuxiliar = UCase$(pP0042200!Cod_RG)
        Select Case Len(lAuxiliar)
            Case Is < 20
                While Len(lAuxiliar) <> 20
                    lAuxiliar = lAuxiliar & " "
                Wend
            'Case 20
            '   Nada a fazer.
            Case Is > 20
                lAuxiliar = Left$(lAuxiliar, 20)
        End Select
        lSequencia = lSequencia & lAuxiliar
        '===109) Question�rio de avalia��o de risco - CPF do condutor.........(11 posi��es - total = 588).
        lAuxiliar = UCase$(pP0042200!Cod_CPF)
        Select Case Len(lAuxiliar)
            Case Is < 11
                While Len(lAuxiliar) <> 11
                    lAuxiliar = lAuxiliar & " "
                Wend
            'Case 11
            '   Nada a fazer.
            Case Is > 11
                lAuxiliar = Left$(lAuxiliar, 11)
        End Select
        lSequencia = lSequencia & lAuxiliar
        '===110) Question�rio - rela��o do condutor com o proponente............(1 posi��o - total = 589).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Relacao, "0")
        '===111) Question�rio - outra rela��o do condutor.....................(20 posi��es - total = 609).
        lAuxiliar = UCase$(pP0042200!Dsc_Outra_Relacao)
        Select Case Len(lAuxiliar)
            Case Is < 20
                While Len(lAuxiliar) <> 20
                    lAuxiliar = lAuxiliar & " "
                Wend
            'Case 20
            '   Nada a fazer.
            Case Is > 20
                lAuxiliar = Left$(lAuxiliar, 20)
        End Select
        lSequencia = lSequencia & lAuxiliar
        '===112) Question�rio - estado civil do condutor........................(1 posi��o - total = 610).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Est_Civil)
        '===113) Question�rio - sexo do condutor................................(1 posi��o - total = 611).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Sexo)
        '===114) Question�rio - data de nascimento do condutor.................(8 posi��es - total = 619).
        lSequencia = lSequencia & Format$(pP0042200!Dat_Nasc, "00000000")
        '===115) Question�rio - ano da primeira habilita��o do condutor........(4 posi��es - total = 623).
        lSequencia = lSequencia & Format$(pP0042200!Dat_Pri_Habilit, "0000")
        '===116) Question�rio - garagem do ve�culo..............................(1 posi��o - total = 624).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Garagem)
        '===117) Question�rio - utiliza��o do ve�culo...........................(1 posi��o - total = 625).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Utiliza)
        '===118) Question�rio - ve�culo conduzido por pessoas 18 e 24 anos?.....(1 posi��o - total = 626).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Pessoas, "0")
        '===119) Question�rio - dispositivo de seguran�a 1......................(1 posi��o - total = 627).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_1, "0")
        '===120) Question�rio - dispositivo de seguran�a 2......................(1 posi��o - total = 628).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_2, "0")
        '===121) Question�rio - dispositivo de seguran�a 3......................(1 posi��o - total = 629).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_3, "0")
        '===122) Question�rio - dispositivo de seguran�a 4......................(1 posi��o - total = 630).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_4, "0")
        '===123) Question�rio - dispositivo de seguran�a 5......................(1 posi��o - total = 631).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_5, "0")

        'd) Pr�ximo item.
        pP0042200.MoveNext
    Wend

    '6. Preencher o campo de seq��ncia para que o tamanho fique em m�ltiplo de 10.
    lTamanho = Len(lSequencia)
    lResto = lTamanho Mod 10
    If lResto <> 0 Then
        lSequencia = lSequencia & String(10 - lResto, " ")
    End If

    '7. Dividir o campo de seq��ncia em campos de 10 posi��es cada.
    lTamanho = Len(lSequencia)
    lResultado = lTamanho / 10
    ReDim lCampo1(lResultado)
    For lI = 1 To lResultado
        lCampo1(lI) = Mid$(lSequencia, ((lI - 1) * 10) + 1, 10)
    Next lI

    '8. Para cada campo de 10 posi��es, transforma cada caracter num valor ASC e soma estes valores.
    ReDim lCampo2(lResultado)
    For lI = 1 To lResultado
        lCampo2(lI) = Asc(Mid(lCampo1(lI), 1, 1)) + Asc(Mid(lCampo1(lI), 2, 1)) + _
                      Asc(Mid(lCampo1(lI), 3, 1)) + Asc(Mid(lCampo1(lI), 4, 1)) + _
                      Asc(Mid(lCampo1(lI), 5, 1)) + Asc(Mid(lCampo1(lI), 6, 1)) + _
                      Asc(Mid(lCampo1(lI), 7, 1)) + Asc(Mid(lCampo1(lI), 8, 1)) + _
                      Asc(Mid(lCampo1(lI), 9, 1)) + Asc(Mid(lCampo1(lI), 10, 1))
        'MsgBox "Resultado " & lI & " = " & lCampo2(lI)
    Next lI

    '9. Somar todos os resultados obtidos.
    lTotal = 0
    For lI = 1 To lResultado
        lTotal = lTotal + lCampo2(lI)
    Next lI

    '10. Resultado: c�digo de verifica��o.
    pCodVerificacao = Right$(Format$(lTotal, "000000"), 6)

    mfCalCodUniXXXXX1 = True
End Function

Private Function mfCalCodUniXXXXX2(ByVal pOpcao As Byte, _
                                   ByVal pNosNumero As String, _
                                   ByVal pP0042100 As ADODB.Recordset, _
                                   ByVal pP0042200 As ADODB.Recordset, _
                                   ByVal pP0042600 As ADODB.Recordset, _
                                   ByVal pP0042700 As ADODB.Recordset, _
                                   ByRef pCN As ADODB.Connection, _
                                   ByRef pCodVerificacao As String, ByRef pMensagem As String)
    'Fun��o: Calcula c�digo de verifica��o da unicidade.

    'Obs.: Esta fun��o tem 1 erros. N�o est� sendo considerado:
    '      1. O c�digo do produtor.
    '      Manter esta fun��o at� fevereiro de 2005, pois alguns corretores est�o com a vers�o do programa
    '      P28V100 antiga, cujo c�lculo est� com este erro.

    'Obs.: Esta fun��o foi copiada do programa P28V100 e adaptada para a situa��o do programa P28V300.

    'Par�metros de entrada...pOpcao............1 = calcula com data do documento para pessoa f�sica
    '                                              corretamente.
    '                                          2 = calcula com data do documento para pessoa f�sica
    '                                              zerada.
    '                        pNosNumero........Nosso n�mero.
    '                        pP0042100.........Registros P0042100.
    '                        pP0042200.........Registros P0042200.
    '                        pP0042400.........Registros P0042400.
    '                        pP0042500.........Registros P0042500.
    'Par�metros de sa�da.....pCodVerificacao...C�digo de verifica��o.
    '                        pMensagem.........Mensagem.

Dim lAuxiliar           As String           'Auxiliar.
Dim lCampo1()           As String           'Campos utilizados para dividir a seq��ncia em campos de
                                            '10 posi��es cada.
Dim lCampo2()           As Integer          'Campos com totais das somas das posi��es de lCampo1.
Dim lClaBonus           As Byte             'Classe do b�nus.
Dim lDatEmiDocumento    As String           'Pessoa f�sica: data de emiss�o do documento.
Dim lI                  As Integer          'Utilizado com For...Next.
Dim lIS_APPDMH          As Double           'Import�ncia segurada de APP - DMH.
Dim lIS_APPInvalidez    As Double           'Import�ncia segurada de APP - invalidez.
Dim lIS_APPMorte        As Double           'Import�ncia segurada de APP - Morte.
Dim lIS_Casco           As Double           'Import�ncia segurada de casco.
Dim lIS_RCDC            As Double           'Import�ncia segurada de RC-DC.
Dim lIS_RCDM            As Double           'Import�ncia segurada de RC-DM.
Dim lIS_RCMO            As Double           'Import�ncia segurada de RC-MO.
Dim lNivRCDC            As Byte             'N�vel de cobertura RC-DC.
Dim lNivRCDM            As Byte             'N�vel de cobertura RC-DM.
Dim lNumDocumento       As String           'Pessoa f�sica: n�mero do documento.
Dim lOrgEmiDocumento    As String           'Pessoa f�sica: �rg�o emissor do documento.
Dim lPerDesAPP          As Double           'Percentual de desconto de APP.
Dim lPerDesBonus        As Double           'Percentual de desconto de b�nus.
Dim lPerDesCasco        As Double           'Percentual de desconto de casco.
Dim lPerDesFidelidade   As Double           'Percentual de desconto de fidelidade.
Dim lPerDesFrota        As Double           'Percentual de desconto de frota.
Dim lPerDesPerfil       As Double           'Percentual de desconto de perfil.
Dim lPerDesRC           As Double           'Percentual de desconto de RC.
Dim lRamAtividade       As String           'Pessoa jur�dica: ramo de atividade.
Dim lResto              As Byte             'Resto da divis�o.
Dim lResultado          As Integer          'Resultado da divis�o.
Dim lSequencia          As String           'Seq��ncia para c�lculo do c�digo de unicidade.
Dim lTamanho            As Integer          'Tamanho.
Dim lTipDocumento       As String           'Pessoa f�sica: tipo do documento.
Dim lTotal              As Double           'Total.
Dim rsP0042300          As ADODB.Recordset  'Registro P0042300.
Dim lSelect             As String
    
    mfCalCodUniXXXXX2 = False

    '1. Obt�m registro de dados comuns.
    '   J� foi obtido o registro de dados comuns - pP0042100.

    '2. Obt�m registro de identifica��o do segurado.
    lSelect = "SELECT * FROM P0042300 WHERE Nosso_Numero = '" & pNosNumero & _
              "' AND Num_Item = 0 AND Num_Linha = 0"
    If gfObtRegistro(pCN, lSelect, rsP0042300, pMensagem) = False Then
        Exit Function
    End If
    Select Case pP0042100!Tip_Pessoa
        Case 1      'Pessoa jur�dica.
            Do
                'a) Registro de identifica��o do segurado.
                If rsP0042300.RecordCount = 0 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                lTamanho = Len(Trim$(rsP0042300!Observacao))
                If lTamanho = 0 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                'b) Ramo de atividade - 2 posi��es num�ricas.
                If lTamanho < 3 Then
                    lRamAtividade = "00"
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 2, 2)) Then
                    lRamAtividade = Mid$(rsP0042300!Observacao, 2, 2)
                Else
                    lRamAtividade = "00"
                End If
                Exit Do
            Loop
        Case 2      'Pessoa f�sica.
            lTipDocumento = "00"
            lNumDocumento = String(20, " ")
            lOrgEmiDocumento = String(20, " ")
            lDatEmiDocumento = String(8, "0")
            Do
                'a) Registro de identifica��o do segurado.
                If rsP0042300.RecordCount = 0 Then
                    Exit Do
                End If
                lTamanho = Len(Trim$(rsP0042300!Observacao))
                If lTamanho = 0 Then
                    Exit Do
                End If
                'b) Tipo do documento - 2 posi��es num�ricas.
                If lTamanho < 3 Then
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 2, 2)) Then
                    lTipDocumento = Mid$(rsP0042300!Observacao, 2, 2)       'CORRIGIDO.
                End If
                'c) N�mero do documento - 20 posi��es.
                If lTamanho = 3 Then
                    Exit Do
                End If
                If lTamanho < 23 Then
                    lNumDocumento = Mid$(rsP0042300!Observacao, 4)
                    While Len(lNumDocumento) < 20
                        lNumDocumento = lNumDocumento & " "
                    Wend
                Else
                    lNumDocumento = Mid$(rsP0042300!Observacao, 4, 20)
                End If
                'd) �rg�o emissor do documento - 20 posi��es.
                If lTamanho = 23 Then
                    Exit Do
                End If
                If lTamanho < 43 Then
                    lOrgEmiDocumento = Mid$(rsP0042300!Observacao, 24)
                    While Len(lOrgEmiDocumento) < 20
                        lOrgEmiDocumento = lOrgEmiDocumento & " "
                    Wend
                Else
                    lOrgEmiDocumento = Mid$(rsP0042300!Observacao, 24, 20)
                End If
                'e) Data de emiss�o do documento - 8 posi��es num�ricas.
                If lTamanho < 51 Then
                    Exit Do
                End If
                If IsNumeric(Mid$(rsP0042300!Observacao, 44, 8)) Then
                    lDatEmiDocumento = Mid$(rsP0042300!Observacao, 44, 8)
                End If
                Exit Do
            Loop
    End Select
    Call gpFecha1(rsP0042300)

    '3. Inicia seq��ncia para c�lculo do c�digo de unicidade com dados comuns.
    '===001) Nosso n�mero......................................................(20 posi��es - total = 20).
    lSequencia = pP0042100!NOSSO_NUMERO
    '===002) Refer�ncia.........................................................(6 posi��es - total = 26).
    lSequencia = lSequencia & Format$(pP0042100!Num_Referencia, "000000")
    '===003) C�digo do corretor.................................................(7 posi��es - total = 33).
    lSequencia = lSequencia & Format$(pP0042100!Cor1_Codigo, "0000000")
    '===004) C�digo do produto (tarifa).........................................(4 posi��es - total = 37).
    lSequencia = lSequencia & Format$(pP0042100!Cod_Produto, "0000")
    '===005) C�digo da unidade produtiva........................................(5 posi��es - total = 42).
    lSequencia = lSequencia & Format$(pP0042100!COD_UNID_PROD, "00000")
    '===006) C�digo do produtor.................................................(5 posi��es - total = 47).
    lSequencia = lSequencia & Format$(pP0042100!COD_UNID_PROD, "00000")
    '===007) Nome do proponente (segurado)....................................(60 posi��es - total = 107).
    lAuxiliar = UCase$(pP0042100!NOM_SEGURADO)
    If Len(lAuxiliar) > 60 Then
        lAuxiliar = Left$(lAuxiliar, 60)
    Else
        While Len(lAuxiliar) < 60
            lAuxiliar = lAuxiliar & " "
        Wend
    End If
    lSequencia = lSequencia & lAuxiliar
    '===008) C�digo do segurado................................................(7 posi��es - total = 114).
    If gfPreenchido(pP0042100!COD_SEGURADO) Then
        If IsNumeric(pP0042100!COD_SEGURADO) Then
            lAuxiliar = Format$(Val(pP0042100!COD_SEGURADO), "0000000")
        Else
            lAuxiliar = String(7, "0")
        End If
    Else
        lAuxiliar = String(7, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===009) Tipo de pessoa.....................................................(1 posi��o - total = 115).
    '===010) Identifica��o....................................................(61 posi��es - total = 176).
    Select Case pP0042100!Tip_Pessoa
        Case 1
            'a) Tipo de pessoa.
            lAuxiliar = "J"
            'b) CNPJ - 14 posi��es num�ricas.
            lAuxiliar = lAuxiliar & gfForCNPJ(CStr(pP0042100!CNPJ_CPF), 14)
            'c) Ramo de atividade - 2 posi��es num�ricas.
            lAuxiliar = lAuxiliar & lRamAtividade
            'd) Completa com espa�os.
            lAuxiliar = lAuxiliar & String(45, " ")
        Case 2
            'a) Tipo de pessoa.
            lAuxiliar = "F"
            'b) CPF - 11 posi��es num�ricas.
            lAuxiliar = lAuxiliar & Format$(pP0042100!CNPJ_CPF, "00000000000")
            'c) Tipo do documento - 2 posi��es num�ricas.
            lAuxiliar = lAuxiliar & lTipDocumento
            'd) N�mero do documento - 20 posi��es.
            lAuxiliar = lAuxiliar & lNumDocumento
            'e) �rg�o emissor do documento - 20 posi��es.
            lAuxiliar = lAuxiliar & lOrgEmiDocumento
            'f) Data de emiss�o do documento - 8 posi��es num�ricas (aaaammdd).
            Select Case pOpcao
                Case 1      'Calcula com a data de emiss�o do documento correta.
                    lAuxiliar = lAuxiliar & lDatEmiDocumento
                Case 2      'Calcula com a data de emiss�o do documento zerada.
                    lAuxiliar = lAuxiliar & String(8, "0")
            End Select
    End Select
    lSequencia = lSequencia & lAuxiliar
    '===011) Endere�o do segurado - logradouro................................(73 posi��es - total = 249).
    lAuxiliar = ""
    If gfPreenchido(pP0042100!End_Tip_Logradouro) Then
        lAuxiliar = Trim$(pP0042100!End_Tip_Logradouro) & " "
    End If
    If gfPreenchido(pP0042100!End_Nom_Logradouro) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!End_Nom_Logradouro) & " "       'CORRIGIDO.
    End If
    If gfPreenchido(pP0042100!End_Complemento) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!End_Complemento)
    End If
    If Len(lAuxiliar) > 73 Then
        lAuxiliar = Left$(lAuxiliar, 73)
    Else
        While Len(lAuxiliar) < 73
            lAuxiliar = lAuxiliar & " "
        Wend
    End If
    lSequencia = lSequencia & lAuxiliar
    '===012) Endere�o do segurado - bairro....................................(30 posi��es - total = 279).
    If gfPreenchido(pP0042100!End_Bairro) Then
        lAuxiliar = pP0042100!End_Bairro
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===013) Endere�o do segurado - cidade....................................(30 posi��es - total = 309).
    If gfPreenchido(pP0042100!End_Cidade) Then
        lAuxiliar = pP0042100!End_Cidade
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===014) Endere�o do segurado - unidade da federa��o.......................(2 posi��es - total = 311).
    If gfPreenchido(pP0042100!End_UF) Then
        lAuxiliar = pP0042100!End_UF
        While Len(lAuxiliar) < 2
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(2, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===015) Endere�o do segurado - CEP........................................(8 posi��es - total = 319).
    If gfPreenchido(pP0042100!End_CEP) Then
        lAuxiliar = pP0042100!End_CEP
        While Len(lAuxiliar) < 8
            lAuxiliar = "0" & lAuxiliar
        Wend
    Else
        lAuxiliar = String(8, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===016) Endere�o do segurado - telefones.................................(30 posi��es - total = 349).
    If gfPreenchido(pP0042100!End_Telefones) Then
        lAuxiliar = pP0042100!End_Telefones
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===017) Endere�o de cobran�a - logradouro................................(73 posi��es - total = 422).
    lAuxiliar = ""
    If gfPreenchido(pP0042100!Cob_Tip_Logradouro) Then
        lAuxiliar = Trim$(pP0042100!Cob_Tip_Logradouro) & " "
    End If
    If gfPreenchido(pP0042100!Cob_Nom_Logradouro) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!Cob_Nom_Logradouro) & " "       'CORRIGIDO.
    End If
    If gfPreenchido(pP0042100!Cob_Complemento) Then
        lAuxiliar = lAuxiliar & Trim$(pP0042100!Cob_Complemento)
    End If
    If Len(lAuxiliar) > 73 Then
        lAuxiliar = Left$(lAuxiliar, 73)
    Else
        While Len(lAuxiliar) < 73
            lAuxiliar = lAuxiliar & " "
        Wend
    End If
    lSequencia = lSequencia & lAuxiliar
    '===018) Endere�o de cobran�a - bairro....................................(30 posi��es - total = 452).
    If gfPreenchido(pP0042100!Cob_Bairro) Then
        lAuxiliar = pP0042100!Cob_Bairro
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===019) Endere�o de cobran�a - cidade....................................(30 posi��es - total = 482).
    If gfPreenchido(pP0042100!Cob_Cidade) Then
        lAuxiliar = pP0042100!Cob_Cidade
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===020) Endere�o de cobran�a - unidade da federa��o.......................(2 posi��es - total = 484).
    If gfPreenchido(pP0042100!Cob_UF) Then
        lAuxiliar = pP0042100!Cob_UF
        While Len(lAuxiliar) < 2
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(2, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===021) Endere�o de cobran�a - CEP........................................(8 posi��es - total = 492).
    If gfPreenchido(pP0042100!Cob_CEP) Then
        lAuxiliar = pP0042100!Cob_CEP
        While Len(lAuxiliar) < 8
            lAuxiliar = "0" & lAuxiliar
        Wend
    Else
        lAuxiliar = String(8, "0")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===022) Endere�o de cobran�a - telefones.................................(30 posi��es - total = 522).
    If gfPreenchido(pP0042100!Cob_Telefones) Then
        lAuxiliar = pP0042100!Cob_Telefones
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
    Else
        lAuxiliar = String(30, " ")
    End If
    lSequencia = lSequencia & lAuxiliar
    '===023) In�cio de vig�ncia................................................(8 posi��es - total = 530).
    lSequencia = lSequencia & Format$(pP0042100!Dat_Vig_Inicio, "00000000")
    '===024) T�rmino de vig�ncia...............................................(8 posi��es - total = 538).
    lSequencia = lSequencia & Format$(pP0042100!Dat_Vig_Termino, "00000000")
    '===025) Corretagem.......................................................(33 posi��es - total = 571).
    lSequencia = lSequencia & Format$(pP0042100!Cor1_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor1_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cor2_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor2_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cor3_Codigo, "0000000")
    lAuxiliar = Format$(pP0042100!Cor3_Cms_Casco, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===026) Cosseguros.......................................................(50 posi��es - total = 621).
    lSequencia = lSequencia & Format$(pP0042100!Cos1_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos1_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos2_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos2_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos3_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos3_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos4_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos4_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    lSequencia = lSequencia & Format$(pP0042100!Cos5_Codigo, "000000")
    lAuxiliar = Format$(pP0042100!Cos5_Percentual, "00.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===027) Juros ao m�s......................................................(4 posi��es - total = 625).
    Select Case pP0042100!Pag_Ant_Ind
        Case 1, 2       'Pagamento antecipado.
            Select Case pP0042100!Qtd_Parcelas_VM
                Case 0
                    lAuxiliar = "00,00"
                Case 1
                    lAuxiliar = Format$(pP0042100!Jur_Ant_01, "00.00")
                Case 2
                    lAuxiliar = Format$(pP0042100!Jur_Ant_02, "00.00")
                Case 3
                    lAuxiliar = Format$(pP0042100!Jur_Ant_03, "00.00")
                Case 4
                    lAuxiliar = Format$(pP0042100!Jur_Ant_04, "00.00")
                Case 5
                    lAuxiliar = Format$(pP0042100!Jur_Ant_05, "00.00")
                Case 6
                    lAuxiliar = Format$(pP0042100!Jur_Ant_06, "00.00")
                Case 7
                    lAuxiliar = Format$(pP0042100!Jur_Ant_07, "00.00")
                Case 8
                    lAuxiliar = Format$(pP0042100!Jur_Ant_08, "00.00")
                Case 9
                    lAuxiliar = Format$(pP0042100!Jur_Ant_09, "00.00")
                Case 10
                    lAuxiliar = Format$(pP0042100!Jur_Ant_10, "00.00")
                Case 11
                    lAuxiliar = Format$(pP0042100!Jur_Ant_11, "00.00")
                Case 12
                    lAuxiliar = Format$(pP0042100!Jur_Ant_12, "00.00")
            End Select
        Case 9      'Pagamento postecipado.
            Select Case pP0042100!Qtd_Parcelas_VM
                Case 0
                    lAuxiliar = "00,00"
                Case 1
                    lAuxiliar = Format$(pP0042100!Jur_Pos_01, "00.00")
                Case 2
                    lAuxiliar = Format$(pP0042100!Jur_Pos_02, "00.00")
                Case 3
                    lAuxiliar = Format$(pP0042100!Jur_Pos_03, "00.00")
                Case 4
                    lAuxiliar = Format$(pP0042100!Jur_Pos_04, "00.00")
                Case 5
                    lAuxiliar = Format$(pP0042100!Jur_Pos_05, "00.00")
                Case 6
                    lAuxiliar = Format$(pP0042100!Jur_Pos_06, "00.00")
                Case 7
                    lAuxiliar = Format$(pP0042100!Jur_Pos_07, "00.00")
                Case 8
                    lAuxiliar = Format$(pP0042100!Jur_Pos_08, "00.00")
                Case 9
                    lAuxiliar = Format$(pP0042100!Jur_Pos_09, "00.00")
                Case 10
                    lAuxiliar = Format$(pP0042100!Jur_Pos_10, "00.00")
                Case 11
                    lAuxiliar = Format$(pP0042100!Jur_Pos_11, "00.00")
                Case 12
                    lAuxiliar = Format$(pP0042100!Jur_Pos_12, "00.00")
            End Select
    End Select
    lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
    '===028) Custo da ap�lice.................................................(10 posi��es - total = 635).
    lAuxiliar = Format$(pP0042100!Cus_Emissao, "00000000.00")
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===029) Valor do IOF.....................................................(10 posi��es - total = 645).
    If pP0042100!Val_IOF_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_IOF_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_IOF_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===030) N�mero de parcelas................................................(2 posi��es - total = 647).
    lAuxiliar = Format$(pP0042100!Qtd_Parcelas_VM, "00")
    lSequencia = lSequencia & lAuxiliar
    '===031) Indicador de primeira parcela paga antecipada......................(1 posi��o - total = 648).
    lAuxiliar = Format$(pP0042100!Pag_Ant_Ind, "0")
    lSequencia = lSequencia & lAuxiliar
    '===032) Valor da primeira parcela........................................(10 posi��es - total = 658).
    If pP0042100!Val_Parcela1_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_Parcela1_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_Parcela1_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===033) Valor das demais parcelas........................................(10 posi��es - total = 668).
    If pP0042100!Val_Parcelas_VM = 0 Then
        lAuxiliar = Format$(pP0042100!Val_Parcelas_VD, "00000000.00")
    Else
        lAuxiliar = Format$(pP0042100!Val_Parcelas_VM, "00000000.00")
    End If
    lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
    '===034) Pagamento em bloqueto - n�mero do bloqueto.......................(10 posi��es - total = 678).
    lSequencia = lSequencia & Format$(pP0042100!Pag_Ant_Bloqueto, "0000000000")
    '===035) Pagamento atrav�s de carn�.......................................(11 posi��es - total = 689).
    'a) C�digo do banco.
    lSequencia = lSequencia & Format$(pP0042100!Carne_Cod_Banco, "000")
    'b) Vencimento da primeira parcela.
    lSequencia = lSequencia & Format$(pP0042100!Ven_Parcela1_VM, "00000000")
    '===036) Pagamento atrav�s de d�bito em conta.............................(18 posi��es - total = 707).
    'a) C�digo do banco.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Banco, "000")
    'b) C�digo da ag�ncia.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Agencia, "0000")
    'c) C�digo da conta corrente.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Cod_Conta, "000000000")
    'd) Dia para d�bito.
    lSequencia = lSequencia & Format$(pP0042100!Deb_Dia, "00")
    '===037) Juros de mora.....................................................(4 posi��es - total = 711).
    lSequencia = lSequencia & "0450"

    '4. Obt�m dados dos itens - j� foram obtidos os registros dos itens - pP0042200.
    'a) Verifica base de dados.
    If pP0042200.RecordCount = 0 Then
        pMensagem = "FTE0056 - " & gPrefixo & _
                    "N�o localizado registro de item (c�lculo do c�digo de unicidade)."
        Exit Function
    End If
    'b) Coberturas dos itens - j� foram obtidos os registros de coberturas dos itens - pP0042600.
    'c) Descontos dos itens - j� foram obtidos os registros de descontos dos itens - pP0042700.

    '5. Continua seq��ncia para c�lculo do c�digo de unicidade com dados dos itens.
    pP0042200.MoveFirst
    While Not pP0042200.EOF
        'a) Obt�m valores das coberturas.
        lIS_Casco = 0
        lNivRCDM = 0
        lIS_RCDM = 0
        lNivRCDC = 0
        lIS_RCDC = 0
        lIS_RCMO = 0
        lIS_APPMorte = 0
        lIS_APPInvalidez = 0
        lIS_APPDMH = 0
        If pP0042600.RecordCount <> 0 Then
            pP0042600.MoveFirst
            While Not pP0042600.EOF
                If pP0042600!Num_Item = pP0042200!Num_Item Then
                    Select Case pP0042600!Cod_Cobert
                        Case gCobCasco
                            lIS_Casco = pP0042600!Val_IS
                        Case gCobRCDM
                            lNivRCDM = pP0042600!Cod_Niv_IS
                            lIS_RCDM = pP0042600!Val_IS
                        Case gCobRCDC
                            lNivRCDC = pP0042600!Cod_Niv_IS
                            lIS_RCDC = pP0042600!Val_IS
                        Case gCobRCMO
                            lIS_RCMO = pP0042600!Val_IS
                        Case gCobAPPMorte
                            lIS_APPMorte = pP0042600!Val_IS
                        Case gCobAPPInvalidez
                            lIS_APPInvalidez = pP0042600!Val_IS
                        Case gCobAPPDMH
                            lIS_APPDMH = pP0042600!Val_IS
                    End Select
                End If
                pP0042600.MoveNext
            Wend
        End If

        'b) Obt�m percentuais de desconto.
        lClaBonus = 0
        lPerDesAPP = 0
        lPerDesBonus = 0
        lPerDesCasco = 0
        lPerDesFidelidade = 0
        lPerDesFrota = 0
        lPerDesPerfil = 0
        lPerDesRC = 0
        If pP0042700.RecordCount <> 0 Then
            pP0042700.MoveFirst
            While Not pP0042700.EOF
                If pP0042700!Num_Item = pP0042200!Num_Item Then
                    Select Case pP0042700!Cod_Desc
                        Case gDesAPP
                            lPerDesAPP = pP0042700!Per_Desc
                        Case gDesBonus
                            lPerDesBonus = pP0042700!Per_Desc
                            lClaBonus = pP0042700!Cod_Classe_Desc
                        Case gDesCasco
                            lPerDesCasco = pP0042700!Per_Desc
                        Case gDesFidelidade
                            lPerDesFidelidade = pP0042700!Per_Desc
                        Case gDesFrota
                            lPerDesFrota = pP0042700!Per_Desc
                        Case gDesPerfil
                            lPerDesPerfil = pP0042700!Per_Desc
                        Case gDesRC
                            lPerDesRC = pP0042700!Per_Desc
                    End Select
                End If
                pP0042700.MoveNext
            Wend
        End If

        'c) Continua seq��ncia para c�lculo do c�digo de unicidade com dados do item.
        '===038) N�mero do item..................................................(4 posi��es - total = 4).
        lSequencia = lSequencia & Format$(pP0042200!Num_Item, "0000")
        '===039) Tipo de emiss�o.................................................(3 posi��es - total = 7).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Emissao, "000")
        '===040) Tipo do produto..................................................(1 posi��o - total = 8).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Produto, "0")
        '===041) C�digo do ve�culo..............................................(8 posi��es - total = 16).
        lSequencia = lSequencia & pP0042200!Cod_Veiculo
        '===042) C�digo Renavam................................................(10 posi��es - total = 26).
        lSequencia = lSequencia & Format$(pP0042200!Val_Cus_Emissao, "0000000000")
        '===043) Ano de fabrica��o..............................................(4 posi��es - total = 30).
        lSequencia = lSequencia & Format$(pP0042200!Ano_Fabricacao, "0000")
        '===044) Ano de modelo..................................................(4 posi��es - total = 34).
        lSequencia = lSequencia & Format$(pP0042200!Ano_Modelo, "0000")
        '===045) Indicador de ve�culo 0 km.......................................(1 posi��o - total = 35).
        lSequencia = lSequencia & Format$(pP0042200!COD_IDEN_0KM, "0")
        '===046) C�digo da placa................................................(8 posi��es - total = 43).
        lAuxiliar = UCase$(pP0042200!Cod_Placa)
        While Len(lAuxiliar) < 8
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===047) Tipo do combust�vel.............................................(1 posi��o - total = 44).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Combustivel, "0")
        '===048) C�digo da chassi nacional.....................................(20 posi��es - total = 64).
        lAuxiliar = UCase$(pP0042200!Cod_Chassi)
        While Len(lAuxiliar) < 20
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===049) C�digo da chassi estrangeiro..................................(20 posi��es - total = 84).
        lAuxiliar = UCase$(pP0042200!Cod_Chassi_Estrang)
        While Len(lAuxiliar) < 20
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===050) C�digo FIPE....................................................(6 posi��es - total = 90).
        lSequencia = lSequencia & Format$(pP0042200!Cod_FIPE, "000000")
        '===051) Categoria......................................................(2 posi��es - total = 92).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Categoria, "00")
        '===052) CEP de pernoite...............................................(8 posi��es - total = 100).
        lSequencia = lSequencia & Format$(pP0042200!Cep_Regiao, "00000000")
        '===053) Franquia de casco............................................(10 posi��es - total = 110).
        If pP0042200!Val_Franquia_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Val_Franquia_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Val_Franquia_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===054) Indicador de question�rio de avalia��o de risco................(1 posi��o - total = 111).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Questionario, "0")
        '===055) Renova��o Yasuda - n�mero da ap�lice.........................(10 posi��es - total = 121).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Num_Apolice, "0000000000")
        '===056) Renova��o Yasuda - item da ap�lice............................(4 posi��es - total = 125).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Num_Item, "0000")
        '===057) Indicador da exist�ncia do benefici�rio........................(1 posi��o - total = 126).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Beneficiario, "0")
        '===058) Nome do benefici�rio.........................................(20 posi��es - total = 146).
        lAuxiliar = UCase$(pP0042200!Nom_Beneficiario)
        While Len(lAuxiliar) < 20
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===059) Nome do propriet�rio.........................................(30 posi��es - total = 176).
        lAuxiliar = UCase$(pP0042200!Nom_Proprietario)
        While Len(lAuxiliar) < 30
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===060) Tipo do cobertura..............................................(1 posi��o - total = 177).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Cobertura, "0")
        '===061) Tipo da assist�ncia 24 horas (tipo do limite de guincho).......(1 posi��o - total = 178).
        lSequencia = lSequencia & Format$(pP0042200!Tip_Lim_Guincho, "0")
        '===062) Cl�usula 112 (s�cio/dirigente).................................(1 posi��o - total = 179).
        lSequencia = lSequencia & Format$(pP0042200!Soc_Dirigente, "0")
        '===063) Cobertura de carro reserva.....................................(1 posi��o - total = 180).
        lSequencia = lSequencia & Format$(pP0042200!Carro_Reserva, "0")
        '===064) Cobertura de vidros............................................(1 posi��o - total = 181).
        lSequencia = lSequencia & Format$(pP0042200!COD_IDEN_VIDROS, "0")
        '===065) Cobertura de extens�o para ve�culos 0 km.......................(1 posi��o - total = 182).
        lSequencia = lSequencia & Format$(pP0042200!Ext_0km, "0")
        '===066) Acess�rio de f�brica - ar condicionado.........................(1 posi��o - total = 183).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Ar_Condic, "0")
        '===067) Acess�rio de f�brica - bancos de couro.........................(1 posi��o - total = 184).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Ban_Couro, "0")
        '===068) Acess�rio de f�brica - freios ABS..............................(1 posi��o - total = 185).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Fre_ABS, "0")
        '===069) Acess�rio de f�brica - dire��o hidr�ulica......................(1 posi��o - total = 186).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Dir_Hidra, "0")
        '===070) Acess�rio de f�brica - c�mbio autom�rico.......................(1 posi��o - total = 187).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Cam_Autom, "0")
        '===071) Acess�rio de f�brica - air bag.................................(1 posi��o - total = 188).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Air_Bag, "0")
        '===072) Acess�rios...................................................(65 posi��es - total = 253).
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_1, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_1, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_2, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_2, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!COD_ACES_3, "000")
        lAuxiliar = Format$(pP0042200!VAL_IS_ACES_3, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!Cod_Aces_4, "000")
        lAuxiliar = Format$(pP0042200!Val_IS_Aces_4, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        lSequencia = lSequencia & Format$(pP0042200!Cod_Aces_5, "000")
        lAuxiliar = Format$(pP0042200!Val_IS_Aces_5, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===073) Desconto de casco.............................................(4 posi��es - total = 257).
        lAuxiliar = Format$(lPerDesCasco, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===074) Desconto de RCF...............................................(4 posi��es - total = 261).
        lAuxiliar = Format$(lPerDesRC, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===075) Desconto de APP...............................................(4 posi��es - total = 265).
        lAuxiliar = Format$(lPerDesAPP, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===076) Classe de b�nus...............................................(2 posi��es - total = 267).
        lSequencia = lSequencia & Format$(lClaBonus, "00")
        '===077) Percentual de desconto de b�nus...............................(4 posi��es - total = 271).
        lAuxiliar = Format$(lPerDesBonus, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===078) Desconto de frota.............................................(4 posi��es - total = 275).
        lAuxiliar = Format$(lPerDesFrota, "00.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 2) & Right$(lAuxiliar, 2)
        '===079) Renova��o de cong�nere - c�digo da seguradora.................(3 posi��es - total = 278).
        lSequencia = lSequencia & Format$(pP0042200!Ren_Con_Seguradora, "000")
        '===080) Renova��o de cong�nere - c�digo da ap�lice...................(15 posi��es - total = 293).
        lAuxiliar = UCase$(pP0042200!Ren_Con_Apolice)
        While Len(lAuxiliar) < 15
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===081) Renova��o de cong�nere - item da ap�lice......................(5 posi��es - total = 298).
        lAuxiliar = UCase$(pP0042200!Ren_Con_Item)
        While Len(lAuxiliar) < 5
            lAuxiliar = lAuxiliar & " "
        Wend
        lSequencia = lSequencia & lAuxiliar
        '===082) Renova��o de cong�nere - c�digo de identifica��o.............(14 posi��es - total = 312).
        lAuxiliar = ""
        If gfPreenchido(pP0042200!Clausula1) Then
            lAuxiliar = pP0042200!Clausula1
        End If
        If gfPreenchido(pP0042200!Clausula2) Then
            lAuxiliar = lAuxiliar & pP0042200!Clausula2
        End If
        If gfPreenchido(pP0042200!Clausula3) Then
            lAuxiliar = lAuxiliar & pP0042200!Clausula3
        End If
        If Len(lAuxiliar) > 14 Then
            lAuxiliar = Left$(lAuxiliar, 14)
        Else
            While Len(lAuxiliar) < 14
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===083) Renova��o de cong�nere - indicador de sinistro.................(1 posi��o - total = 313).
        lSequencia = lSequencia & Format$(pP0042200!Ind_Sinistro, "0")
        '===084) Import�ncia segurada de casco................................(10 posi��es - total = 323).
        lAuxiliar = Format$(lIS_Casco, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===085) N�vel do cobertura RC-DM......................................(2 posi��es - total = 325).
        lSequencia = lSequencia & Format$(lNivRCDM, "00")
        '===086) Import�ncia segurada de RC-DM................................(10 posi��es - total = 335).
        lAuxiliar = Format$(lIS_RCDM, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===087) N�vel do cobertura RC-DC......................................(2 posi��es - total = 337).
        lSequencia = lSequencia & Format$(lNivRCDC, "00")
        '===088) Import�ncia segurada de RC-DC................................(10 posi��es - total = 347).
        lAuxiliar = Format$(lIS_RCDC, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===089) Import�ncia segurada de RC-MO................................(10 posi��es - total = 357).
        lAuxiliar = Format$(lIS_RCMO, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===090) Import�ncia segurada de APP Morte............................(10 posi��es - total = 367).
        lAuxiliar = Format$(lIS_APPMorte, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===091) Import�ncia segurada de APP Invalidez permanente.............(10 posi��es - total = 377).
        lAuxiliar = Format$(lIS_APPInvalidez, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===092) Import�ncia segurada de APP DMH..............................(10 posi��es - total = 387).
        lAuxiliar = Format$(lIS_APPDMH, "00000000.00")
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===093) Pr�mio de casco..............................................(10 posi��es - total = 397).
        If pP0042200!Pr_Casco_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Casco_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Casco_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===094) Pr�mio de despesas extraodrin�rias...........................(10 posi��es - total = 407).
        If pP0042200!Pr_Des_Extr_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Des_Extr_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Des_Extr_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===095) Pr�mio de acess�rios.........................................(10 posi��es - total = 417).
        If pP0042200!Pr_Acessorios_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Acessorios_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Acessorios_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===096) Pr�mio de RC-DM..............................................(10 posi��es - total = 427).
        If pP0042200!Pr_RCDM_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCDM_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCDM_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===097) Pr�mio de RC-DC..............................................(10 posi��es - total = 437).
        If pP0042200!Pr_RCDC_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCDC_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCDC_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===098) Pr�mio da cl�usula 112 (s�cio/dirigente).....................(10 posi��es - total = 447).
        lSequencia = lSequencia & "0000000000"
        '===099) Pr�mio de RC-MO..............................................(10 posi��es - total = 457).
        If pP0042200!Pr_RCMO_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_RCMO_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_RCMO_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===100) Pr�mio de APP................................................(10 posi��es - total = 467).
        If pP0042200!Pr_APP_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_APP_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_APP_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===101) Pr�mio de assist�ncia 24 horas...............................(10 posi��es - total = 477).
        If pP0042200!Pr_Ass_24hs_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Ass_24hs_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Ass_24hs_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===102) Pr�mio de carro reserva......................................(10 posi��es - total = 487).
        If pP0042200!Pr_Carro_Reserva_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Carro_Reserva_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Carro_Reserva_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===103) Pr�mio de vidros.............................................(10 posi��es - total = 497).
        If pP0042200!Pr_Vidros_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Vidros_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Vidros_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===104) Pr�mio de extens�o para ve�culo 0 km.........................(10 posi��es - total = 507).
        If pP0042200!Pr_Ext_0km_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Ext_0km_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Ext_0km_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===105) Pr�mio l�quido...............................................(10 posi��es - total = 517).
        If pP0042200!Pr_Liquido_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Liquido_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Liquido_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===106) Pr�mio total.................................................(10 posi��es - total = 527).
        If pP0042200!Pr_Total_VM = 0 Then
            lAuxiliar = Format$(pP0042200!Pr_Total_VD, "00000000.00")
        Else
            lAuxiliar = Format$(pP0042200!Pr_Total_VM, "00000000.00")
        End If
        lSequencia = lSequencia & Left$(lAuxiliar, 8) & Right$(lAuxiliar, 2)
        '===107) Question�rio de avalia��o de risco - nome do condutor........(30 posi��es - total = 557).
        lAuxiliar = UCase$(pP0042200!Nom_Condutor)
        If Len(lAuxiliar) > 30 Then
            lAuxiliar = Left$(lAuxiliar, 30)
        Else
            While Len(lAuxiliar) < 30
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===108) Question�rio de avalia��o de risco - RG do condutor..........(20 posi��es - total = 577).
        lAuxiliar = UCase$(pP0042200!Cod_RG)
        If Len(lAuxiliar) > 20 Then
            lAuxiliar = Left$(lAuxiliar, 20)
        Else
            While Len(lAuxiliar) < 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===109) Question�rio de avalia��o de risco - CPF do condutor.........(11 posi��es - total = 588).
        lAuxiliar = UCase$(pP0042200!Cod_CPF)
        If Len(lAuxiliar) > 11 Then
            lAuxiliar = Left$(lAuxiliar, 11)
        Else
            While Len(lAuxiliar) < 11
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===110) Question�rio - rela��o do condutor com o proponente............(1 posi��o - total = 589).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Relacao, "0")
        '===111) Question�rio - outra rela��o do condutor.....................(20 posi��es - total = 609).
        lAuxiliar = UCase$(pP0042200!Dsc_Outra_Relacao)
        If Len(lAuxiliar) > 20 Then
            lAuxiliar = Left$(lAuxiliar, 20)
        Else
            While Len(lAuxiliar) < 20
                lAuxiliar = lAuxiliar & " "
            Wend
        End If
        lSequencia = lSequencia & lAuxiliar
        '===112) Question�rio - estado civil do condutor........................(1 posi��o - total = 610).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Est_Civil)
        '===113) Question�rio - sexo do condutor................................(1 posi��o - total = 611).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Sexo)
        '===114) Question�rio - data de nascimento do condutor.................(8 posi��es - total = 619).
        lSequencia = lSequencia & Format$(pP0042200!Dat_Nasc, "00000000")
        '===115) Question�rio - ano da primeira habilita��o do condutor........(4 posi��es - total = 623).
        lSequencia = lSequencia & Format$(pP0042200!Dat_Pri_Habilit, "0000")
        '===116) Question�rio - garagem do ve�culo..............................(1 posi��o - total = 624).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Garagem)
        '===117) Question�rio - utiliza��o do ve�culo...........................(1 posi��o - total = 625).
        lSequencia = lSequencia & UCase$(pP0042200!Cod_Iden_Utiliza)
        '===118) Question�rio - ve�culo conduzido por pessoas 18 e 24 anos?.....(1 posi��o - total = 626).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Pessoas, "0")
        '===119) Question�rio - dispositivo de seguran�a 1......................(1 posi��o - total = 627).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_1, "0")
        '===120) Question�rio - dispositivo de seguran�a 2......................(1 posi��o - total = 628).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_2, "0")
        '===121) Question�rio - dispositivo de seguran�a 3......................(1 posi��o - total = 629).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_3, "0")
        '===122) Question�rio - dispositivo de seguran�a 4......................(1 posi��o - total = 630).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_4, "0")
        '===123) Question�rio - dispositivo de seguran�a 5......................(1 posi��o - total = 631).
        lSequencia = lSequencia & Format$(pP0042200!Cod_Iden_Disp_Seg_5, "0")

        'd) Pr�ximo item.
        pP0042200.MoveNext
    Wend

    '6. Preencher o campo de seq��ncia para que o tamanho fique em m�ltiplo de 10.
    lTamanho = Len(lSequencia)
    lResto = lTamanho Mod 10
    If lResto <> 0 Then
        lSequencia = lSequencia & String(10 - lResto, " ")
    End If

    '7. Dividir o campo de seq��ncia em campos de 10 posi��es cada.
    lTamanho = Len(lSequencia)
    lResultado = lTamanho / 10
    ReDim lCampo1(lResultado)
    For lI = 1 To lResultado
        lCampo1(lI) = Mid$(lSequencia, ((lI - 1) * 10) + 1, 10)
    Next lI

    '8. Para cada campo de 10 posi��es, transforma cada caracter num valor ASC e soma estes valores.
    ReDim lCampo2(lResultado)
    For lI = 1 To lResultado
        lCampo2(lI) = Asc(Mid(lCampo1(lI), 1, 1)) + Asc(Mid(lCampo1(lI), 2, 1)) + _
                      Asc(Mid(lCampo1(lI), 3, 1)) + Asc(Mid(lCampo1(lI), 4, 1)) + _
                      Asc(Mid(lCampo1(lI), 5, 1)) + Asc(Mid(lCampo1(lI), 6, 1)) + _
                      Asc(Mid(lCampo1(lI), 7, 1)) + Asc(Mid(lCampo1(lI), 8, 1)) + _
                      Asc(Mid(lCampo1(lI), 9, 1)) + Asc(Mid(lCampo1(lI), 10, 1))
        'MsgBox "Resultado " & lI & " = " & lCampo2(lI)
    Next lI

    '9. Somar todos os resultados obtidos.
    lTotal = 0
    For lI = 1 To lResultado
        lTotal = lTotal + lCampo2(lI)
    Next lI

    '10. Resultado: c�digo de verifica��o.
    pCodVerificacao = Right$(Format$(lTotal, "000000"), 6)

    mfCalCodUniXXXXX2 = True
End Function

Private Function mfAbrBasSQL(ByVal pIdeBasDados As String, ByVal pTipBasDados As String, _
                             ByVal pSerBasDados As String, ByVal pEndBasDados As String, _
                             ByVal pUIDBasDados As String, ByVal pPWDBasDados As String, _
                             ByRef pADOBasDados As ADODB.Connection, ByRef pMensagem As String) _
                             As Boolean
    'Fun��o: abre base de dados.

    'Par�metros de entrada...pIdeBasDados...Identificador da base de dados.
    '                        pTipBasDados...Tipo da base de dados.
    '                        pEndBasDados...Endere�o da base de dados.
    'Par�metros de sa�da.....pADOBasDados...Base de dados.
    '                        pMensagem......Mensagem.

    Dim lIniCatalog     As String   'Par�metro INITIAL CATALOG.
    Dim lOpen           As String   'Linha para comando OPEN.

    mfAbrBasSQL = False

    '1. Verifica identifica��o da base de dados.
    If Not gfPreenchido(pIdeBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (identifica��o da base de dados n�o " & _
                    "preenchida)."
        Exit Function
    End If
'    Select Case UCase$(pIdeBasDados)
'        Case "P0044700", "P0044800", "CORRETORES", "P0042100", "P0042200", "P0042300", _
'             "P0042400", "P0042500", "P0042600", "P0042700", "P0042800", "P0042900", _
'             "P0043000", "P0043100", "P0043200", "P0043300", "P0043400", "P0043500", _
'             "P0043600", "P0043700", "P0043800", "P0043900", "P0044000", "P0044100", _
'             "P0044200", "P0044300", "P0044500", "EAPDB", "DBSYASEMIS", "GED"
'            'Nada a fazer - bases de dados v�lidas.
'        Case Else
'            pMensagem = "FTE0001 - Erro ao abrir base de dados (identifica��o da base de dados " & _
'                        "desconhecida: " & pIdeBasDados & ")."
'            Exit Function
'    End Select

    '2. Verifica tipo da base de dados.
    If Not gfPreenchido(pTipBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (tipo da base de dados " & pIdeBasDados & _
                    " n�o preenchido)."
        Exit Function
    End If
    If pTipBasDados <> "2" Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (tipo da base de dados " & pIdeBasDados & _
                    " desconhecido: " & pTipBasDados & ")."
        Exit Function
    End If

    '3. Verifica endere�o da base de dados.
    If Not gfPreenchido(pEndBasDados) Then
        pMensagem = "FTE0001 - Erro ao abrir base de dados (endere�o da base de dados " & pEndBasDados & _
                    " n�o preenchido)."
        Exit Function
    End If

    '4. Monta linha para comando Open.
    DBEngine.RegisterDatabase pIdeBasDados, "SQL Server", True, "Description=SYASEMIS" & vbCr & _
                            "Server=" & pSerBasDados & vbCr & "Database=" & pEndBasDados
    'lOpen = "Driver={Microsoft Access Driver (*.mdb)};Dbq=" & pEndBasDados
    '5. Abre base de dados.
    'a) Posiciona conex�o.
    On Error Resume Next
    Set pADOBasDados = New ADODB.Connection
    If Err <> 0 Then
        pMensagem = "FTE0001 - Erro ao base de dados (" & pIdeBasDados & _
                    " - comando SET New ADODB.Connection - erro " & Err & " - " & Error & ")."
        On Error GoTo 0
        Exit Function
    End If
    pADOBasDados.ConnectionString = "driver={SQL Server};server=" & pSerBasDados & _
                                    ";uid=" & pUIDBasDados & ";pwd=" & pPWDBasDados & _
                                    ";database=" & pEndBasDados
    pADOBasDados.ConnectionTimeout = 30
    'b) Posiciona propriedade CursorLocation.
    'pADOBasDados.CursorLocation = adUseClient
    If Err <> 0 Then
        pMensagem = "FTE0001 - Erro ao base de dados (" & pIdeBasDados & _
                    " - Comando CursorLocation = adUseClient - erro: " & Err & " - " & Error & ")."
        On Error GoTo 0
        Exit Function
    End If
    'c) Abre base de dados.
    pADOBasDados.Open
    If Err <> 0 Then
        pMensagem = "FTE0001 - Erro ao base de dados (" & pIdeBasDados & _
                    " - comando Open " & lOpen & " - erro: " & Err & " - " & Error & ")."
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    mfAbrBasSQL = True
End Function

Private Function mfExeSQL(ByVal pBasDados As ADODB.Connection, ByVal pComando As String, _
                          ByRef pMensagem As String) As Double
    'Fun��o: executa comando SQL (espec�fico para SQL-SERVER).

    'Par�metros de entrada...pBasDados......base de dados a ser processada.
    '                        pComando ......comando SQL a ser executado.
    'Par�metros de sa�da.....pMensagem......mensagem.
    '                        pRegAfetados...quantidade de registros afetados pelo comando SQL (OPCIONAL).

    'Resultado da fun��o.....C�digo de retorno do comando SQL:
    '                        0 = comando OK.
    '                        3022 = chave duplicada (inclus�o).

    Dim rsBasDados      As ADODB.Recordset  'RecordSet.

    mfExeSQL = 999

    Set rsBasDados = New ADODB.Recordset
    rsBasDados.CursorType = adOpenKeyset
    rsBasDados.LockType = adLockPessimistic

    On Error Resume Next
    
    Call gpGraLog(0, pComando)
    
    rsBasDados.Open pComando, pBasDados
    Select Case Err
        Case 0
            'Nada a fazer.
        Case 3022
            pMensagem = "FTE0027 - Erro ao executar comando SQL: duplicidade de chave. " & pComando
        Case Else
            pMensagem = "FTE0027 - Erro ao executar comando SQL: " & Err & " - " & Error & " " & pComando
    End Select
    mfExeSQL = Err      'Este comando precisa ser o �ltimo antes do On Error GoTo 0.
    On Error GoTo 0
End Function

Public Function gfObtemIniP28V300(ByRef pEndPastas As String, _
                               ByRef pEndSyasEdi As String, _
                               ByRef pIdeBasEAPDB As String, _
                               ByRef pTipBasEAPDB As String, _
                               ByRef pSerBasEAPDB As String, _
                               ByRef pEndBasEAPDB As String, _
                               ByRef pUIDBasEAPDB As String, _
                               ByRef pPWDBasEAPDB As String, _
                               ByRef pIdeBasSYASEMIS As String, _
                               ByRef pTipBasSyasEmis As String, _
                               ByRef pSerBasSYASEMIS As String, _
                               ByRef pEndBasSYASEMIS As String, _
                               ByRef pUIDBasSYASEMIS As String, _
                               ByRef pPWDBasSYASEMIS As String, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: Busca os parametros de inicializa��o
  
'******** Exemplo do conteudo do arquivo
'//- Raiz do endere�o onde se localizam as pastas com os arquivos para transferencia/recep��o
'EndPastas = "C:\User_c\P24V007\MailboxesTeste\"
'
'//- Drive "Raiz do programa SYAS-EDI Server (P24V007.exe)
'EndSYASEDI = "C:\User_c\P24V007\"
'
'//- Informa��es da base de dados EAPDB
'IdeBasEAPDB = "EAPDB"
'TipBasEAPDB = "2"
'SerBasEAPDB = "spX20112cslumix"
'EndBasEAPDB = "EAPDB"
'UIDBasEAPDB = "workflow"
'PWDBasEAPDB = "yasworkflow"
'
'//- Informa��es da base de dados Syas_EMIS
'IdeBasSYASEMIS = "SYAS_EMIS"
'TipBasSYASEMIS = "2"
'SerBasSYASEMIS = "spX20112cslumix"
'EndBasSYASEMIS = "SYAS_EMIS"
'UIDBasSYASEMIS = "workflow"
'PWDBasSYASEMIS = "yasworkflow"
'*****************

    Dim lEndP28V300_INI    As String   'Endere�o do arquivo P28V300.INI.
    Dim lNumP28V300_INI    As Integer  'Utilizado com FreeFile.
    Dim lRegistro          As String   'Registro.
    Dim lStrAux            As String   'String auxiliar

Err = 0
On Error GoTo gfObtemIniP28V300_ERRO

    gfObtemIniP28V300 = False

    '1. Verifica arquivo P28V300.INI.
    lEndP28V300_INI = gAppPath & "P28V300.INI"
    If Not gfPreenchido(Dir(lEndP28V300_INI)) Then
        pMensagem = "N�o localizado arquivo de inicializa��o"
        Exit Function
    End If
    lNumP28V300_INI = FreeFile
    Open lEndP28V300_INI For Input Access Read As #lNumP28V300_INI
    If Err <> 0 Then
        pMensagem = "Erro ao abrir arquivo de inicializa��o"
        Exit Function
    End If

     
    Do While Not EOF(lNumP28V300_INI)
        Line Input #lNumP28V300_INI, lRegistro
        'Obtem o usuario de transmissao
        If UCase(Mid(lRegistro, 1, 10)) = "ENDPASTAS=" Then
            lStrAux = Trim(Mid(lRegistro, 11))
            lStrAux = Replace(lStrAux, """", "")
            pEndPastas = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 11)) = "ENDSYASEDI=" Then
            lStrAux = Trim(Mid(lRegistro, 12))
            lStrAux = Replace(lStrAux, """", "")
            pEndSyasEdi = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "IDEBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pIdeBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "TIPBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pTipBasEAPDB = Val(lStrAux)
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "SERBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pSerBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "ENDBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pEndBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "UIDBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pUIDBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "PWDBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pPWDBasEAPDB = lStrAux
            lStrAux = ""
        End If
        
        If UCase(Mid(lRegistro, 1, 15)) = "IDEBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pIdeBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "TIPBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pTipBasSyasEmis = Val(lStrAux)
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "SERBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pSerBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "ENDBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pEndBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "UIDBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pUIDBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "PWDBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pPWDBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
    Loop
    Close #lNumP28V300_INI
    
'- Consiste os dados obtidos
    
    If gfPreenchido(pEndPastas) = False Then
        pMensagem = "N�o foi possivel obter o endere�o das pastas"
        GoTo gfObtemIniP28V300_SAIDA
    Else
        If gfPreenchido(Dir(pEndPastas, vbDirectory)) = False Then
            pMensagem = "N�o foi possivel acessar o endere�o " & pEndPastas
            GoTo gfObtemIniP28V300_SAIDA
        End If
    End If
    
    If gfPreenchido(pEndSyasEdi) = False Then
        pMensagem = "N�o foi possivel obter o endere�o do servidor SYAS-EDI"
        GoTo gfObtemIniP28V300_SAIDA
    Else
        If gfPreenchido(Dir(pEndSyasEdi, vbDirectory)) = False Then
            pMensagem = "N�o foi possivel acessar o endere�o " & pEndSyasEdi
            GoTo gfObtemIniP28V300_SAIDA
        End If
    End If
    
    gfObtemIniP28V300 = True
gfObtemIniP28V300_SAIDA:
    Exit Function

gfObtemIniP28V300_ERRO:
    If gfPreenchido(pMensagem) = True Then
        pMensagem = " gfObtemIniP28V300 - ERRO " & pMensagem
    Else
        pMensagem = " gfObtemIniP28V300 - ERRO " & Err & " - " & Error$
    End If
    Call gpGraLog(0, pMensagem)
    GoTo gfObtemIniP28V300_SAIDA
    
End Function

