Attribute VB_Name = "basM46V401"
Option Explicit
Public gDiretorio           As String
Public objPedido            As clsA46V702A  'Objeto da classe clsA46V702A  (TAB_PED)
Public objstcPedido         As stcA46V702B  'Objeto da classe de estrutura stcA46V702B (TAB_PED)
Private Declare Function MoveFile Lib "kernel32" Alias "MoveFileA" _
                         (ByVal lpExistingFileName As String, ByVal lpNewFileName As String) As Long
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public Sub gpPausa(ByVal lSegundos)

Dim i
    Dim lMiliSegundos   As Double
    
        lMiliSegundos = lSegundos * 1000

    i = DoEvents
    Sleep (lMiliSegundos)
    i = DoEvents
    
    Exit Sub
    
End Sub

Sub Main()
    Dim lbdP00MPED      As ADODB.Connection 'Base de dados: P0042300.
    Dim lCodCorretor    As String           'C�digo do corretor.
    Dim lCodUsuario     As String  'Long             'C�digo do usu�rio.
    Dim lDatModulo      As Double           'Data do m�dulo.
    Dim lDatVersao      As String           'Data da vers�o.
    Dim lEndP2842400    As String           'Endere�o do arquivo P2842400.EXE.
    Dim lLargura        As Integer          'Largura.
    Dim lMensagem       As String           'Mensagem.
    Dim lNumP2842400    As Integer          'Utilizado com FreeFile para o arquivo P2842400.EXE.
    Dim lPosicao        As Integer          'Utilizado com InStr.
    Dim lRegistro       As String           'Registro.
    

    Screen.MousePointer = vbHourglass

    '1. Verifica se form j� est� ativo.
    If App.PrevInstance = True Then
        End
    End If

    '2. Obt�m informa��es iniciais do sistema: tipo do usu�rio, endere�os das bases de dados, endere�os
    '   dos arquivos de impress�o, indicador de uso do aux�lio autom�tico, nome ou c�digo do usu�rio.
    Call gM46V999.gpInicia("")

    '3. Emite mensagem de entrada (precisa ser depois de obter dados do arquivo de inicializa��o).
    Call gM46V999.gpGraLog(0, "AGE0001 - In�cio do processamento do programa " & App.EXEName & ".")

    '4. procesa os arquivos
    Call mpCarregaArquivosRecebidos

    
    'Finaliza o Programa
    End

End Sub
Private Sub mpCarregaArquivosRecebidos()
Dim clsA46V601          As clsA46V601A      'Classe: cria arquivo de transmiss�o.
Dim lEndArqTransmissao  As String
Dim lMensagem           As String
Dim lPathArqs           As String
Dim lArquivo            As String
Dim lCkPoint            As String

    
Err = 0
On Error GoTo TRATAMENTO_ERRO

    lArquivo = Dir(gM46V999.gAppPath & "*.034")
    Do While gM46V999.gfPreenchido(lArquivo) = True
        lEndArqTransmissao = gM46V999.gAppPath & lArquivo
        Set clsA46V601 = New clsA46V601A
        Set clsA46V601.M46V999 = gM46V999
        If Not clsA46V601.gfRecArqCotacaoAceitaRec(lEndArqTransmissao, lMensagem) Then
            Call gM46V999.gpGraLog(0, lMensagem)
        End If
        Kill gM46V999.gAppPath & lArquivo
        lArquivo = Dir(gM46V999.gAppPath & "*.034")
    Loop
    Set clsA46V601 = Nothing

SAIDA:
    Err = 0
    On Error GoTo 0
    Exit Sub
TRATAMENTO_ERRO:
    If gM46V999.gfPreenchido(lMensagem) = False Then
        lMensagem = Err & " - " & Error
    End If
    lMensagem = "mpCarregaArquivosRecebidos Erro: " & lMensagem & vbCrLf
    lMensagem = lMensagem & "CheckPoint: " & lCkPoint
    Call gM46V999.gpGraLog(0, lMensagem)
    GoTo SAIDA
    
End Sub

Private Function mfMoveFile(ByVal pOrigem As String, ByVal pDestino As String) As Boolean
Dim lMsgErr         As String
Err = 0
On Error GoTo TratamentoErro
    mfMoveFile = False
    
'1- Efetua a c�pia do arquivo
    MoveFile pOrigem, pDestino

'2- Verifica a exist�ncia do arquivo no destino copiado.
    If gM46V999.gfPreenchido(Dir(pDestino)) = False Then
        lMsgErr = "O arquivo n�o foi movido para o caminho: " & pDestino
        GoTo TratamentoErro
    End If
    
    mfMoveFile = True
SAIDA:
    Err = 0
    On Error GoTo 0
    Exit Function
    
TratamentoErro:
    If gM46V999.gfPreenchido(lMsgErr) = False Then
        lMsgErr = Err & " - " & Error
    End If
    lMsgErr = "mfMoveFile Erro: " & lMsgErr
    Call gM46V999.gpGraLog(0, lMsgErr)
    GoTo SAIDA

End Function

Private Sub mpGravaErroTransmissao(ByVal pMensagem As String, ByVal pNomArqLog As String)
    'Procedure: grava arquivo log.

    '                        pMensagem...Mensagem.
Dim lEndLog             As String
Dim lPosicao            As Integer  'Utilizado com InStr.
Dim lNumLog             As Integer
Dim lMensagem           As String   'Mensagem.
Dim lMsgErr             As String
Dim lconta              As Integer
Static lNomComputador   As String   'Nome do computador.
Static lNomPrograma     As String   'Nome do programa.
Static lNomUsuario      As String   'Nome do usu�rio.
Static lPriVez          As Boolean  'Indicador de primeira vez (false).


Err = 0
On Error GoTo TRATAMENTO_ERRO

    lEndLog = gM46V999.gAppPath & pNomArqLog
    
    '2. Ao executar esta procedure pela primeira vez, obter dados utilizados na grava��o das mensagens.
    If lPriVez = False Then
        lPriVez = True

        'b) Obt�m nome do usu�rio.
        If gM46V999.gfPreenchido(gM46V999.gNomUsuario) Then
            lNomUsuario = gM46V999.gNomUsuario
            While Len(lNomUsuario) < 20
                lNomUsuario = lNomUsuario & " "
            Wend
        Else
            lNomUsuario = String(20, "X")
        End If
        'c) Obt�m nome do computador.
        lNomComputador = gM99V001.GetLoginComputerName()
        If Not gM46V999.gfPreenchido(lNomComputador) Then
            lNomComputador = "********"
        End If
        While Len(lNomComputador) < 16
            lNomComputador = lNomComputador & " "
        Wend
        'd) Obt�m nome do programa.
        lNomPrograma = Trim$(App.EXEName)
        While Len(lNomPrograma) < 12
            lNomPrograma = lNomPrograma & " "
        Wend
    End If

    '3. Abre arquivo log.
    lNumLog = FreeFile
    Open lEndLog For Output Access Write As #lNumLog
        If Err <> 0 Then
            GoTo TRATAMENTO_ERRO
        End If
        
        '6. Grava mensagem.
        lMensagem = pMensagem
        Do
            lPosicao = InStr(lMensagem, vbLf)
            If lPosicao = 0 Then
                Exit Do
            End If
            lMensagem = Left$(lMensagem, lPosicao - 1) & " " & Mid$(lMensagem, lPosicao + 1)
        Loop
        Print #lNumLog, gM46V999.gForHoje & " | " & Format$(Now, "hh:nn:ss") & " | " & lNomUsuario & " | " & _
                        lNomComputador & " | " & lNomPrograma & " | " & lMensagem
                    
    Close #lNumLog

SAIDA:
    Err = 0
    On Error GoTo 0
    Exit Sub

TRATAMENTO_ERRO:
    If gM46V999.gfPreenchido(lMsgErr) = False Then
        lMsgErr = Err & " - " & Error
    End If
    lMsgErr = "mpGravaErroTransmissao Erro: " & lMsgErr
    Call gM46V999.gpGraLog(0, lMsgErr)
    GoTo SAIDA
    
End Sub




