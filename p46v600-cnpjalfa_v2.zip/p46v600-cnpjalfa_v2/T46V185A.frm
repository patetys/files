VERSION 5.00
Object = "{0BA686C6-F7D3-101A-993E-0000C0EF6F5E}#1.0#0"; "THREED32.OCX"
Begin VB.Form frmT46V185A 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "D�bito em conta"
   ClientHeight    =   3480
   ClientLeft      =   1350
   ClientTop       =   2370
   ClientWidth     =   5190
   ControlBox      =   0   'False
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3480
   ScaleWidth      =   5190
   ShowInTaskbar   =   0   'False
   Begin VB.Frame fraBoleto 
      Caption         =   "Boleto:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1125
      Left            =   60
      TabIndex        =   1
      Top             =   1680
      Width           =   5055
      Begin VB.TextBox txtPagAntBloqueto 
         ForeColor       =   &H00800000&
         Height          =   315
         Left            =   1440
         MaxLength       =   9
         TabIndex        =   10
         ToolTipText     =   "N�mero de bloqueto do pagamento antecipado."
         Top             =   675
         Width           =   1000
      End
      Begin VB.ComboBox cboBancoBoleto 
         ForeColor       =   &H00800000&
         Height          =   315
         Left            =   1425
         Sorted          =   -1  'True
         Style           =   2  'Dropdown List
         TabIndex        =   8
         ToolTipText     =   "Banco da conta de d�bito."
         Top             =   300
         Width           =   3500
      End
      Begin VB.Label lblX 
         Alignment       =   1  'Right Justify
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Bloqueto: "
         ForeColor       =   &H00800000&
         Height          =   315
         Index           =   26
         Left            =   120
         TabIndex        =   12
         ToolTipText     =   "N�mero de bloqueto do pagamento antecipado."
         Top             =   660
         Width           =   1305
      End
      Begin VB.Label lblX 
         Alignment       =   1  'Right Justify
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Banco: "
         ForeColor       =   &H00800000&
         Height          =   315
         Index           =   3
         Left            =   120
         TabIndex        =   9
         ToolTipText     =   "Banco da conta de d�bito."
         Top             =   300
         Width           =   1305
      End
   End
   Begin VB.Frame fraDadosDaConta 
      Caption         =   "Dados da Conta:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1515
      Left            =   60
      TabIndex        =   0
      Top             =   60
      Width           =   5055
      Begin VB.TextBox txtDebConta 
         ForeColor       =   &H00800000&
         Height          =   285
         Left            =   1425
         MaxLength       =   9
         TabIndex        =   4
         Tag             =   "1"
         ToolTipText     =   "N�mero da conta corrente para d�bito."
         Top             =   1095
         Width           =   1200
      End
      Begin VB.TextBox txtDebAgencia 
         ForeColor       =   &H00800000&
         Height          =   285
         Left            =   1425
         MaxLength       =   4
         TabIndex        =   3
         Tag             =   "1"
         ToolTipText     =   "Ag�ncia da conta de d�bito."
         Top             =   705
         Width           =   800
      End
      Begin VB.ComboBox cboDebBanco 
         ForeColor       =   &H00800000&
         Height          =   315
         Left            =   1425
         Sorted          =   -1  'True
         Style           =   2  'Dropdown List
         TabIndex        =   2
         ToolTipText     =   "Banco da conta de d�bito."
         Top             =   300
         Width           =   3500
      End
      Begin VB.Label lblX 
         Alignment       =   1  'Right Justify
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Conta corrente: "
         ForeColor       =   &H00800000&
         Height          =   285
         Index           =   2
         Left            =   120
         TabIndex        =   7
         ToolTipText     =   "N�mero da conta corrente para d�bito."
         Top             =   1095
         Width           =   1305
      End
      Begin VB.Label lblX 
         Alignment       =   1  'Right Justify
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Ag�ncia: "
         ForeColor       =   &H00800000&
         Height          =   285
         Index           =   1
         Left            =   120
         TabIndex        =   6
         ToolTipText     =   "Ag�ncia da conta de d�bito."
         Top             =   705
         Width           =   1305
      End
      Begin VB.Label lblX 
         Alignment       =   1  'Right Justify
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Banco: "
         ForeColor       =   &H00800000&
         Height          =   315
         Index           =   0
         Left            =   120
         TabIndex        =   5
         ToolTipText     =   "Banco da conta de d�bito."
         Top             =   300
         Width           =   1305
      End
   End
   Begin Threed.SSCommand cmdOk 
      Cancel          =   -1  'True
      Height          =   300
      Left            =   2093
      TabIndex        =   11
      ToolTipText     =   "Volta � proposta."
      Top             =   2880
      Width           =   1005
      _Version        =   65536
      _ExtentX        =   1773
      _ExtentY        =   529
      _StockProps     =   78
      Caption         =   "&Ok"
      ForeColor       =   8388608
   End
End
Attribute VB_Name = "frmT46V185A"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cboDebBanco_Click()
    Dim lAuxiliar As String    'Auxiliar.
    Dim lCodBanco As String    'C�digo do banco.
    Dim lMensagem As String    'Mensagem.
    Dim lTamAgencia As Byte     'Tamanho do campo de ag�ncia.
    Dim lTamConta As Byte   'Tamanho do campo de conta.

'1. Habilita salvar.
    If gM46V999.PerfilAcesso <> e_Perfil_Triagem Then
        Call gpHabSalvar
    End If

    '2. Posiciona c�digo do banco.
    With cboDebBanco
        If .ListIndex = -1 Then
            lCodBanco = "000"
        Else
            lCodBanco = Left$(.Text, 3)
        End If
    End With

    '3. Posiciona e verifica campos de ag�ncia e conta.
    Select Case lCodBanco
    Case "001"    'Projeto 11080 - Debito automatico - Banco do Brasil
        lTamAgencia = 6
        lTamConta = 10
    Case "237"      'Bradesco.
        lTamAgencia = 6
        lTamConta = 9
    Case "409"      'Unibanco.
        lTamAgencia = 4
        lTamConta = 8
    Case "341"      'Ita�.
        lTamAgencia = 4
        lTamConta = 7
    Case "347"      'Sudameris.
        lTamAgencia = 4
        lTamConta = 11
    Case "479"      'Boston.
        lTamAgencia = 3
        lTamConta = 9
    Case "356"      'Real.
        lTamAgencia = 4
        lTamConta = 11
    Case "399"      'HSBC
        lTamAgencia = 4
        lTamConta = 12
    Case "033", "33"
        lTamAgencia = 4
        lTamConta = 10
    Case "047", "47"
        lTamAgencia = 4
        lTamConta = 10
    Case "756" 'BANCOB
        lTamAgencia = 4
        lTamConta = 10
    Case Else       'Outros bancos.
        lTamAgencia = 4
        lTamConta = 9
    End Select
    If gM46V999.gfPreenchido(txtDebAgencia.Text) Then
        If Len(Trim(txtDebAgencia.Text)) > lTamAgencia Then
            txtDebAgencia.Text = Left$(Trim(txtDebAgencia.Text), lTamAgencia)
        End If
        txtDebAgencia.MaxLength = lTamAgencia
        If gfVerAgencia(1, lCodBanco, txtDebAgencia.Text, lAuxiliar, lMensagem) = False Then
            Call gM46V999.gpGraLog(1, lMensagem)
        Else
            If txtDebAgencia.Text <> lAuxiliar Then
                txtDebAgencia.Text = lAuxiliar
            End If
        End If
    Else
        txtDebAgencia.MaxLength = lTamAgencia
    End If
    If gM46V999.gfPreenchido(txtDebConta.Text) Then
        If Len(Trim(txtDebConta.Text)) > lTamConta Then
            txtDebConta.Text = Left$(Trim(txtDebConta.Text), lTamConta)
        End If
        txtDebConta.MaxLength = lTamConta
        If gfVerConta(1, lCodBanco, txtDebConta.Text, lAuxiliar, lMensagem) = False Then
            Call gM46V999.gpGraLog(1, lMensagem)
        Else
            If txtDebConta.Text <> lAuxiliar Then
                txtDebConta.Text = lAuxiliar
            End If
        End If
    Else
        txtDebConta.MaxLength = lTamConta
    End If
End Sub

Private Sub cboDebBanco_KeyPress(KeyAscii As Integer)
    If KeyAscii = vbKeyReturn Then
        'KeyAscii = 0
        SendKeys "{TAB}"
    End If
End Sub

Private Sub cboBancoBoleto_KeyPress(KeyAscii As Integer)
    If KeyAscii = vbKeyReturn Then
        'KeyAscii = 0
        SendKeys "{TAB}"
    End If
End Sub

Private Sub cboDebBanco_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyBack Then     'Teclou backspace.
        cboDebBanco.ListIndex = -1
    End If
End Sub

Private Sub cboBancoBoleto_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = vbKeyBack Then     'Teclou backspace.
        cboBancoBoleto.ListIndex = -1
    End If
End Sub

Private Sub cmdOk_Click()
    Dim clsA46V102 As clsA46V102A      'DLL : consiste dados comuns (n�vel 2).
    Dim lMensagem As String
    Dim lValida As Boolean

    '1001180 - Valida��o de DV na Triagem
    If gM46V999.PerfilAcesso = e_Perfil_Triagem Then
        Set clsA46V102 = New clsA46V102A    'DLL : consiste dados comuns (n�vel 2).
        Set clsA46V102.M46V999 = gM46V999

        With clsA46V102
            .Pro_IndBanco = cboDebBanco.ItemData(cboDebBanco.ListIndex)
            .Pro_IndBanco = cboDebBanco.ItemData(cboBancoBoleto.ListIndex)
            .Pro_IndAgencia = val(Replace(Replace(txtDebAgencia.Text, "X", "0"), "-", ""))
            .Pro_IndConta = val(Replace(Replace(UCase(txtDebConta.Text), "X", "0"), "-", ""))
            lValida = .mfVerConta(1, cboDebBanco.ItemData(cboDebBanco.ListIndex), val(Replace(txtDebAgencia.Text, "-", "")), val(Replace(txtDebConta.Text, "-", "")), lMensagem)
            If (lValida = True) And (lMensagem = "") Then
                Me.Hide
            Else
                MsgBox lMensagem, vbCritical, "Aten��o"
            End If
        End With
        Set clsA46V102 = Nothing
    Else
        Me.Hide
    End If
End Sub

Private Sub Form_Activate()
    Call Carregar_cboDebBanco

    If gM46V999.PerfilAcesso <> e_Perfil_Triagem Then
        frmT46V100A.panForm.Caption = Mid$(Me.Name, 4)
    End If

    If cboDebBanco.Visible = True And cboDebBanco.Enabled = True Then
        cboDebBanco.SetFocus
    End If
Finalizar:
    If gM46V999.gDesabilitarForms Then
        If Me.Tag <> "Desabilitado" Then
            DesabilitaControles Me
            cmdOk.Enabled = True
        End If
    Else
        If Me.Tag = "Desabilitado" Then
            HabilitaControles Me
        End If
    End If

End Sub
Public Sub mpInstanciarForm(pTipoPagamento As Integer)

    If gM46V999.PerfilAcesso = e_Perfil_Triagem Then
        Me.Show vbModal, frmT46V012A
    Else
        Me.Show vbModal, frmT46V102A
    End If

End Sub

Private Sub Carregar_cboDebBanco()
    Dim lMensagem As String    'Mensagem.
    Dim lCpfCnpj As String
    Dim lDatEmiss As Long
    Dim lOpcao As Byte
    Dim lCDebSel As Integer

    '2. Carrega combos de bancos.
    With frmT46V101A
        If .objstcPedLoc.Tip_Emissao <= 200 Then
            lDatEmiss = 0
        Else
            lDatEmiss = .objstcPedido.gStcPedidoApolice.Dat_Emis
        End If
        
        '[Verifica se PF/PJ]
        If frmT46V102A.optTipPessoa(0).Value = True Then    '[Pessoa f�sica]
            Call gM46V999.gpForCPF(2, frmT46V102A.txtCPF.Text, lCpfCnpj)
        Else
            Call gM46V999.gpForCNPJ(2, frmT46V102A.txtCNPJ.Text, lCpfCnpj)
        End If
        
        If gM46V999.mfObtemBancoBoleto(.objstcPedLoc.Tip_Emissao, _
                                       lCpfCnpj, _
                                       .objstcPedido.Cod_Produto, _
                                       .objstcPedido.Cod_Segurado, _
                                       .objstcPedido.Num_Apol, _
                                       gM46V999.CDblx(frmT46V102A.txtCorretor(1).Tag), _
                                       lDatEmiss) Then
            lOpcao = 5
        Else
            lOpcao = 3
        End If
    End With
    
    lCDebSel = cboDebBanco.ListIndex
    If gfCarCboBancos(lOpcao, cboDebBanco, lMensagem) = False Then
        Call gM46V999.gpGraLog(2, lMensagem)
        Exit Sub
    End If
    cboDebBanco.ListIndex = lCDebSel
End Sub

Private Sub Form_Load()
    Dim lMensagem As String    'Mensagem.
    Dim lDatEmiss As Long
    Dim i As Integer
    Dim lTentativa As Integer
    
    lTentativa = 5 'Maximo de tentativas
    
'1. Centraliza form.
    Call gM46V999.gpCenForm(Me)

    If gfCarCboBancos(2, cboBancoBoleto, lMensagem, frmT46V101A.objstcPedido.objstcCtrlEmis.Cod_Corr) = False Then
        Call gM46V999.gpGraLog(2, lMensagem)
        Exit Sub
    End If

    Call Carregar_cboDebBanco
    
'Boleto Santander
ConsultaSegregacao:
    For i = 0 To cboBancoBoleto.ListCount - 1
        '2016-08-22: Alterar Itau p Santander
        If frmT46V101A.objstcPedido.objstcCtrlEmis.Cod_Corr = 15701 Then 'mercedes
            If cboBancoBoleto.ItemData(i) = 33 Then
                cboBancoBoleto.ListIndex = i
                Exit For
            End If
        Else
            If cboBancoBoleto.ItemData(i) = frmT46V101A.objstcPedido.Cod_Bco_Cobr Then
                cboBancoBoleto.ListIndex = i
                cboBancoBoleto.Enabled = False
                Exit For
            End If
        End If
        '2016-08-22
    Next i
    
    lDatEmiss = 0
    If cboBancoBoleto.ListIndex = -1 Then
        With frmT46V101A
            
            If .objstcPedLoc.Tip_Emissao <= 200 Then
                lDatEmiss = 0
            Else
                gM46V999.gNum_Apolice = .objstcPedido.Num_Apol_An
                lDatEmiss = gM46V999.gDataEmis_Apol
            End If
        
            If Left(.objstcPedido.objstcCtrlEmis.Num_Bloq, 1) <> 5 Then
                gM46V999.gCod_Ramo = .objstcPedido.Cod_Ramo
                .objstcPedido.Cod_Bco_Cobr = gM46V999.gObtemBoletoSegregacao(.objstcPedLoc.Tip_Emissao, _
                                                                            .objstcPedido.Num_Cgc_Cpf, _
                                                                            .objstcPedido.Cod_Produto, _
                                                                            .objstcPedido.Cod_Segurado, _
                                                                            .objstcPedido.Num_Apol_An, _
                                                                            .objstcPedido.objstcCtrlEmis.Cod_Corr, _
                                                                            lDatEmiss, .objstcPedido.Cod_Tip_Doc)
            End If
            
            If .objstcPedido.Cod_Bco_Cobr <> 0 And lTentativa > 0 Then
                lTentativa = lTentativa - 1
                GoTo ConsultaSegregacao
            End If
            
        End With
    End If
End Sub
Private Sub txtDebAgencia_Change()
    If gM46V999.PerfilAcesso <> e_Perfil_Triagem Then
        Call gpHabSalvar
    End If
End Sub
Private Sub txtDebAgencia_GotFocus()
    With txtDebAgencia
        .SelStart = 0
        .SelLength = .MaxLength
    End With
End Sub
Private Sub txtDebAgencia_KeyPress(KeyAscii As Integer)
    If KeyAscii = vbKeyReturn Then
        KeyAscii = 0
        SendKeys "{TAB}"
    End If
End Sub
Private Sub txtDebAgencia_LostFocus()
    Dim lAuxiliar As String    'Auxiliar.
    Dim lCodBanco As String    'C�digo do banco.
    Dim lMensagem As String    'Mensagem.

    If gM46V999.gfPreenchido(txtDebAgencia.Text) Then
        With cboDebBanco
            If .ListIndex = -1 Then
                lCodBanco = "000"
            Else
                lCodBanco = Left$(.Text, 3)
            End If
        End With
        If gfVerAgencia(1, lCodBanco, txtDebAgencia.Text, lAuxiliar, lMensagem) = False Then
            Call gM46V999.gpGraLog(1, lMensagem)
            txtDebAgencia.Text = ""
            Exit Sub
        End If
        If txtDebAgencia.Text <> lAuxiliar Then
            txtDebAgencia.Text = lAuxiliar
        End If
    End If
End Sub
Private Sub txtDebConta_Change()
    If gM46V999.PerfilAcesso <> e_Perfil_Triagem Then
        Call gpHabSalvar
    End If
End Sub
Private Sub txtDebConta_GotFocus()
    With txtDebConta
        .SelStart = 0
        .SelLength = .MaxLength
    End With
End Sub
Private Sub txtDebConta_KeyPress(KeyAscii As Integer)
    If KeyAscii = vbKeyReturn Then
        KeyAscii = 0
        SendKeys "{TAB}"
    End If
End Sub
Private Sub txtDebConta_LostFocus()
    Dim lAuxiliar As String    'Auxiliar.
    Dim lCodBanco As String    'C�digo do banco.
    Dim lMensagem As String    'Mensagem.

    If gM46V999.gfPreenchido(txtDebConta.Text) Then
        With cboDebBanco
            If .ListIndex = -1 Then
                lCodBanco = "000"
            Else
                lCodBanco = Left$(.Text, 3)
            End If
        End With
        If gfVerConta(1, lCodBanco, txtDebConta.Text, lAuxiliar, lMensagem) = False Then
            Call gM46V999.gpGraLog(1, lMensagem)
            Exit Sub
        End If
        If txtDebConta.Text <> lAuxiliar Then
            txtDebConta.Text = lAuxiliar
        End If
    End If
End Sub
Private Sub txtPagAntBloqueto_GotFocus()
    With txtPagAntBloqueto
        .SelStart = 0
        .SelLength = .MaxLength
    End With
End Sub
Private Sub txtPagAntBloqueto_KeyPress(KeyAscii As Integer)
    If KeyAscii = vbKeyReturn Then
        KeyAscii = 0
        SendKeys "{TAB}"
    End If
End Sub
Private Sub txtPagAntBloqueto_LostFocus()
    Dim lAuxiliar As String     'Auxiliar.

    With txtPagAntBloqueto
        If gM46V999.gfPreenchido(.Text) Then
            .Text = Trim$(.Text)
            If Len(.Text) = 9 Then
                Exit Sub
            End If
            If IsNumeric(.Text) Then
                lAuxiliar = Format$(CDbl(.Text), "00000000")
                .Text = Mid$(lAuxiliar, 1, 7) & "-" & Mid$(lAuxiliar, 8, 1)
            End If
        End If
    End With
End Sub
