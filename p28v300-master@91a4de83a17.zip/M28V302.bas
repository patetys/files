Attribute VB_Name = "basM28V302"
Option Explicit
Private mArqsVig            As String       'lista dos arquivos vigentes
Private mSubStrUltLog       As String       'Substrisg ref. ao ultimo log enviado
Private mDataNovoLog        As String       'Data de envio do SYASINFO.log
Private mFlagPrior          As Boolean      'Variavel logica que verifica se a solicita��o
                                            'de atualiza��o � prioridade ou conex�o normal
Public Sub mpProcessa006()
'Procesure Utilizada para processar arquivos recebidos com exten��o 006
'Contendo informa��es sobre vers�o dos programas utilizados pelo usuario
    Dim bdSyasEmis      As ADODB.Connection
    Dim rsEAPDB         As ADODB.Recordset
    Dim lBusca          As String   'Busca do arquivo de entrada.
    Dim lDir            As String   'Resultado da fun��o DIR.
    Dim lEndSYASINFO    As String   'Endere�o do arquivo de entrada.
    Dim lNumSYASINFO    As String   '
    Dim lMensagem       As String   'Mensagem.
    Dim lArqEntrada     As String   'Arquivo que esta sendo processado
    Dim lCodUsuario     As String   'C�digo do Usu�rio de transmiss�o
    Dim lDadosSYASINFO  As String   'Conte�do do arquivo SYASINFO.LOG que esta sendo processado
    Dim lRegistro       As String   'Registro da leitura de arquivo

    '1. Posiciona crit�rio de busca do arquivo.
    lBusca = gAppPath & "*.006"
    '2. Obt�m arquivo de entrada.
    lDir = Dir(lBusca)
    If Not gfPreenchido(lDir) Then
        Exit Sub
    End If
    '3. Abre base de dados SQL-Server.
    If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
                   "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
        Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    '4. Processa arquivo de entrada
    Do
        'a) Obtem o Nome do arquivo e Codigo do Usu�rio
        lArqEntrada = Trim$(lDir)
        lCodUsuario = Left$(lArqEntrada, 6)
        'b)Inicia a variavel mFlagPrior
        If Mid(lArqEntrada, 7, 2) = "YY" Then
            'Conex�o tradicional
            mFlagPrior = False
        Else
            'Redundantemente verifica se o digito do nome do arquivo
            '� numerico
            If IsNumeric(Mid(lArqEntrada, 7, 2)) = True Then
                'Iniciou conex�o atraves de compara��o SYASINFO.LOG
                mFlagPrior = True
            Else
                mFlagPrior = False
            End If
        End If
        
        If Len(lArqEntrada) > 12 Then
            lArqEntrada = Left$(lArqEntrada, 12)
        Else
            While Len(lArqEntrada) < 12
                lArqEntrada = lArqEntrada & " "
            Wend
        End If
        'c)Obtem caminho do arquivo processado
        lEndSYASINFO = gAppPath & lArqEntrada
        'd) Obtem as informa��es contidas no arquivo
        lNumSYASINFO = FreeFile
        'Inicia a vair�vel
        lDadosSYASINFO = Empty
        On Error Resume Next
        Open lEndSYASINFO For Input Access Read As #lNumSYASINFO
            If Err <> 0 Then
                Call gpGraLog(1, "FTE0026 - Erro ao abrir arquivo " & lEndSYASINFO & ": " & Err & _
                                 " - " & Error & vbLf & vbLf & "O sistema ser� encerrado.")
                End
            Else
                Do While Not EOF(lNumSYASINFO)
                    Line Input #lNumSYASINFO, lRegistro
                    If gfPreenchido(lRegistro) = True Then
                        'Armazena os registros do arquivo
                        'separando por ";"
                        lDadosSYASINFO = lDadosSYASINFO & _
                                        IIf(lDadosSYASINFO = "", "", ";")
                        lDadosSYASINFO = lDadosSYASINFO & lRegistro
                    Else
                        Exit Do
                    End If
                Loop
        Close #lNumSYASINFO
            End If
        'e) Exclui arquivo de entrada.
        Kill lEndSYASINFO
        'f) Atualiza os dados do usuario na tabela YTAB_SyasInfo_Log
        Call mpAtualizaYTAB_SYASINFO(lCodUsuario, lDadosSYASINFO)
        'g)Obtem lista de arquivos vigentes e inicia compara��o/disponibiliza��o de atualiza��es
        If mfObtemListaArqVig(mArqsVig) = True Then
            Call mpComparaArqs(lCodUsuario, lDadosSYASINFO, mArqsVig)
        End If
'h) Marca o arquivo como recebido
            'Call mpMarcaRecebido(lArqEntrada)
        'h) Verifica se tem outro arquivo de entrada a processar.
        lDir = Dir(lBusca)
        If Not gfPreenchido(lDir) Then
            Call gpFecha2(bdSyasEmis)
            Exit Sub
        End If
    Loop
End Sub
Private Sub mpAtualizaYTAB_SYASINFO(ByVal lCodUser As String, ByVal lDados As String)
'Procedure criada para atualizar a Base EAPDB com as informa��es do obtidas
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o
                            'lDados:........String contendo todos os registros obtidos
    Dim bdSyasEmis      As ADODB.Connection
    Dim rsEAPDB         As ADODB.Recordset
    Dim lSplitDados()       As String   'String utilizada para dividir as informa��es da vari�vel lDados
    Dim lSplitRegistro()    As String   'String Utilizada para dividir informa��es
    Dim lCont               As Integer  'Contador
    Dim lContAux            As Integer  'Contador Auxiliar
    Dim lReferencia         As String   'Referencia (YTAB_SYASINFO_LOG)
    Dim lStrComparacao      As String   'StrCompara��o (YTAB_SYASINFO_LOG)
    Dim lMensagem           As String   'Mensagem
    
    If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
                   "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
        Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    
    '1. Obtem data do ultimo log enviado
    gSelect = "SELECT [StrComparacao] FROM [EAPDB].[yasuser].[YTAB_SYASINFO_LOG] "
    gSelect = gSelect & "WHERE [usuarioSYAS] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [Referencia] = 'DATALOG'"
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
       Call gpGraLog(1, lMensagem)
       Exit Sub
    End If
    
    If rsEAPDB.EOF = False Then
        mSubStrUltLog = rsEAPDB![StrComparacao]
    End If
    
    '2. Exclui informa��es anteriores (Mantendo Historico de Instala��o)
    'monta instru��o DELETE
    gDelete = "DELETE FROM [EAPDB].[yasuser].[YTAB_SYASINFO_LOG] "
    gDelete = gDelete & "WHERE [usuarioSYAS] = '" & lCodUser & "' "
    gDelete = gDelete & "AND [Referencia] <> 'Instala1'"
    If gfExeSQL(bdSyasEmis, gDelete, lMensagem) <> 0 Then
       Call gpGraLog(1, lMensagem)
       Exit Sub
    End If
    '3. Carrega base com novas informa��es
    lSplitDados = Split(lDados, ";")
    If UBound(lSplitDados()) > -1 Then
        For lCont = 0 To UBound(lSplitDados())
            lSplitRegistro = Split(lSplitDados(lCont), "$")
            If UBound(lSplitRegistro()) >= 1 Then
                'Somente se existir informa��o
                lReferencia = lSplitRegistro(0)
                lStrComparacao = lSplitRegistro(1)
                'Monta instru��o INSERT
                gInsert = "INSERT INTO [EAPDB].[yasuser].[YTAB_SYASINFO_LOG] "
                gInsert = gInsert & "([usuarioSYAS], [Referencia], [StrComparacao]) "
                gInsert = gInsert & "VALUES('" & lCodUser & "','" & lReferencia & "','"
                gInsert = gInsert & lStrComparacao & "')"
                'Insere registro
                On Error Resume Next
                If gfExeSQL(bdSyasEmis, gInsert, lMensagem) <> 0 Then
                   'Continua, pode ocorrer erro ao tentar registrar
                   'historico de instala��o ( caso n�o seja novo )
                End If
                On Error GoTo 0
            End If
        Next lCont
    Else
        Exit Sub
    End If
End Sub
Private Function mfObtemListaArqVig(ByRef lListaArqs As String) As Boolean
'Procedure criada para obter a lista dos arquivos vigentes, pa serem utilizados na compara��o
    'Parametros de Saida    lListaArqs:....Lista de arquivos vigentes
Dim bdSyasEmis      As ADODB.Connection
Dim rsEAPDB         As ADODB.Recordset
Dim lMensagem       As String

    If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
                   "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
        Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        mfObtemListaArqVig = False
        Exit Function
    End If

    gSelect = "SELECT [arquivo], [StrComparacao], [atualizacao], [prioridade]"
    gSelect = gSelect & "From [EAPDB].[yasuser].[YTAB_Arqs_Vig] "
    gSelect = gSelect & "ORDER BY [prioridade] DESC"
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        mfObtemListaArqVig = False
        Exit Function
    End If
    
    If rsEAPDB.EOF <> True Then
        While Not rsEAPDB.EOF
            lListaArqs = lListaArqs & IIf(gfPreenchido(lListaArqs) = False, "", ";")
            lListaArqs = lListaArqs & rsEAPDB![Arquivo] & "$" & _
                         rsEAPDB![StrComparacao] & "$" & _
                         rsEAPDB![atualizacao] & "$" & _
                         rsEAPDB![prioridade]
                         
            rsEAPDB.MoveNext
        Wend
    End If
    If gfPreenchido(lListaArqs) = True Then
        mfObtemListaArqVig = True
    Else
        mfObtemListaArqVig = False
    End If
End Function
Private Sub mpComparaArqs(ByVal lCodUser As String, ByVal lDadosUser As String, _
                          ByVal lDadosVig As String)
'Procedure criada para atualizar a Base EAPDB com as informa��es do obtidas
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o
                            'lDadosUser:........String contendo todos os registros obtidos
                            'lDadosVig:.........String contendo todos os registros dos arquivos Vigentes
    Dim lSDadosUser()       As String   'String utilizada para dividir as informa��es da vari�vel lDadosUser
    Dim lSRegUser()         As String   'String Utilizada para dividir informa��es da vari�vel lDadosUser
    Dim lSDadosVig()        As String   'String utilizada para dividir as informa��es da vari�vel lDadosUser
    Dim lSRegVig()          As String   'String Utilizada para dividir informa��es da vari�vel lDadosUser
    Dim lCont               As Integer  'Contador
    Dim lContAux            As Integer  'Contador Auxiliar
    Dim lCurArqAtua         As String   'Atualiza��o que ref. ao arquivo que esta sendo verificado
    Dim lFlagCurArqAtua     As Boolean  'True = Processa continua processo , FALSE = N�o cosiderar processo
    Dim lFlagEncontrado     As Boolean  'True = Arquivo encontrado na lista do Usuario ( n�o processar novamente)
                                        'False = Arquivo n�o encontrado ( incluir atualiza��o )


    lSDadosUser = Split(lDadosUser, ";")
    lSDadosVig = Split(lDadosVig, ";")
'1 Verifica se as informa��es s�o de usuarios REDE (Possui Processo 5 cadastrado)
'Caso contrario encerra o procedimento
    If UBound(lSDadosUser()) > -1 Then
        For lCont = 0 To UBound(lSDadosUser())
            lSRegUser = Split(lSDadosUser(lCont), "$")
            If UBound(lSRegUser()) >= 1 Then
                If Trim(UCase(lSRegUser(0))) = "USUARIO" Then
                   If Trim(UCase(lSRegUser(1))) <> "REDE" Then
                        gArqEst = gArqEst + 1
                        Exit Sub
                   Else
                        gArqSer = gArqSer + 1
                        
                        Exit For
                   End If
                End If
            End If
        Next lCont
    Else
        Exit Sub
    End If
''2 Verifica se o novo Log foi gerado pelo meno 2 minutos
''depois do ultimo informado
    If Len(Trim(mSubStrUltLog)) >= 19 Then
        For lCont = 0 To UBound(lSDadosUser())
            lSRegUser = Split(lSDadosUser(lCont), "$")
            If UBound(lSRegUser()) >= 1 Then
                If Trim(UCase(lSRegUser(0))) = "DATALOG" Then
                    'Guarda data do novo Log na variavel
                     mDataNovoLog = lSRegUser(1)
'                     If Mid(mSubStrUltLog, 1, 15) = Mid(lSRegUser(1), 1, 15) Then
'                        If Val(Mid(mSubStrUltLog, 16, 1) + 2) >= Val(Mid(lSRegUser(1), 16, 1)) Then
'                            'o log foi reenviado a menos de 2 minutos
'                                Exit Sub
'                        End If
'                     End If
                    Exit For
                End If
            End If
        Next lCont
    End If
      
'3-Disponibiliza SYASINFO.LOG (SYAS1106.003)
    Call mpDispSYASINFO(lCodUser)
    
'4- Faz a compara��o
    ' A partir de cada informa��o dos arquivos vigentes,
    ' Procura o correnpondente na lista dos arquivos do usuario e faz a compara��o
    'lSRegVig(0)..........[arquivo]
    'lSRegVig(1)..........[StrComparacao]
    'lSRegVig(2)..........[atualizacao]
    'lSRegVig(3)..........[prioridade]
    If UBound(lSDadosVig()) > -1 Then
        For lCont = 0 To UBound(lSDadosVig())
            lSRegVig = Split(lSDadosVig(lCont), "$")
            If UBound(lSRegVig()) >= 3 Then
                If UBound(lSDadosUser()) > -1 Then
                    'Inicializa a vari�vel
                    lFlagEncontrado = False
                    If lCurArqAtua <> lSRegVig(2) Then
                        lCurArqAtua = lSRegVig(2)
                        lFlagCurArqAtua = True
                    End If
                    For lContAux = 0 To UBound(lSDadosUser())
                        lSRegUser = Split(lSDadosUser(lContAux), "$")
                        If UBound(lSRegUser()) >= 1 Then
                            If Trim(UCase(lSRegVig(0))) = Trim(UCase(lSRegUser(0))) Then
                                If Trim(UCase(lSRegVig(1))) = Trim(UCase(lSRegUser(1))) Then
                                'n�o encontrou divergencia, remove atualiza��o n�o recebida
                                    If lFlagCurArqAtua = True Then
                                        'N�o executa a linha abaixo caso o arquivo
                                        'tenha sido dispodibilizado por este processo
                                        Call mpExcluiAtualizacao(lCodUser, lSRegVig(2))
                                    End If
                                    lFlagEncontrado = True
                                Else
                                    If Trim(UCase(lSRegVig(2))) = "SYAS1200.003" Or _
                                       Trim(UCase(lSRegVig(2))) = "SYAS9800.003" Then
                                        ''Trata-se de arquivo com String de compara��o sobre a vers�o tarifaria
                                        If Val(Trim(UCase(lSRegVig(1)))) < Val(Trim(UCase(lSRegUser(1)))) Then
                                            'Vers�o mais recente que o atual n�o disponibiliza atualiza��o
                                        Else
                                            'Encontrou Divergencia
                                            If mFlagPrior = True Then
                                                'inclui atualiza��o ignorando a regra de prioridade
                                                 Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                                                 lFlagCurArqAtua = False
                                            Else
                                                If mfVerificaPrioridade(lCodUser, lSRegVig(3), lSRegVig(2)) = True Then
                                                    'inclui atualiza��o
                                                    Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                                                    lFlagCurArqAtua = False
                                                End If
                                             End If
                                        End If
                                    Else
                                        'Trata-se de arquivo com String de compara��o data
                                        If IsDate(Mid(Trim(UCase(lSRegUser(1))), 1, 10)) = True Then
                                            If CDate(Mid(Trim(UCase(lSRegVig(1))), 1, 10)) < CDate(Mid(Trim(UCase(lSRegUser(1))), 1, 10)) Then
                                                'Arquivo mais recente que o atual n�o disponibiliza atualiza��o
                                            Else
                                                'Encontrou divergencia
                                                If mFlagPrior = True Then
                                                    'inclui atualiza��o ignorando a regra de prioridade
                                                     Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                                                     lFlagCurArqAtua = False
                                                Else
                                                    If mfVerificaPrioridade(lCodUser, lSRegVig(3), lSRegVig(2)) = True Then
                                                        'inclui atualiza��o
                                                        Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                                                        lFlagCurArqAtua = False
                                                    End If
                                                End If
                                            End If
                                        Else
                                            'Encontrou divergencia
                                            'Vers�o indisponivel no log do usuario
                                            If mFlagPrior = True Then
                                                'inclui atualiza��o ignorando a regra de prioridade
                                                 Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                                                 lFlagCurArqAtua = False
                                            Else
                                                If mfVerificaPrioridade(lCodUser, lSRegVig(3), lSRegVig(2)) = True Then
                                                    'inclui atualiza��o
                                                    Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                                                    lFlagCurArqAtua = False
                                                End If
                                            End If
                                        End If
                                    End If
                                    lFlagEncontrado = True
                                End If
                                Exit For
                            End If
                        End If
                    Next lContAux
                Else
                    Exit Sub
                End If
            End If
            If lFlagEncontrado = False Then
                If mFlagPrior = True Then
                    'inclui atualiza��o ignorando a regra de prioridade
                     Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                     lFlagCurArqAtua = False
                Else
                    If mfVerificaPrioridade(lCodUser, lSRegVig(3), lSRegVig(2)) = True Then
                        'inclui atualiza��o
                        Call mpIncluiAtualizacao(lCodUser, lSRegVig(2))
                        lFlagCurArqAtua = False
                    End If
                End If
            End If
        Next lCont
    Else
        Exit Sub
    End If

End Sub

Private Function mfVerificaPrioridade(ByVal lCodUser As String, ByVal lPrioridade As Integer, ByVal lAtualizacao As String)
'Fun��o utilizada para verificar se o usuario n�o possui
'um arquivo n�o recebido de prioridade menor
'ao arquivo em quest�o.
'Tamb�m verifica se a atualiza��o correspondente foi recebida na "Hoje"
'Caso positivo, trata-se de uma informa��o enviada durante o recebimento da atualiza��o
' N�o disponibilizar novamente

Dim bdSyasEmis      As ADODB.Connection
Dim rsEAPDB         As ADODB.Recordset
Dim lMensagem       As String
    If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
                   "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
        Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        mfVerificaPrioridade = False
        Exit Function
    End If

'1 - Verifica se n�o existe arquivo com prioridade menor n�o recebido
    gSelect = "SELECT [snrf] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[mailbox] "
    gSelect = gSelect & "WHERE [receiver] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [status] = 1 "
    gSelect = gSelect & "AND [snrf] IN "
    gSelect = gSelect & "(SELECT DISTINCT [atualizacao] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[YTAB_Arqs_Vig] "
    gSelect = gSelect & "WHERE [prioridade] > " & lPrioridade & ")"
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        mfVerificaPrioridade = False
        Exit Function
    End If
    
    If rsEAPDB.EOF = True Then
        'N�o existe arquivos n�o recebidos
        mfVerificaPrioridade = True
    Else
        'Existem arquivos pendentes p/ recebimento
        mfVerificaPrioridade = False
        Exit Function
    End If
'2 - Veririca se a referida atualiza��o foi recebida na mesma data em que o Log esta sendo processado
    gSelect = "SELECT CONVERT(datetime,[last_extract_datetime],103) AS DataReceb "
    gSelect = gSelect & "From [EAPDB].[yasuser].[mailbox] "
    gSelect = gSelect & "WHERE [receiver] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [status] = 3 "
    gSelect = gSelect & "AND [snrf] IN "
    gSelect = gSelect & "(SELECT DISTINCT [atualizacao] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[YTAB_Arqs_Vig] "
    gSelect = gSelect & "WHERE [atualizacao] = '" & lAtualizacao & "')"
    
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        mfVerificaPrioridade = False
        Exit Function
    End If
    
    If rsEAPDB.EOF = True Then
        'Ainda n�o possui esta atualiza��o na lista de arquivos recebidos
        mfVerificaPrioridade = True
    Else
        If Format(rsEAPDB![DataReceb], "dd/mm/yyyy") = Format(mDataNovoLog, "dd/mm/yyyy") Then
            'Atualiza��o recebida na mesma data em que o LOG foi enviado
            mfVerificaPrioridade = False
        Else
            'O �ltimo recebimento desta atualiza��o foi diferente da data do Log
            mfVerificaPrioridade = True
        End If
    End If
    
End Function
Private Sub mpIncluiAtualizacao(ByVal lCodUser As String, ByVal lArqSYAS As String)
'Procedure criada para atualizar a Base EAPDB com as informa��es obtidas
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o
                            'lArqSYAS:......Nomo do arquivo de atualiza��o
Dim bdSyasEmis      As ADODB.Connection
Dim rsEAPDB         As ADODB.Recordset
Dim lMensagem       As String
Dim lTarifaInt      As Boolean  'True - Disponibiliza tarifa Interna.
                                'False -      "       tarifa corretor
Dim lRecFolder      As String   'Pasta onde o arquivo ser� recebido


If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
               "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
    Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
    Exit Sub
End If

'1 - Verifica se o usuario Recebe tarifa INTERNA
If lArqSYAS = "SYAS1200.003" Then  'TARIFA AUTO
    'inicia verifica��o do tpo de tarifa a disponibilizar
    gSelect = "SELECT  DISTINCT [user_name], [inscricao_estadual] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[FULL_FIELDS] "
    gSelect = gSelect & "WHERE [user_name] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [inscricao_estadual] IN ("
    gSelect = gSelect & "'0000001'"  'FILIAL
    'gSelect = gSelect & "'0308101'"    'VENTO NOVO
    gSelect = gSelect & ") "
    gSelect = gSelect & "AND [ADM] = 1 "
        
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If
    'Inicializa a variavel p/ evitar distribui��o incorreta
    lTarifaInt = False
    If rsEAPDB.EOF = False Then
        'Usuario encontrado na consulta
            'Recebe tarifa INterna
        lTarifaInt = True
    Else
        'N�o encontrou usuario na lista
            'Recebe tarifa Corretor
        lTarifaInt = False
    End If
Else
    'Inicializa a variavel p/ evitar distribui��o incorreta
    lTarifaInt = False
End If

'2 Busca Pasta onde o arquivo dever� ser recebido

    If lTarifaInt = True Then
        lRecFolder = lArqSYAS
    Else
        gSelect = "SELECT TOP 1 U.[user_name] as receiver_folder , "
        gSelect = gSelect & "ISNULL(P.[TotalPend], 0) As TotalPend "
        gSelect = gSelect & "FROM [EAPDB].[yasuser].[user] U "
        gSelect = gSelect & "LEFT JOIN [EAPDB].[yasuser].[Yview_AtuPendente] P "
        gSelect = gSelect & "ON U.[user_name] = P.[receiver_folder] "
        gSelect = gSelect & "WHERE U.[user_name] LIKE '" & Left(lArqSYAS, 8) & "%' "
        gSelect = gSelect & "ORDER BY P.[TotalPend] , U.[user_name]"
    
        If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
            Call gpGraLog(2, lMensagem)
            Exit Sub
        End If
        'Inicializa a variavel p/ evitar distribui��o incorreta
        
        If rsEAPDB.EOF = True Then
            'N�o encontrou pastas distribui p/ a pasta padr�o
            lRecFolder = lArqSYAS
        Else
            'distribui na pasta onde tem menos arquivos pendentes
            lRecFolder = rsEAPDB![receiver_folder]
        End If
    
    End If
    
      

'3- Monta os comandos SQL
gInsert = "INSERT INTO [EAPDB].[yasuser].[mailbox] "
gInsert = gInsert & "([filename], "
gInsert = gInsert & "[snrf],[aprf],[filesize], [receiver_folder], "
gInsert = gInsert & "[sender],[edifact], [extract_count], [status], "
gInsert = gInsert & "[id_user],[receiver], "
gInsert = gInsert & "[delivery_datetime] , [first_extract_datetime], [last_extract_datetime]) "
If lTarifaInt = True And lArqSYAS = "SYAS1200.003" Then
    'Tarifa Interna
    gInsert = gInsert & "(SELECT DISTINCT('SYAS1201.003.003'), "
    gInsert = gInsert & "'SYAS1201.003','003',0,'SYAS1201.003', "
Else
    'Tarifa Corretor
    gInsert = gInsert & "(SELECT DISTINCT([atualizacao])+ '.003', "
    gInsert = gInsert & "[atualizacao],'003',0, '" & lRecFolder & "', "
End If
gInsert = gInsert & "'YASUDA',0,0,1, "
gInsert = gInsert & "[id_user], [user_name], "
gInsert = gInsert & "[DataLancamento] , [DataLancamento], [DataLancamento] "
gInsert = gInsert & "From [EAPDB].[yasuser].[YVIEW_USER_PLUS_ArqsVig] "
gInsert = gInsert & "WHERE [user_name] = '" & lCodUser & "' "
gInsert = gInsert & "AND [atualizacao] = '" & lArqSYAS & "')"

gUpdate = "UPDATE [EAPDB].[yasuser].[mailbox] "
gUpdate = gUpdate & "SET "
gUpdate = gUpdate & "[filesize] = 0, "
gUpdate = gUpdate & "[status] = 1, "
If lTarifaInt = True And lArqSYAS = "SYAS1200.003" Then
    gUpdate = gUpdate & "[receiver_folder] = 'SYAS1201.003', "
Else
    gUpdate = gUpdate & "[receiver_folder] = '" & lRecFolder & "', "
End If
gUpdate = gUpdate & "[delivery_datetime] = "
gUpdate = gUpdate & "(SELECT DISTINCT([DataLancamento]) "
gUpdate = gUpdate & "From [EAPDB].[yasuser].[YVIEW_USER_PLUS_ArqsVig] "
gUpdate = gUpdate & "WHERE [user_name] = '" & lCodUser & "' "
gUpdate = gUpdate & "AND [atualizacao] = '" & lArqSYAS & "'), "
gUpdate = gUpdate & "[first_extract_datetime] = "
gUpdate = gUpdate & "(SELECT DISTINCT([DataLancamento]) "
gUpdate = gUpdate & "From [EAPDB].[yasuser].[YVIEW_USER_PLUS_ArqsVig] "
gUpdate = gUpdate & "WHERE [user_name] = '" & lCodUser & "' "
gUpdate = gUpdate & "AND [atualizacao] = '" & lArqSYAS & "'), "
gUpdate = gUpdate & "[last_extract_datetime] = "
gUpdate = gUpdate & "(SELECT DISTINCT([DataLancamento]) "
gUpdate = gUpdate & "From [EAPDB].[yasuser].[YVIEW_USER_PLUS_ArqsVig] "
gUpdate = gUpdate & "WHERE [user_name] = '" & lCodUser & "' "
gUpdate = gUpdate & "AND [atualizacao] = '" & lArqSYAS & "') "
gUpdate = gUpdate & "WHERE [receiver] = '" & lCodUser & "' "
If lTarifaInt = True Then
    'Tarifa Interna
    gUpdate = gUpdate & "AND [snrf] = 'SYAS1201.003'"
Else
    'Tarifa Corretor
    gUpdate = gUpdate & "AND [snrf] = '" & lArqSYAS & "'"
End If
'4- Verifica se o Usuario consta na View [YVIEW_USER_PLUS_ArqsVig]
'Caso contrario sai do procedimento.
    gSelect = "SELECT [atualizacao] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[YVIEW_USER_PLUS_ArqsVig] "
    gSelect = gSelect & "WHERE [user_name] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [atualizacao] = '" & lArqSYAS & "'"
        
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If
    
    If rsEAPDB.EOF = True Then
    'Usuario n�o possui processo 6 cadastrado
        Exit Sub
    End If
    
'5- verifica se o arquivo ja existe na lista de arquivos de atualiza��o
'do usu�rio, caso n�o exista insere o registro, caso contrario atualiza.
    gSelect = "SELECT [snrf] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[mailbox] "
    gSelect = gSelect & "WHERE [receiver] = '" & lCodUser & "' "
    If lTarifaInt = True Then
        'Tarifa Interna
        gSelect = gSelect & "AND [snrf] = 'SYAS1201.003'"
    Else
        'Tarifa Corretor ou algum outro pacote de atualiza��o
        gSelect = gSelect & "AND [snrf] = '" & lArqSYAS & "'"
    End If
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If
    
    If rsEAPDB.EOF = True Then
        'N�o existe o arquivos na lista do usuario
        If gfExeSQL(bdSyasEmis, gInsert, lMensagem) <> 0 Then
           Call gpGraLog(1, "SYASINFO " & lMensagem)
           Exit Sub
        End If
    Else
        'existe o arquivos na lista do usuario
        If gfExeSQL(bdSyasEmis, gUpdate, lMensagem) <> 0 Then
           Call gpGraLog(1, "SYASINFO " & lMensagem)
           Exit Sub
        End If
    End If
End Sub

Private Sub mpExcluiAtualizacao(ByVal lCodUser As String, ByVal lArqSYAS As String)
'Procedure criada para cancelar o envio de atualiza��o, caso o usuario tenha este arquivo pendente para recebimento
' e a informa��o obtida informa que  este ja esta atualizado
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o
                            'lDados:........String contendo todos os registros obtidos
Dim bdSyasEmis      As ADODB.Connection
Dim rsEAPDB         As ADODB.Recordset
Dim lMensagem       As String
'1- Monta os comandos SQL
gUpdate = "UPDATE [EAPDB].[yasuser].[mailbox] "
gUpdate = gUpdate & "SET "
gUpdate = gUpdate & "[status] = 3 "
gUpdate = gUpdate & "WHERE [receiver] = '" & lCodUser & "' "
gUpdate = gUpdate & "AND [snrf] = '" & lArqSYAS & "'"

'2- verifica se o arquivo do usuario esta pendente / recebimento
'caso afirmativo, cancela o envio
    If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
                   "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
        Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        Exit Sub
    End If
    gSelect = "SELECT [snrf] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[mailbox] "
    gSelect = gSelect & "WHERE [receiver] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [snrf] = '" & lArqSYAS & "'"
    gSelect = gSelect & "AND [status] = 1"
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If
    
    If rsEAPDB.EOF = True Then
        'N�o esta pendente
        Exit Sub
    Else
        'existe o arquivo esta pendente, ser� cancelado o envio
        If gfExeSQL(bdSyasEmis, gUpdate, lMensagem) <> 0 Then
           Call gpGraLog(1, "SYASINFO " & lMensagem)
           Exit Sub
        End If
    End If
End Sub

Private Sub mpMarcaRecebido(ByVal lArq006 As String)
'Procedure criada para atualizar a Base EAPDB com as informa��es do obtidas
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o
                            'lDados:........String contendo todos os registros obtidos
Dim bdSyasEmis      As ADODB.Connection
Dim lMensagem       As String

If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
               "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
    Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
    Exit Sub
End If

'1- Monta os comandos SQL

gUpdate = "Update [EAPDB].[yasuser].[mailbox] "
gUpdate = gUpdate & "SET [status] = 3, "
gUpdate = gUpdate & "[filesize] = 2, "
gUpdate = gUpdate & "[last_extract_datetime] = CURRENT_TIMESTAMP "
gUpdate = gUpdate & "WHERE [filename] like '" & lArq006 & "%'"
gUpdate = gUpdate & "and [status] = 1 "
gUpdate = gUpdate & "and [aprf] = '006' "
gUpdate = gUpdate & "and [filesize]= 0 "


'2- Executa atualiza�a� do registro
    If gfExeSQL(bdSyasEmis, gUpdate, lMensagem) <> 0 Then
       Call gpGraLog(1, "SYASINFO " & lMensagem)
       Exit Sub
    End If
    
End Sub
Private Sub mpDispSYASINFO(ByVal lCodUsuario As String)
'Procedure criada para obter a lista dos arquivos vigentes, pa serem utilizados na compara��o
    'Parametros de Saida    lListaArqs:....Lista de arquivos vigentes
Dim bdSyasEmis      As ADODB.Connection
Dim rsEAPDB         As ADODB.Recordset
Dim lMensagem       As String
Dim lStatus         As Byte

'1-  Abre a base de dados
    If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
                   "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
        Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        Exit Sub
    End If
    
'2- Obtem os dados
    gSelect = "SELECT [Status] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[YTAB_ParamProgramas] "
    gSelect = gSelect & "WHERE [Param] = 'SYASINFO'"
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If

    lStatus = 0
    
    If rsEAPDB.EOF = False Then
        lStatus = rsEAPDB![Status]
    End If
    Call gpFecha1(rsEAPDB)

'3- Disponibiliza o arquivo
    Select Case lStatus
        Case 0
            'N�o disponibiliza p/ nenhum corretor
            Exit Sub
        Case 1
            'Disponibiliza somente p/ correotres com prioridade
            gSelect = "SELECT DISTINCT [prior_atu_syas] "
            gSelect = gSelect & "From [EAPDB].[yasuser].[FULL_FIELDS] "
            gSelect = gSelect & "WHERE [user_name] = '" & lCodUsuario & "'"
            
            If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
                Call gpGraLog(2, lMensagem)
                Exit Sub
            End If
                        
            If rsEAPDB.EOF = False Then
                If rsEAPDB![prior_atu_syas] = 0 Then
                    'Sai da procedure usuario n�o tem prioridade
                    Exit Sub
                End If
            Else
                'Sai da procedure n�o localizado registro
                Exit Sub
            End If
            Call gpFecha1(rsEAPDB)
            
            'Disponibiliza a atualiza��o
            Call mpIncluiSYASINFO(lCodUsuario)
            
        Case 2
            'Disponibiliza p/ qualquer Usuario REDE
            Call mpIncluiSYASINFO(lCodUsuario)
    End Select
   
End Sub
Private Sub mpIncluiSYASINFO(ByVal lCodUser As String)
'Procedure criada para atualizar a Base EAPDB com o arquivo SYAS1106.003
    'Parametros de entrada  lCodUser:.......Codigo de usu�rio de transmiss�o

Dim bdSyasEmis      As ADODB.Connection
Dim rsEAPDB         As ADODB.Recordset
Dim lMensagem       As String
Dim lRecFolder      As String   'Pasta onde o arquivo ser� recebido


If gfAbrBasSQL("EAPDB", "2", "SP310110PSLUWEB", "EAPDB", "yasuser", _
               "User00.MsdeWeb", bdSyasEmis, lMensagem) = False Then
    Call gpGraLog(2, "SYASINFO - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
    Exit Sub
End If

'1 Busca Pasta onde o arquivo dever� ser recebido
    gSelect = "SELECT TOP 1 U.[user_name] as receiver_folder , "
    gSelect = gSelect & "ISNULL(P.[TotalPend], 0) As TotalPend "
    gSelect = gSelect & "FROM [EAPDB].[yasuser].[user] U "
    gSelect = gSelect & "LEFT JOIN [EAPDB].[yasuser].[Yview_AtuPendente] P "
    gSelect = gSelect & "ON U.[user_name] = P.[receiver_folder] "
    gSelect = gSelect & "WHERE U.[user_name] LIKE 'SYAS1106%' "
    gSelect = gSelect & "ORDER BY P.[TotalPend] , U.[user_name]"

    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If
    
    'Inicializa a variavel p/ evitar distribui��o incorreta
    If rsEAPDB.EOF = True Then
        'N�o encontrou pastas distribui p/ a pasta padr�o
        lRecFolder = "SYAS1106.003"
    Else
        'distribui na pasta onde tem menos arquivos pendentes
        lRecFolder = rsEAPDB![receiver_folder]
    End If
         
'2- Monta os comandos SQL
    gInsert = "INSERT INTO [EAPDB].[yasuser].[mailbox] "
    gInsert = gInsert & "([filename], "
    gInsert = gInsert & "[snrf],[aprf],[filesize], [receiver_folder], "
    gInsert = gInsert & "[sender],[edifact], [extract_count], [status], "
    gInsert = gInsert & "[id_user],[receiver], "
    gInsert = gInsert & "[delivery_datetime] , [first_extract_datetime], [last_extract_datetime]) "
    gInsert = gInsert & "(SELECT 'SYAS1106.003.003', "
    gInsert = gInsert & "'SYAS1106.003','003',0, '" & lRecFolder & "', "
    gInsert = gInsert & "'YASUDA',0,0,1, "
    gInsert = gInsert & "[id_user], [user_name], "
    gInsert = gInsert & "CURRENT_TIMESTAMP , CURRENT_TIMESTAMP, CURRENT_TIMESTAMP "
    gInsert = gInsert & "From [EAPDB].[yasuser].[user] "
    gInsert = gInsert & "WHERE [user_name] = '" & lCodUser & "') "

    gUpdate = "UPDATE [EAPDB].[yasuser].[mailbox] "
    gUpdate = gUpdate & "SET "
    gUpdate = gUpdate & "[filesize] = 0, "
    gUpdate = gUpdate & "[status] = 1, "
    gUpdate = gUpdate & "[receiver_folder] = '" & lRecFolder & "', "
    gUpdate = gUpdate & "[delivery_datetime] = CURRENT_TIMESTAMP, "
    gUpdate = gUpdate & "[first_extract_datetime] = CURRENT_TIMESTAMP, "
    gUpdate = gUpdate & "[last_extract_datetime] = CURRENT_TIMESTAMP "
    gUpdate = gUpdate & "WHERE [receiver] = '" & lCodUser & "' "
    gUpdate = gUpdate & "AND [snrf] = 'SYAS1106.003'"
    
'3- verifica se o arquivo ja existe na lista de arquivos de atualiza��o
'do usu�rio, caso n�o exista insere o registro, caso contrario atualiza.
    gSelect = "SELECT [snrf] "
    gSelect = gSelect & "From [EAPDB].[yasuser].[mailbox] "
    gSelect = gSelect & "WHERE [receiver] = '" & lCodUser & "' "
    gSelect = gSelect & "AND [snrf] = 'SYAS1106.003'"
    
    If gfObtRegistro(bdSyasEmis, gSelect, rsEAPDB, lMensagem) = False Then
        Call gpGraLog(2, lMensagem)
        Exit Sub
    End If
    
    If rsEAPDB.EOF = True Then
        'N�o existe o arquivos na lista do usuario
        If gfExeSQL(bdSyasEmis, gInsert, lMensagem) <> 0 Then
           Call gpGraLog(1, "SYASINFO " & lMensagem)
           Exit Sub
        End If
    Else
        'existe o arquivos na lista do usuario
        If gfExeSQL(bdSyasEmis, gUpdate, lMensagem) <> 0 Then
           Call gpGraLog(1, "SYASINFO " & lMensagem)
           Exit Sub
        End If
    End If
End Sub
