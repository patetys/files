Attribute VB_Name = "basM28V301"
Option Explicit
Private mEndMinimo          As Boolean          'Indicador de endosso m�nimo.
Private mNumProposta        As Long             'N�mero da proposta para DT1101D.
Private mQuaDias            As Integer          'Quantidade de dias.
Private mNomeContato        As String
Private mTelContato         As String
Private mEmailContato       As String
Private mCCotacaoOrig       As String
Private mObservacao         As String
Private mBoletos            As String
Private mCodCorretor        As String
Private mUsuario            As String
Private mRestituicao        As Boolean          'Indicador de restitui��o.
Private bdSYASEMIS          As ADODB.Connection 'Base de dados SYASEMIS.
Public Enum eTipTransmissao     'Tipo de Transmissao
    eTipTransmissao_ND = 0
    eTipTransmissao_Corretor = 1
    eTipTransmissao_Automatic = 2
End Enum
Public gArqSer  As Double
Public gArqEst  As Double

'C�digos de cobertura e descontos utilizados.
Public Const gCobCasco = 1          '01 = Cobertura de casco.
Public Const gCobRCDM = 3           '03 = Cobertura de RCDM.
Public Const gCobRCDC = 4           '04 = Cobertura de RCDC.
Public Const gCobRCMO = 5           '05 = Cobertura de RCMO.
Public Const gCobAPPMorte = 6       '06 = Cobertura de APP-Morte.
Public Const gCobAPPInvalidez = 7   '07 = Cobertura de APP-Invalidez.
Public Const gCobAPPDMH = 8         '08 = Cobertura de APP-DMH.
Public Const gCob0km = 9            '09 = Cobertura de ve�culo 0 km.
Public Const gCobAss24hs = 10       '10 = Cobertura de assist�ncia 24 horas.
Public Const gCobCarReserva = 11    '11 = Cobertura de carro reserva.
Public Const gCobDesExtr = 12       '12 = Cobertura de despesas extraordin�rias.
Public Const gCobVidros = 13        '13 = Cobertura de vidros.
Public Const gCobClauSocDir = 14    '14 = C�digo de cobertura de cl�usula s�cio-dirigente.

Public gEndPastas           As String   'Endere�o das pastas dos arquivos de atualiza��o

Public Const gDesCasco = 1          '01 = Desconto de casco.
Public Const gDesBonus = 2          '02 = Desconto de b�nus.
Public Const gDesFidelidade = 3     '03 = Desconto de fidelidade.
Public Const gDesFrota = 4          '04 = Desconto de frota.
Public Const gDesRC = 9             '09 = Desconto de RC.
Public Const gDesPerfil = 10        '10 = Desconto de perfil.
Public Const gDesAPP = 11           '11 = Desconto de APP.

Private Declare Function MoveFile Lib "kernel32" Alias "MoveFileA" _
                         (ByVal lpExistingFileName As String, ByVal lpNewFileName As String) As Long


Private Sub Main()
Dim lMensagem   As String
    'Obt�m informa��es do arquivo de inicializa��o.
    
    If App.PrevInstance = True Then
        End
    End If
    
    Call gpInicia
    gPrograma = "P28V300.EXE"
    If gfObtemDadosINI(gEndPastas, gEndSyasEdi, _
                       gIdeBasEAPDB, gTipBasEAPDB, gSerBasEAPDB, _
                       gEndBasEAPDB, gUIDBasEAPDB, gPWDBasEAPDB, _
                       gIdeBasSyasEmis, gTipBasSyasEmis, gSerBasSyasEmis, _
                       gEndBasSyasEmis, gUIDBasSyasEmis, gPWDBasSyasEmis, _
                        gEndSYASPROD, gTipSYASPROD, gSerSYASPROD, _
                       gEndSYASPROD, gUidSYASPROD, gPwdSYASPROD, _
                       lMensagem) = False Then
        GoTo Main_Erro
    End If
'Atribui os propriet�rios de tabela
    gPropTabelaSyasEdi = gIdeBasEAPDB & ".yasuser."
    gPropTabelaCorporativo = gIdeBasSyasEmis & ".."
    gPropTabelaSyasPortal = gEndSYASPROD & ".."
    
    
    Dim lDir As String
    
    lDir = Dir("L:\User_c\P24v007\MailboxesTeste\Yasuda\*.Y14")
    Do While lDir <> ""
        FileCopy "L:\User_c\P24v007\MailboxesTeste\Yasuda\" & lDir, "L:\User_c\P24v007\MailboxesTeste\Yasuda\" & Replace(lDir, "Y14", "P10")
        lDir = Dir()
    Loop
        
    
    Call gpCarregaDadosBoleto
    Call gpCarregaTransmissao("P10", bdSYASEMIS)   'Trasmiss�o do Corretor
    Call gpCarregaTransmissao("090", bdSYASEMIS)   'Transmiss�o Autom�tica
    Call gpCarregaTransmissao("014", bdSYASEMIS)   'Transmiss�o Autom�tica
    Call gpCarregaCotacao
    Call gpEnviaRetornoCotacao
    Call gpCarregaCancelamentoEmissao(bdSYASEMIS)
    
    
    'finaliza o programa
    End
    Exit Sub
Main_Erro:
    Call gpGraLog(0, lMensagem)
    On Error Resume Next
    Shell "NET SEND TJGOMES P28V300 - " & lMensagem
    Shell "NET SEND VAGNERSK P28V300 - " & lMensagem
    Shell "NET SEND TJGOMES P28V300 - " & lMensagem
    Shell "NET SEND VAGNERSK P28V300 - " & lMensagem
    End
End Sub

Public Sub gpVarPadrDLL(ByRef pobjCalc As clsC028O001)

    pobjCalc.Ser_SYASEMIS = gSerSYASEMIS
    pobjCalc.End_SYASEMIS = gEndSYASEMIS
    pobjCalc.Uid_SYASEMIS = gUidSYASEMIS
    pobjCalc.Pwd_SYASEMIS = gPwdSYASEMIS
    Set pobjCalc.mConSQL = mConexaoSQL
    pobjCalc.Perfil_Acesso = gPerfilAcesso
    pobjCalc.Tip_Usuario = gTipUsuario
    pobjCalc.End_P0043200 = gEndP0043200
    pobjCalc.End_P0043400 = gEndP0043400
    pobjCalc.End_P0043500 = gEndP0043500
    pobjCalc.End_P0043700 = gEndP0043700
    pobjCalc.End_P0043900 = gEndP0043900
    pobjCalc.End_P0044000 = gEndP0044000
    pobjCalc.End_P0044400 = gEndP0044400
    pobjCalc.End_P0044800 = gEndP0044800
    pobjCalc.End_P0044900 = gEndP0044900
    pobjCalc.End_P0045000 = gEndP0045000
    pobjCalc.End_P0045100 = gEndP0045100
    
End Sub

Public Sub gpEnviaRetornoCotacao()
Dim lMensagem       As String
Dim lComando        As String
Dim lRst            As ADODB.Recordset
Dim lNossoNumero    As String
Dim lPropostas(1)   As String
Dim lCodCorretor    As String
Dim lCodUsuario     As String
Dim lCotacao        As String
Dim lStatus         As Integer
Dim lSenha          As String
Dim lBusca          As String
Dim clsA28V201      As clsA28V201
Dim lDir            As String


    If gfAbrBasSQL(gEndSYASEMIS, gTipSYASEMIS, gSerBasSyasEmis, gEndSYASEMIS, gUidSYASEMIS, _
       gPwdSYASEMIS, bdSYASEMIS, lMensagem) = False Then
       If Not UCase(gSerSYASEMIS) Like "*MIX*" Then
            Shell "net send tjgomes Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send hideo Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send newton Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send oscar Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send jayme Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send cristina Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
        End If
        Call gpGraLog(2, lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    
    lComando = "Select * from siscota.dbo.tab_syas_cotacao where cod_ramo = 310"
    lComando = lComando & " and STATUS_ENVIO = 1 "
    
    If Not gfObtRegistro(bdSYASEMIS, lComando, lRst, lMensagem) Then
        Call gpGraLog(0, lMensagem)
        Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem
        End
    End If
    
    
    Do While Not lRst.EOF
        lNossoNumero = lRst("Nosso_Numero")
        lPropostas(1) = lNossoNumero
        lCodCorretor = lRst("COD_CORRETOR")
        lCodUsuario = lRst("COD_Usuario")
        lStatus = lRst("Cod_Status")
        lCotacao = lRst("CCotacao")
        lSenha = lRst("Senha")
        Set clsA28V201 = New clsA28V201
        'If lCodUsuario = "0" Then 'Realizada pelo site
            If Not clsA28V201.gfAtualizaClasse4Portal(lNossoNumero, lStatus, gTipBasSyasEmis, gEndBasSyasEmis, _
                gTipSYASPROD, gEndSYASPROD, lMensagem) Then
                Call gpGraLog(0, lMensagem)
                Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem
                Exit Sub
            End If
        'Else
            
        '    If clsA28V201.gfCriCotacaoAceita(lCodCorretor, lPropostas, _
        '            lCodUsuario, lStatus, lCotacao, lRst("NomArq") & ".033", lSenha, lMensagem) = False Then
        '        Call gpGraLog(0, lMensagem)
        '        Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem
        '        Exit Sub
        '    End If
        '    Set clsA28V201 = Nothing
        'End If
        lComando = "Update siscota.dbo.tab_syas_cotacao set status_envio = 2 where "
        lComando = lComando & " Nosso_Numero = " & mfFormatarCamposSQL(lRst("Nosso_Numero"))
        If gfExeSQL(bdSYASEMIS, lComando, lMensagem) <> 0 Then
            Call gpGraLog(0, lMensagem)
            Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem
            End
        End If
        lRst.MoveNext
    Loop
    
    lBusca = gAppPath & "Remessa\*.033"
    lDir = Dir(lBusca)
    Do While gfPreenchido(lDir) = True
        If mfEnviaRetornoCotacaoAceitaRec(Left(lDir, 6), lDir, ".033.033", lMensagem) = False Then
            Call gpGraLog(0, "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem)
            Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem
        End If
        lDir = Dir(lBusca)
    Loop
    
    lBusca = gAppPath & "P46V600\Remessa\*.034"
    lDir = Dir(lBusca)
    Do While gfPreenchido(lDir) = True
        FileCopy gAppPath & "P46V600\Remessa\" & lDir, gAppPath & "Remessa\" & lDir
        Kill gAppPath & "P46V600\Remessa\" & lDir
        lDir = Dir(lBusca)
    Loop
    
    
    lBusca = gAppPath & "Remessa\*.034"
    lDir = Dir(lBusca)
    Do While gfPreenchido(lDir) = True
        If mfEnviaRetornoCotacaoAceitaRec(Left(lDir, 6), lDir, ".034.034", lMensagem) = False Then
            Call gpGraLog(0, "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem)
            Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno aceita/recusa" & lMensagem
        End If
        lDir = Dir(lBusca)
    Loop
    Exit Sub
    
End Sub

Public Sub gpCarregaCotacao()
Dim lBusca          As String   'Busca do arquivo de entrada.
Dim lFileSize       As Double   'Tamanho em bytes do arquivo de entrada
Dim lDir            As String   'Resultado da fun��o DIR.
Dim lEndArqEntrada  As String   'Endere�o do arquivo de entrada.
Dim lEndCopRetorno  As String   'Endere�o da c�pia do arquivo de retorno.
Dim lMensagem       As String   'Mensagem.
    
Dim lNomArqEnvio    As String           ' antigo gNomArqEnvio
Dim lEndCopEntrada  As String           ' antigo gEndCopEntrada
Dim lNumCopEntrada  As Integer          ' antigo gNumCopEntrada
Dim lEndArqRetorno  As String           ' antigo gEndArqRetorno
Dim lNumArqRetorno  As Integer          ' antigo gNumArqRetorno
Dim lDatHorRetorno  As String
    
    'Busca os arquivos da pasta X:\mailboxes\YASUDA para o App.Path
Busca_Transmissao:

    lEndArqEntrada = gEndPastas & "YASUDA\"
    
    lBusca = gEndPastas & "YASUDA\*.030"
    
    lDir = Dir(lBusca)
    If gfPreenchido(lDir) = True Then
        'MoveFile lEndArqEntrada & lDir, gAppPath & Mid(lDir, 1, 12)
        If Len(Mid(lDir, 1, 12)) = 12 Then
            FileCopy lEndArqEntrada & lDir, gAppPath & Mid(lDir, 1, 14)
        Else
            FileCopy lEndArqEntrada & lDir, gAppPath & Mid(lDir, 1, 12)
        End If
        Kill lEndArqEntrada & lDir
    End If
    
    '4- Processa arquivo de entrada
    
    lBusca = gAppPath & "*.030"
    
    '5. Obt�m arquivo de entrada.
    lDir = Dir(lBusca)
    If Not gfPreenchido(lDir) Then
        lBusca = gAppPath & "Remessa\*.031"
        lDir = Dir(lBusca)
        Do While gfPreenchido(lDir) = True
            If mfEnviaRetornoCotacao(Left(lDir, 6), lDir, lMensagem) = False Then
                Call gpGraLog(0, "P28V300 - ERRO ao enviar protocolo" & lMensagem)
                On Error Resume Next
                Shell "net send tjgomes " & "P28V300 - ERRO ao enviar protocolo" & lMensagem
                On Error GoTo 0
            End If
            lDir = Dir(lBusca)
        Loop
        If Dir(gAppPath & "P46V600\") <> "" Then
            lBusca = gAppPath & "P46V600\*.031"
            lDir = Dir(lBusca)
            Do While gfPreenchido(lDir) = True
                FileCopy gAppPath & "P46V600\" & lDir, gAppPath & "Remessa\" & lDir
                Kill gAppPath & "P46V600\" & lDir
                lDir = Dir(lBusca)
            Loop
        End If
        Exit Sub
    End If
    
    If gfAbrBasSQL(gEndSYASEMIS, gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, gUidSYASEMIS, _
       gPwdSYASEMIS, bdSYASEMIS, lMensagem) = False Then
       If Not UCase(gSerSYASEMIS) Like "*MIX*" Then
            On Error Resume Next
            Shell "net send manfred Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send tjgomes Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send hideo Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send newton Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send oscar Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send jayme Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send cristina Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            On Error GoTo 0
        End If
        Call gpGraLog(2, lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    
    Do
        'a) Posiciona controles.
        lNomArqEnvio = Trim$(lDir)
        If Len(lNomArqEnvio) = 14 Then
            If Len(lNomArqEnvio) > 14 Then
                lNomArqEnvio = Left$(lNomArqEnvio, 14)
            Else
                While Len(lNomArqEnvio) < 14
                    lNomArqEnvio = lNomArqEnvio & " "
                Wend
            End If
        Else
            If Len(lNomArqEnvio) > 12 Then
                lNomArqEnvio = Left$(lNomArqEnvio, 12)
            Else
                While Len(lNomArqEnvio) < 12
                    lNomArqEnvio = lNomArqEnvio & " "
                Wend
            End If
        End If
        lEndArqEntrada = gAppPath & lDir

        'b) Copia arquivo de entrada.
        lEndCopEntrada = Mid$(lEndArqEntrada, 1, Len(lEndArqEntrada) - 3) & "Y30"
        Call FileCopy(lEndArqEntrada, lEndCopEntrada)

        'c) Exclui arquivo de entrada.
        lFileSize = FileLen(lEndArqEntrada)
        Kill lEndArqEntrada

        'd) Cria e inicializa arquivo de retorno.
        lEndArqRetorno = Mid$(lEndArqEntrada, 1, Len(lEndArqEntrada) - 3) & "031"
        lNumArqRetorno = FreeFile
        lDatHorRetorno = Format$(Now, "yyyymmddhhnnss")
        Open lEndArqRetorno For Output As #lNumArqRetorno

        'Verifica arquivo de entrada (atrav�s da c�pia do arquivo).
        lNumCopEntrada = FreeFile
        Open lEndCopEntrada For Input As #lNumCopEntrada
        If mfVerEntradaCotacao(lNomArqEnvio, lEndCopEntrada, lNumCopEntrada, _
                               lDatHorRetorno, lEndArqRetorno, lNumArqRetorno, lMensagem) = False Then
            On Error Resume Next
            Shell "net send tjgomes erro no arquivo de cotacao auto."
            Shell "net send tjgomes erro no arquivo de cotacao auto."
            On Error GoTo 0
            Call gpGraLog(0, lMensagem)
            Close #lNumCopEntrada
            Exit Sub
        End If
        Close #lNumCopEntrada

        'f) Encerra processo.
        Close #lNumArqRetorno

        'g) Copia o arquivo de retorno na pasta de remessa.
        lEndCopRetorno = gAppPath & "Remessa\"
        If Len(lNomArqEnvio) = 12 Then
            lEndCopRetorno = lEndCopRetorno & Mid$(lEndArqRetorno, Len(lEndArqRetorno) - 11, 12)
        Else
            lEndCopRetorno = lEndCopRetorno & Mid$(lEndArqRetorno, Len(lEndArqRetorno) - 13, 14)
        End If
        Call FileCopy(lEndArqRetorno, lEndCopRetorno)

        'h) marca arquivo como recebido
        If Len(lNomArqEnvio) = 12 Then
            Call gpMarcaRecebido(Left(lNomArqEnvio, 8), lFileSize, "YASUDA", "030")
        Else
            Call gpMarcaRecebido(Left(lNomArqEnvio, 10), lFileSize, "YASUDA", "030")
        End If

        'i) Verifica se tem outro arquivo de entrada a processar.
        lDir = Dir(lBusca)
        If Not gfPreenchido(lDir) Then
            Call gpFecha2(bdSYASEMIS)
            GoTo Busca_Transmissao
            Exit Sub
        End If
    Loop
End Sub

Public Sub gpCarregaDadosBoleto()
    Dim lBusca          As String   'Busca do arquivo de entrada.
    Dim lFileSize       As Double   'Tamanho em bytes do arquivo de entrada
    Dim lDir            As String   'Resultado da fun��o DIR.
    Dim lEndArqEntrada  As String   'Endere�o do arquivo de entrada.
    Dim lEndCopRetorno  As String   'Endere�o da c�pia do arquivo de retorno.
    Dim lMensagem       As String   'Mensagem.
    Dim lArgumento      As String   'Argumento da linha de comando usada para chamar o programa P28V300
                                '(semelhante ao PARM do Cobol).
                                
    Dim lPoint          As String
    Dim lCodUsuario     As String
    Dim lRst            As ADODB.Recordset
    Dim lNumArq         As Integer          'Utilizado com FreeFile para arquivo de retorno.
    Dim lEndArq         As String
    Dim lArray          As Variant
    Dim lCount          As Integer
    
Dim lNomArqEnvio    As String           ' antigo gNomArqEnvio
Dim lEndCopEntrada  As String           ' antigo gEndCopEntrada
Dim lEndArqRetorno  As String           ' antigo gEndArqRetorno
Dim lNumArqRetorno  As Integer          ' antigo gNumArqRetorno
Dim lDatHorRetorno  As String
    
    On Error GoTo ControleErro
Retorno:
    
    lEndArqEntrada = gEndPastas & "YASUDA\"
    
        
    lBusca = gEndPastas & "YASUDA\*.021"
    
    
    lPoint = "1"
    lDir = Dir(lBusca)
    If gfPreenchido(lDir) = True Then
        'MoveFile lEndArqEntrada & lDir, gAppPath & Mid(lDir, 1, 12)
        FileCopy lEndArqEntrada & lDir, gAppPath & Mid(lDir, 1, 12)
        Kill lEndArqEntrada & lDir
    End If
    
    '4- Processa arquivo de entrada
    
    lBusca = gAppPath & "*.021"
    
    '5. Obt�m arquivo de entrada.
    lPoint = "2"
    lDir = Dir(lBusca)
    If Not gfPreenchido(lDir) Then
        lBusca = gAppPath & "Remessa\*.022"
        lDir = Dir(lBusca)
        Do While gfPreenchido(lDir) = True
            If mfEnviaRetornoBoleto(Left(lDir, 6), lDir, lMensagem) = False Then
                Call gpGraLog(0, "P28V300 - ERRO ao enviar retorno do boleto" & lMensagem)
                Shell "net send tjgomes " & "P28V300 - ERRO ao enviar retorno do boleto" & lMensagem
            End If
            lDir = Dir(lBusca)
        Loop
        Exit Sub
    End If
    lPoint = "3"
    If gfAbrBasSQL(gEndSYASEMIS, gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, gUidSYASEMIS, _
       gPwdSYASEMIS, bdSYASEMIS, lMensagem) = False Then
       If Not UCase(gSerSYASEMIS) Like "*MIX*" Then
            Shell "net send manfred Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send tjgomes Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send hideo Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send newton Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send oscar Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send jayme Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
            Shell "net send cristina Servidor PSLUEDI com falha na conex�o SQL.  Verificar com urg�ncia."
        End If
        Call gpGraLog(2, lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    lPoint = "4"
    Do
        'a) Posiciona controles.
        lNomArqEnvio = Trim$(lDir)
        If Len(lNomArqEnvio) > 12 Then
            lNomArqEnvio = Left$(lNomArqEnvio, 12)
        Else
            While Len(lNomArqEnvio) < 12
                lNomArqEnvio = lNomArqEnvio & " "
            Wend
        End If
        lEndArqEntrada = gAppPath & lDir
        lPoint = "5"
        'b) Copia arquivo de entrada.
        lEndCopEntrada = Mid$(lEndArqEntrada, 1, Len(lEndArqEntrada) - 3) & "Y21"
        Call FileCopy(lEndArqEntrada, lEndCopEntrada)
        lPoint = "6"
        'c) Exclui arquivo de entrada.
        lFileSize = FileLen(lEndArqEntrada)
        Kill lEndArqEntrada

        'd) Cria e inicializa arquivo de retorno.
        lEndArqRetorno = Mid$(lEndArqEntrada, 1, Len(lEndArqEntrada) - 3) & "022"
        lNumArqRetorno = FreeFile
        lDatHorRetorno = Format$(Now, "yyyymmddhhnnss")
        Open lEndArqRetorno For Output As #lNumArqRetorno
        lPoint = "7"
        'e) Processa arquivo de entrada.
        mBoletos = ""
        mCodCorretor = ""
        Call mpProEntradaBoleto(lEndCopEntrada, lNumArqRetorno)

        'f) Encerra processo.
        Close #lNumArqRetorno

        'g) Copia o arquivo de retorno na pasta de remessa.
        lEndCopRetorno = gAppPath & "Remessa\"
        lEndCopRetorno = lEndCopRetorno & Mid$(lEndArqRetorno, Len(lEndArqRetorno) - 11, 12)
        Call FileCopy(lEndArqRetorno, lEndCopRetorno)
        
        lPoint = "8"
        'h) marca arquivo como recebido
        Call gpMarcaRecebido(Left(lNomArqEnvio, 8), lFileSize, "YASUDA", "021")
        
        ''Gero o mesmo arquivo para os demais usu�rios redes do corretor.
        'mBoletos
        lCodUsuario = Left(lNomArqEnvio, 6)
        
        '1. Verifico se existe o corretor informado
        gSelect = " SELECT  distinct "
        gSelect = gSelect & " t2.[user_name] "
        gSelect = gSelect & " From"
        gSelect = gSelect & " " & gPropTabelaSyasEdi & "enterprise t1,"
        gSelect = gSelect & " " & gPropTabelaSyasEdi & "[user] t2 ,"
        gSelect = gSelect & " " & gPropTabelaSyasEdi & "[YVIEW_USER_PLUS_ArqsVig] t3"
        gSelect = gSelect & " Where"
        gSelect = gSelect & " T1.id_enterprise = t2.id_enterprise"
        gSelect = gSelect & " and t3.[user_name] = t2.[user_name]"
        gSelect = gSelect & " AND T1.INSCRICAO_ESTADUAL = '" & Format(mCodCorretor, "0000000") & "'"
        gSelect = gSelect & " AND T2.ADM = 1"
        

        If gfObtRegistro(mConexaoSQL, gSelect, lRst, lMensagem) = False Then
            Call gpFecha2(mConexaoSQL)
            Call gpGraLog(2, lMensagem)
            Screen.MousePointer = vbDefault
            Exit Sub
        End If
        
        
        lNumArq = FreeFile
        lEndArq = gAppPath & "Copia.txt"
        
        On Error Resume Next
            Kill lEndArq
        On Error GoTo ControleErro
        
        Open lEndArq For Output As #lNumArq
        lArray = Split(mBoletos, ";")
        For lCount = 0 To UBound(lArray)
            If gfPreenchido(lArray(lCount)) Then
                Print #lNumArq, lArray(lCount)
            End If
        Next lCount
        Close #lNumArq
        
        
        Do While Not lRst.EOF
            If lRst("user_name") <> lCodUsuario Then
                lEndCopRetorno = gAppPath & "Remessa\"
                lEndCopRetorno = lEndCopRetorno & Format(lRst("user_name"), "000000") & "99.022"
               Call FileCopy(lEndArq, lEndCopRetorno)
            End If
            lRst.MoveNext
        Loop
                                                
        On Error Resume Next
            Kill lEndArq
        On Error GoTo ControleErro
        
        'i) Verifica se tem outro arquivo de entrada a processar.
        lPoint = "9"
        lDir = Dir(lBusca)
        If Not gfPreenchido(lDir) Then
            Call gpFecha2(bdSYASEMIS)
            GoTo Retorno
            Exit Sub
        End If
    Loop
    Exit Sub
ControleErro:
    Call gpGraLog(1, "gpCarregaDadosBoleto  - Erro : " & lPoint & "-" & Err.Description)
End Sub

Private Function mfEnviaRetornoCotacaoAceitaRec(ByVal pCodUser As String, _
                                  ByVal pFileName As String, pExtencao As String, _
                                  ByRef pMensagem As String) As Boolean
                                  
Dim lIDUser             As Integer
Dim lCopyOrigem         As String
Dim lPasteDestino       As String
Dim lPathKill           As String
Dim lMensagem           As String
Dim lExec               As String
Dim lCN_EAPDB           As ADODB.Connection
Dim lRsEAPDB            As ADODB.Recordset
Dim lRst                As ADODB.Recordset
Dim lCodUsuario         As String

 Err = 0
 On Error GoTo mfEnviaProtocolo_ERRO
 pMensagem = ""
 
'1- verifica a existencia diretorio e o arquivo de origem
    lCopyOrigem = gAppPath & "Remessa\" & pFileName
        
    If gfPreenchido(Dir(gAppPath & "Remessa", vbDirectory)) = True Then
        If gfPreenchido(Dir(lCopyOrigem)) = False Then
            pMensagem = lCopyOrigem & Chr(13) & "arquivo n�o localizado"
            GoTo mfEnviaProtocolo_ERRO
        End If
    Else
        pMensagem = gAppPath & "Remessa" & Chr(13) & "Caminho inexistente"
        GoTo mfEnviaProtocolo_ERRO
    End If

   
    '6- Abre a base de dados
    If gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, _
                   gPWDBasEAPDB, lCN_EAPDB, lMensagem) = False Then
        Call gpGraLog(0, "gpMarcaRecebido - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
        
    ''Gero o mesmo arquivo para os demais usu�rios redes do corretor.
    '1. Verifico se existe o corretor informado
    gSelect = " select t2.[user_name] from "
    gSelect = gSelect & " " & gPropTabelaSyasEdi & "[User] t2"
    gSelect = gSelect & " inner join " & gPropTabelaSyasEdi & "YTAB_USER_PROCES as p"
    gSelect = gSelect & " on t2.[user_name] = p.[user_name]"
    gSelect = gSelect & " and cod_proces = 6"
    gSelect = gSelect & " where id_enterprise = ("
    gSelect = gSelect & " SELECT"
    gSelect = gSelect & " id_enterprise"
    gSelect = gSelect & " From"
    gSelect = gSelect & " " & gPropTabelaSyasEdi & "[user] as u"
    gSelect = gSelect & " Where"
    gSelect = gSelect & " u.[user_name] = '" & Format(pCodUser, "000000") & "')"
    gSelect = gSelect & " union"
    gSelect = gSelect & " select '" & Format(pCodUser, "000000") & "' as [user_name]"

    If gfObtRegistro(mConexaoSQL, gSelect, lRst, lMensagem) = False Then
        Call gpFecha2(mConexaoSQL)
        Call gpGraLog(2, lMensagem)
        Screen.MousePointer = vbDefault
        Exit Function
    End If
    Dim lEndCopRetorno  As String
    Do While Not lRst.EOF
        lCodUsuario = lRst("user_name")
    
    '2- verifica a existencia diretorio destino
        lPasteDestino = gEndPastas
        lPasteDestino = lPasteDestino & lCodUsuario
        If Len(pFileName) = 14 Then
            lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 10) & pExtencao
        Else
            lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 8) & pExtencao
        End If
       
        If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
            'Verifica se o usuario j� possui pasta de arquivos
            'caso contr�rio cria a pasta
            MkDir lPasteDestino
        End If
       
        If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
            pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
            GoTo mfEnviaProtocolo_ERRO
        End If
        
        'Verifica tambem a existencia da pasta temp
            '********** Sem esta pasta a trasmiss�o de protocolo ao usuario
            '********** gera erro e encera o servi�o EDIServer
        If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
            'Verifica se o usuario j� possui pasta de arquivos
            'caso contr�rio cria a pasta
            MkDir lPasteDestino & "\temp"
        End If
    
        If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
            pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
            GoTo mfEnviaProtocolo_ERRO
        End If
        
    '3- Apaga o arquivo destino caso j� exista no diretorio destino
        
        'Concatena o nome do arquivo da String
        If Len(pFileName) = 14 Then
            lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 10) & pExtencao
        Else
            lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 8) & pExtencao
        End If
        
        If gfPreenchido(Dir(lPathKill)) = True Then
            Kill lPathKill
        End If
        
    '4- Copia o arquivo de ap�lices para a pasta do usuario
        FileCopy lCopyOrigem, lPasteDestino
        
    '5- verifica a existencia do arquivo no destino
        If gfPreenchido(Dir(lPasteDestino)) = False Then
            'Arquivo n�o foi copiado
            pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel copiar o arquivo."
            GoTo mfEnviaProtocolo_ERRO
        End If
    
            
        'Inclui registro para receber este arquivo
        lExec = "" & gPropTabelaSyasEdi & "[Proc_EAPDB_IncluiEnvio] "
        lExec = lExec & "'YASUDA', "
        If Len(pFileName) = 14 Then
            lExec = lExec & "'" & Mid(pFileName, 1, 10) & Left(pExtencao, 4) & "', "
        Else
            lExec = lExec & "'" & Mid(pFileName, 1, 8) & Left(pExtencao, 4) & "', "
        End If
        lExec = lExec & "'" & lCodUsuario & "'"
        
        If gfObtRegistro(lCN_EAPDB, lExec, lRsEAPDB, lMensagem) = False Then
            If Err = 0 Then
                Err = 1
            End If
            GoTo mfEnviaProtocolo_ERRO
        End If
        lRst.MoveNext
    Loop
    
    
    'Antes de excluir o arquivo...
    
    If Len(pFileName) = 14 Then
        gUpdate = " Update " & gPropTabelaSyasEdi & "[mailbox] Set [Status] = 1 WHERE [sender] = 'YASUDA' AND [snrf] = '" & Mid(pFileName, 1, 10) & Left(pExtencao, 4) & "'"
    Else
        gUpdate = " Update " & gPropTabelaSyasEdi & "[mailbox] Set [Status] = 1 WHERE [sender] = 'YASUDA' AND [snrf] = '" & Mid(pFileName, 1, 8) & Left(pExtencao, 4) & "'"
    End If
    gUpdate = gUpdate & "  AND [aprf] = '" & Right(pExtencao, 3) & "' AND [status] = 3"
    
    If gfExeSQL(lCN_EAPDB, gUpdate, lMensagem) <> 0 Then
         GoTo mfEnviaProtocolo_ERRO
    End If
        
'7- Exclui o arquivo de origem
    If gfPreenchido(Dir(lCopyOrigem)) = True Then
        Kill lCopyOrigem
    End If
    
'8 Finalizado OK
    mfEnviaRetornoCotacaoAceitaRec = True

'Saida da Fun��o
mfEnviaRetornoCotacaoAceitaRec_SAIDA:
    Exit Function
    
'Tratamento de erro
mfEnviaProtocolo_ERRO:
    mfEnviaRetornoCotacaoAceitaRec = False
    pMensagem = "mfEnviaRetornoCotacaoAceitaRec  - Erro " & Err & " " & Error$ & pMensagem
    
    GoTo mfEnviaRetornoCotacaoAceitaRec_SAIDA
End Function

Private Function mfEnviaRetornoBoleto(ByVal pCodUser As String, _
                                  ByVal pFileName As String, _
                                  ByRef pMensagem As String) As Boolean
                                  
Dim lIDUser             As Integer
Dim lCopyOrigem         As String
Dim lPasteDestino       As String
Dim lPathKill           As String
Dim lMensagem           As String
Dim lExec               As String
Dim lCN_EAPDB           As ADODB.Connection
Dim lRsEAPDB            As ADODB.Recordset

 Err = 0
 On Error GoTo mfEnviaProtocolo_ERRO
 pMensagem = ""
 
'1- verifica a existencia diretorio e o arquivo de origem
    lCopyOrigem = gAppPath & "Remessa\" & pFileName
        
    If gfPreenchido(Dir(gAppPath & "Remessa", vbDirectory)) = True Then
        If gfPreenchido(Dir(lCopyOrigem)) = False Then
            pMensagem = lCopyOrigem & Chr(13) & "arquivo n�o localizado"
            GoTo mfEnviaProtocolo_ERRO
        End If
    Else
        pMensagem = gAppPath & "APOLICES" & Chr(13) & "Caminho inexistente"
        GoTo mfEnviaProtocolo_ERRO
    End If

'2- verifica a existencia diretorio destino
    
    lPasteDestino = gEndPastas
    
    
    
    lPasteDestino = lPasteDestino & pCodUser
    lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".022.022"
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino
    End If
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
    'Verifica tambem a existencia da pasta temp
        '********** Sem esta pasta a trasmiss�o de protocolo ao usuario
        '********** gera erro e encera o servi�o EDIServer
    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino & "\temp"
    End If

    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
'3- Apaga o arquivo destino caso j� exista no diretorio destino
    
    'Concatena o nome do arquivo da String
    lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".022.022"
    
    If gfPreenchido(Dir(lPathKill)) = True Then
        Kill lPathKill
    End If
    
'4- Copia o arquivo de ap�lices para a pasta do usuario
    FileCopy lCopyOrigem, lPasteDestino
    
'5- verifica a existencia do arquivo no destino
    If gfPreenchido(Dir(lPasteDestino)) = False Then
        'Arquivo n�o foi copiado
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel copiar o arquivo."
        GoTo mfEnviaProtocolo_ERRO
    End If

'6- Abre a base de dados
    If gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, _
                   gPWDBasEAPDB, lCN_EAPDB, lMensagem) = False Then
        Call gpGraLog(0, "gpMarcaRecebido - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    
    
    'Inclui registro para receber este arquivo
    lExec = "" & gPropTabelaSyasEdi & "[Proc_EAPDB_IncluiEnvio] "
    lExec = lExec & "'YASUDA', "
    lExec = lExec & "'" & Mid(pFileName, 1, 8) & ".022', "
    lExec = lExec & "'" & pCodUser & "'"
    
    If gfObtRegistro(lCN_EAPDB, lExec, lRsEAPDB, lMensagem) = False Then
        If Err = 0 Then
            Err = 1
        End If
        GoTo mfEnviaProtocolo_ERRO
    End If
    

'7- Exclui o arquivo de origem
    If gfPreenchido(Dir(lCopyOrigem)) = True Then
        Kill lCopyOrigem
    End If
    
'8 Finalizado OK
    mfEnviaRetornoBoleto = True

'Saida da Fun��o
mfEnviaProtocolo_SAIDA:
    Exit Function
    
'Tratamento de erro
mfEnviaProtocolo_ERRO:
    mfEnviaRetornoBoleto = False
    pMensagem = " mfEnviaRetornoBoleto - Erro " & Err & " " & Error$ & pMensagem
                  
    GoTo mfEnviaProtocolo_SAIDA
End Function
Private Function mfEnviaRetornoCotacao(ByVal pCodUser As String, _
                                  ByVal pFileName As String, _
                                  ByRef pMensagem As String) As Boolean
                                  
Dim lIDUser             As Integer
Dim lCopyOrigem         As String
Dim lPasteDestino       As String
Dim lPathKill           As String
Dim lMensagem           As String
Dim lExec               As String
Dim lCN_EAPDB           As ADODB.Connection
Dim lRsEAPDB            As ADODB.Recordset

 Err = 0
 On Error GoTo mfEnviaProtocolo_ERRO
 pMensagem = ""
 
'1- verifica a existencia diretorio e o arquivo de origem
    lCopyOrigem = gAppPath & "Remessa\" & pFileName
        
    If gfPreenchido(Dir(gAppPath & "Remessa", vbDirectory)) = True Then
        If gfPreenchido(Dir(lCopyOrigem)) = False Then
            pMensagem = lCopyOrigem & Chr(13) & "arquivo n�o localizado"
            GoTo mfEnviaProtocolo_ERRO
        End If
    Else
        pMensagem = gAppPath & "APOLICES" & Chr(13) & "Caminho inexistente"
        GoTo mfEnviaProtocolo_ERRO
    End If

'2- verifica a existencia diretorio destino
    
    lPasteDestino = gEndPastas
    

    
    lPasteDestino = lPasteDestino & pCodUser
    If Len(pFileName) = 12 Then
        lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".031.031"
    Else
        lPathKill = lPasteDestino & "\" & Mid(pFileName, 1, 10) & ".031.031"
    End If
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino
    End If
   
    If gfPreenchido(Dir(lPasteDestino, vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
    'Verifica tambem a existencia da pasta temp
        '********** Sem esta pasta a trasmiss�o de protocolo ao usuario
        '********** gera erro e encera o servi�o EDIServer
    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        'Verifica se o usuario j� possui pasta de arquivos
        'caso contr�rio cria a pasta
        MkDir lPasteDestino & "\temp"
    End If

    If gfPreenchido(Dir(lPasteDestino & "\temp", vbDirectory)) = False Then
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel acessar o destino."
        GoTo mfEnviaProtocolo_ERRO
    End If
    
'3- Apaga o arquivo destino caso j� exista no diretorio destino
    
    'Concatena o nome do arquivo da String
    If Len(pFileName) = 12 Then
        lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 8) & ".031.031"
    Else
        lPasteDestino = lPasteDestino & "\" & Mid(pFileName, 1, 10) & ".031.031"
    End If
    
    If gfPreenchido(Dir(lPathKill)) = True Then
        Kill lPathKill
    End If
    
'4- Copia o arquivo de ap�lices para a pasta do usuario
    FileCopy lCopyOrigem, lPasteDestino
    
'5- verifica a existencia do arquivo no destino
    If gfPreenchido(Dir(lPasteDestino)) = False Then
        'Arquivo n�o foi copiado
        pMensagem = lPasteDestino & Chr(13) & "N�o foi possivel copiar o arquivo."
        GoTo mfEnviaProtocolo_ERRO
    End If

'6- Abre a base de dados
    
    If gfAbrBasSQL("EAPDB", gTipBasEAPDB, gSerBasEAPDB, gEndBasEAPDB, gUIDBasEAPDB, _
                   gPWDBasEAPDB, lCN_EAPDB, lMensagem) = False Then
        Call gpGraLog(0, "gpMarcaRecebido - " & lMensagem & vbLf & vbLf & "O sistema ser� encerrado.")
        End
    End If
    
    
    'Inclui registro para receber este arquivo
    lExec = "" & gPropTabelaSyasEdi & "[Proc_EAPDB_IncluiEnvio] "
    lExec = lExec & "'YASUDA', "
    If Len(pFileName) = 12 Then
        lExec = lExec & "'" & Mid(pFileName, 1, 8) & ".031', "
    Else
        lExec = lExec & "'" & Mid(pFileName, 1, 10) & ".031', "
    End If
    lExec = lExec & "'" & pCodUser & "'"
    
    If gfObtRegistro(lCN_EAPDB, lExec, lRsEAPDB, lMensagem) = False Then
        If Err = 0 Then
            Err = 1
        End If
        GoTo mfEnviaProtocolo_ERRO
    End If
    

'7- Exclui o arquivo de origem
    If gfPreenchido(Dir(lCopyOrigem)) = True Then
        Kill lCopyOrigem
    End If
    
'8 Finalizado OK
    mfEnviaRetornoCotacao = True

'Saida da Fun��o
mfEnviaProtocolo_SAIDA:
    Exit Function
    
'Tratamento de erro
mfEnviaProtocolo_ERRO:
    mfEnviaRetornoCotacao = False
    pMensagem = "mfEnviaProtocolo - Erro " & Err & " " & Error$ & pMensagem
                  
    GoTo mfEnviaProtocolo_SAIDA
End Function

Private Function mfPosRegistro(ByVal pOpcao As Byte, ByVal pNomCampo As String, ByVal pCampo, _
                               ByVal pTamanho As Byte, ByVal pDecimais As Byte, _
                               ByRef pRegistro As String, ByRef pMensagem As String) As Boolean
    'Fun��o: retorna campo formatado para inclus�o na tabela.

    'Par�metros de entrada...pOpcao......1 = posiciona campo num�rico com tamanho e casas decimais
    '                                        especificados (consiste e emite mensagem).
    '                                    2 = posiciona campo num�rico com tamanho e casas decimais
    '                                        especificados (preenche com zero se campo com erro).
    '                                    3 = indicador (S ou N).
    '                                    4 = campo alfanum�rico (preenche com branco se campo com erro).
    '                                    5 = campo num�rico - preenche com zero se registro incompleto ou
    '                                        campo n�o num�rico - considera 2 casas decimais.
    '                                    6 = campo alfanum�rico com conte�do num�rico - consiste e
    '                                        emite mensagem.
    '                        pNomCampo...nome do campo.
    '                        pCampo......campo a ser formatado e posicionado no registro.
    '                        pTamanho....tamanho do campo no registro de sa�da.
    '                        pDecimais...quantidade de casas decimais a serem consideradas.
    'Par�metros de sa�da.....pRegistro...registro a ser gravado.
    '                        pMensagem...mensagem.

    mfPosRegistro = False

    '1. Consiste par�metros de entrada.
    'a) Op��o.
    If Not gfPreenchido(pOpcao) Then
        pMensagem = "FTE0006 - Op��o inv�lida (formata campo para inclus�o da tabela - op��o n�o " & _
                    "preenchida."
        Exit Function
    End If
    If Not IsNumeric(pOpcao) Then
        pMensagem = "FTE0006 - Op��o inv�lida (formata campo para inclus�o da tabela - op��o n�o " & _
                    "num�rica."
        Exit Function
    End If
    If pOpcao <> 1 And pOpcao <> 2 And pOpcao <> 4 And pOpcao <> 5 And pOpcao <> 6 Then
        pMensagem = "FTE0006 - Op��o inv�lida (formata campo para inclus�o da tabela - op��o " & _
                    "desconhecida: " & pOpcao & "."
        Exit Function
    End If
    'b) Nome do campo.
    If Not gfPreenchido(pNomCampo) Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (nome do campo n�o " & _
                    "preenchido)."
        Exit Function
    End If
    'c) Tamanho.
    If Not gfPreenchido(pTamanho) Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (tamanho para o campo " & _
                    "n�o preenchido)."
        Exit Function
    End If
    If Not IsNumeric(pTamanho) Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (tamanho informado para " & _
                    "o campo n�o num�rico)."
        Exit Function
    End If
    If Val(pTamanho) = 0 Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (tamanho informado para " & _
                    "o campo igual a zero)."
        Exit Function
    End If
    'd) Quantidade de casas decimais.
    If Not gfPreenchido(pDecimais) Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (quantidade de casas " & _
                    "decimais n�o preenchida)."
        Exit Function
    End If
    If Not IsNumeric(pDecimais) Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (quantidade de casas " & _
                    "decimais n�o num�rico)."
        Exit Function
    End If
    If Val(pDecimais) > Val(pTamanho) Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (quantidade de casas " & _
                    "decimais superior ao tamanho informado para o campo)."
        Exit Function
    End If
    If Val(pDecimais) > 6 Then
        pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (quantidade de casas " & _
                    "decimais superior a 6)."
        Exit Function
    End If

    '2. Posiciona campo de acordo com a op��o.
    Select Case pOpcao
        Case 1      'Posiciona campo num�rico (consiste e emite mensagem).
            If IsNull(pCampo) Then
                pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (campo " & _
                            pNomCampo & " nulo)."
                Exit Function
            End If
            If Not IsNumeric(pCampo) Then
                pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (campo " & _
                            pNomCampo & " n�o num�rico)."
                Exit Function
            End If
            Select Case pDecimais
                Case 0
                    'Nada a fazer.
                Case 1
                    pCampo = pCampo * 10
                Case 2
                    pCampo = pCampo * 100
                Case 3
                    pCampo = pCampo * 1000
                Case 4
                    pCampo = pCampo * 10000
                Case 5
                    pCampo = pCampo * 100000
                Case 6
                    pCampo = pCampo * 1000000
                Case Else
                    pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (quantidade " & _
                                "de casas decimais para posicionar campo " & pNomCampo & " superior a 6)."
                    Exit Function
            End Select
            pRegistro = Format$(pCampo, String(pTamanho, "0"))
        Case 2      'Posiciona campo num�rico (preenche com zero se campo com erro).
            If IsNull(pCampo) Then
                pRegistro = String(pTamanho, "0")
            Else
                If IsNumeric(pCampo) Then
                    Select Case pDecimais
                        Case 0
                            'Nada a fazer.
                        Case 1
                            pCampo = pCampo * 10
                        Case 2
                            pCampo = pCampo * 100
                        Case 3
                            pCampo = pCampo * 1000
                        Case 4
                            pCampo = pCampo * 10000
                        Case 5
                            pCampo = pCampo * 100000
                        Case 6
                            pCampo = pCampo * 1000000
                        Case Else
                            pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL " & _
                                        "(quantidade de casas decimais para posicionar campo " & _
                                        pNomCampo & " superior a 6)."
                            Exit Function
                    End Select
                    pRegistro = Right$(Format$(pCampo, String(pTamanho, "0")), pTamanho)
                Else
                    pRegistro = String(pTamanho, "0")
                End If
            End If
        Case 4      'Posiciona campo alfanum�rico (preenche com branco se campo com erro).
            If gfPreenchido(pCampo) Then
                pRegistro = gfForAspas(Left$(Trim(pCampo) & Space(pTamanho), pTamanho))
            Else
                pRegistro = gfForAspas(Space(pTamanho))
            End If
        Case 6      'Posiciona campo alfanum�rico com conte�do num�rico (consiste e emite mensagem).
            If Not gfPreenchido(pCampo) Then
                pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (campo " & _
                            pNomCampo & " n�o preenchido)."
                Exit Function
            End If
            If Not IsNumeric(pCampo) Then
                pMensagem = "FTE0031 - Erro ao formatar campo para base de dados SQL (campo " & _
                            pNomCampo & " n�o num�rico)."
                Exit Function
            End If
            pRegistro = Right$(String(pTamanho, "0") & Trim(pCampo), pTamanho)
    End Select

    mfPosRegistro = True
End Function
Private Function mfProNumProposta(ByRef pNumProposta As Long, ByRef pMensagem As String) As Boolean
    'Fun��o: Busca pr�ximo n�mero de proposta.

    'Par�metros de sa�da...pNumProposta...N�mero da proposta.
    '                      pMensagem......Mensagem.

    Dim rsTAB_NUM_PROP_SYAS As ADODB.Recordset  'Registro: TAB_NUM_PROP_SYAS.

    mfProNumProposta = False

    '1. Posiciona par�metro de sa�da.
    pNumProposta = 0

    '2. Busca registro na tabela.
    gSelect = "SELECT num_prop FROM TAB_NUM_PROP_SYAS"
    If gfObtRegistro(bdSYASEMIS, gSelect, rsTAB_NUM_PROP_SYAS, pMensagem) = False Then
        Exit Function
    End If
    If rsTAB_NUM_PROP_SYAS.EOF = True Then
        pMensagem = "FTE0032 - Registro n�o localizado (TAB_NUM_PROP_SYAS)."
        Exit Function
    End If

    '3. Posiciona pr�ximo n�mero de proposta e atualiza base de dados.
    pNumProposta = rsTAB_NUM_PROP_SYAS!Num_Prop
    If pNumProposta < 999999 Then
        gUpdate = "UPDATE TAB_NUM_PROP_SYAS SET NUM_PROP = NUM_PROP + 1"
    Else
        gUpdate = "UPDATE TAB_NUM_PROP_SYAS SET NUM_PROP = 1"
    End If
    If gfExeSQL(bdSYASEMIS, gUpdate, pMensagem) <> 0 Then
        Exit Function
    End If

    mfProNumProposta = True
End Function

Private Function mfVerEntradaCotacao(ByVal pNomArqEnvio As String, _
                                     ByVal pEndCopEntrada As String, _
                                     ByRef pNumCopEntrada As Integer, _
                                     ByRef pDatHorEnvio As String, _
                                     ByRef pEndArqRetorno As String, _
                                     ByRef pNumArqRetorno As Integer, _
                                     ByRef pMensagem As String) As Boolean
    'Fun��o: Verifica arquivo de entrada.

    'Par�metro de sa�da...pMensagem...Mensagem.

    Dim li              As Integer  'Utilizado com For...Next.
    Dim lPosicao        As Integer  'Utilizado com InStr.
    Dim lRegistro       As String   'Registro.
    Dim lTotCalculado   As Double   'Total calculado pelo programa.
    Dim lTotGravado     As Double   'Total gravado no arquivo de propostas.
    Dim lTotInvertido   As String   'Total invertido.
    Dim lCotacaoAuto    As Boolean

Dim lstcProposta         As stcA28V300          'Antigo gstcProposta
Dim lColProposta         As Collection          'Antigo lColProposta
Dim lQuaPropostas        As Integer             'Antigos gQuaPropostas

    mfVerEntradaCotacao = False
    Set lstcProposta = New stcA28V300
    Set lColProposta = New Collection

    '1. Posiciona controle.
    pDatHorEnvio = "00000000000000"

    If Not gfAbrBasSQL("SYAS_EMIS", gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, _
          gUidSYASEMIS, gPwdSYASEMIS, mConexaoSQL, lTotInvertido) Then
        Call gpGraLog(1, lTotInvertido)
        Exit Function
    End If
    
    '2. Verifica se arquivo de entrada tem registro.
    Line Input #pNumCopEntrada, lRegistro
    If EOF(pNumCopEntrada) Then
        pMensagem = "Arquivo de transmiss�o sem registro."
        Exit Function
    End If

    '3. Verifica primeiro registro.
    If Not gfPreenchido(lRegistro) Then
        pMensagem = "Arquivo de transmiss�o inv�lido - primeiro registro em branco."
        Exit Function
    End If
    If Len(Trim(lRegistro)) < 8 Then
        pMensagem = "Arquivo de transmiss�o inv�lido - registro com menos de 8 caracteres: " & lRegistro
        Exit Function
    End If

    lTotCalculado = 0
    lTotGravado = 0
    lCotacaoAuto = False
    Do
        If gfPreenchido(lRegistro) Then     'N�o considerar registro em branco.
            lRegistro = UCase$(Trim(lRegistro))
            If Len(lRegistro) < 8 Then
                pMensagem = "Arquivo de transmiss�o inv�lido - registro com menos de 8 posi��es: " & _
                            lRegistro
                Exit Function
            End If
            Select Case Left$(lRegistro, 8)
                Case "USUARIO ", "CORRETOR"
                    lPosicao = InStr(lRegistro, "DATA")
                    If lPosicao = 0 Then
                        pDatHorEnvio = "00000000"
                    Else
                        pDatHorEnvio = Mid$(lRegistro, lPosicao + 11, 4) & _
                                       Mid$(lRegistro, lPosicao + 8, 2) & _
                                       Mid$(lRegistro, lPosicao + 5, 2)
                    End If
                    lPosicao = InStr(lRegistro, "HORA")
                    If lPosicao = 0 Then
                        pDatHorEnvio = pDatHorEnvio & "000000"
                    Else
                        pDatHorEnvio = pDatHorEnvio & _
                                       Mid$(lRegistro, lPosicao + 5, 2) & _
                                       Mid$(lRegistro, lPosicao + 8, 2) & _
                                       Mid$(lRegistro, lPosicao + 11, 2)
                    End If
                    
                    mCodCorretor = Val(Trim(Mid(lRegistro, 9, 7)))
                    
                    lPosicao = InStr(lRegistro, "USUARIO")
                    If lPosicao > 0 Then
                        mUsuario = Mid(lRegistro, lPosicao + 8, 6)
                    Else
                        mUsuario = ""
                    End If
                    
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                'Inclus�o da Base\Tabela P0042601
                'Case "P0042100", "P0042200", "P0042300", "P0042600", "P0042700", "P0042800"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'Case "P0042100", "P0042200", "P0042300", "P0042600", "P0042700", "P0042800", "P0042601"
                Case "P0042100", "P0042200", "P0042300", "P0042600", "P0042700", "P0042800", "P0042601", "TAB_HIST_ROTEIRO_CALCULO"
                'CyberTools - Ari - Task 1884:Alterar programas de transmiss�o. - Mar�o\2014
                'CyberTools - Projeto: Comum/Ve�culo e Perfil - Ari - Dezembro\2013
                    'Registro v�lidos.
                    lCotacaoAuto = True
                Case "COTACAO "
                    If lCotacaoAuto = False Then
                        'Primeiro item de Cotacao
                        mNomeContato = Trim(Mid(lRegistro, 29, 100))
                        mEmailContato = Trim(Mid(lRegistro, 129, 50))
                        mTelContato = Trim(Mid(lRegistro, 179, 50))
                        mCCotacaoOrig = Trim(Mid(lRegistro, 229, 12))
                        mObservacao = Trim(Mid(lRegistro, 249))
                    Else
                        lTotGravado = CDbl(Trim$(Mid$(lRegistro, 9)))
                        Exit Do
                    End If
                Case Else
                    pMensagem = "Arquivo de transmiss�o inv�lido - registro com c�digo desconhecido: " & _
                        lRegistro
                    Exit Function
            End Select
            For li = 1 To Len(Trim(lRegistro))
                lTotCalculado = lTotCalculado + Asc(Mid(lRegistro, li, 1))
            Next li
            If EOF(pNumCopEntrada) Then
                pMensagem = "Arquivo de transmiss�o inv�lido - n�o encontrado registro de controle."
                Exit Function
            End If
            Line Input #pNumCopEntrada, lRegistro
        End If
    Loop
    lTotInvertido = ""
    For li = Len(Trim(CStr(lTotCalculado))) To 1 Step -1
        lTotInvertido = lTotInvertido & Mid(Trim(CStr(lTotCalculado)), li, 1)
    Next li
    
    GoTo Pula       'TEMPOR�RIO...
    
    If lTotGravado <> CDbl(lTotInvertido) Then
        pMensagem = "Arquivo de transmiss�o inv�lido - registro de controle inv�lido."
        Exit Function
    End If
        
Pula:
    Close #pNumCopEntrada
    '2. Fase 1: Processa arquivo de entrada (a partir da c�pia).
    Open pEndCopEntrada For Input As #pNumCopEntrada
    
    'Cota��o Auto s�o inclu�das na base de dados do GED.
    gOwner = "GED.DBO."
    
    If Not gfFase1(pNomArqEnvio, pEndArqRetorno, False, False, _
                   pEndCopEntrada, pNumCopEntrada, pEndArqRetorno, _
                   pNumArqRetorno, lQuaPropostas, lstcProposta, lColProposta, mConexaoSQL) Then
        Close #pNumCopEntrada
        Exit Function
    End If
    
    'If Not mfIncluirSiscotaAuto(mRegNosNumero, pMensagem) Then GoTo ControleErro
    If Not mfIncluirSiscotaAuto(lstcProposta.RegNosNumero, pNomArqEnvio, pNumArqRetorno, pMensagem) Then GoTo ControleErro
    
    Close #pNumArqRetorno
    mfVerEntradaCotacao = True
    Exit Function
ControleErro:
    Close #pNumArqRetorno
    If gfPreenchido(pMensagem) = False Then
        pMensagem = Err.Description
    End If
End Function

Private Function mfIncluirSiscotaAuto(ByVal pNosso_Numero As String, _
                                      ByVal pNomArqEnvio As String, _
                                      ByRef pNumArqRetorno As Integer, _
                                      pMensagem As String) As Boolean
Dim lExec       As String
Dim lCCotacao   As String
Dim lRegistro   As String
Dim lRst        As ADODB.Recordset
Dim lSenha      As String
Dim lAux        As Integer

    'Chama a procedure que ir� retornar o n�mero da cota��o.
    lExec = " exec siscota.dbo.proc_CotacaoAutoSyas " & mfFormatarCamposSQL(pNosso_Numero) & "," & _
            Val(mCCotacaoOrig) & " ," & mfFormatarCamposSQL(mNomeContato) & "," & _
            mfFormatarCamposSQL(mEmailContato) & "," & _
            mfFormatarCamposSQL(mTelContato) & ",'" & Replace(mObservacao, "%!*", vbCrLf) & "'"
    If Not gfObtRegistro(mConexaoSQL, lExec, lRst, pMensagem) Then
        Exit Function
    End If
    
    If Not lRst.EOF Then
        lCCotacao = lRst("Cotacao")
    End If
    
    lExec = "Delete from GED.DBO.P0042300 where  Nosso_Numero = " & mfFormatarCamposSQL(pNosso_Numero)
    lExec = lExec & " and Num_Item = 0 and Num_Linha = 2 "
    If gfExeSQL(mConexaoSQL, lExec, pMensagem) <> 0 Then
        Exit Function
    End If
    
    
    lExec = "INSERT INTO GED.DBO.P0042300 (Nosso_Numero, Num_Item, Num_Linha, Observacao, Dat_Alt, " & _
            "Cod_User_Alt) VALUES (" & _
            mfFormatarCamposSQL(pNosso_Numero) & ", 0 , 2 , " & _
            mfFormatarCamposSQL(lCCotacao) & ", 0,'')"
    If gfExeSQL(mConexaoSQL, lExec, pMensagem) <> 0 Then
        Exit Function
    End If
    
    lRegistro = "STATUS01"
    lRegistro = lRegistro & pNosso_Numero
    lRegistro = lRegistro & lCCotacao
    Print #pNumArqRetorno, lRegistro
    
    lAux = Second(Now)
Retorno:
    If lAux > 25 Then
        lAux = CInt(lAux / 2)
        GoTo Retorno
    End If
    lSenha = Chr(Int(lAux * Rnd) + 65)
    
    lAux = Second(Now)
retorno2:
    If lAux > 25 Then
        lAux = CInt(lAux / 2)
        GoTo retorno2
    End If
    lSenha = lSenha & Chr(Int(lAux * Rnd) + 65)
    
    lAux = Second(Now)
retorno3:
    If lAux > 25 Then
        lAux = CInt(lAux / 2)
        GoTo retorno3
    End If
    lSenha = lSenha & Chr(Int(lAux * Rnd) + 65)
    
    lAux = Second(Now) + Minute(Now) * Hour(Now)
retorno4:
    If lAux > 999 Then
        lAux = CInt(lAux / 2)
        GoTo retorno4
    End If
    lSenha = lSenha & Format(CInt(lAux * Rnd) + 100, "000") '
    
    lExec = "Insert into siscota.dbo.tab_syas_cotacao (CCOTACAO,NOSSO_NUMERO, " & _
            " DATA_INCLUSAO, COD_RAMO, cod_status, STATUS_ENVIO, " & _
            "COD_CORRETOR, COD_USUARIO, NomArq, SENHA ) values ( " & _
            mfFormatarCamposSQL(lCCotacao) & "," & _
            mfFormatarCamposSQL(pNosso_Numero) & "," & _
            gfForData(3) & "," & _
            "310, 1, 0," & _
            mCodCorretor & "," & mUsuario & " , " & Replace(mfFormatarCamposSQL(pNomArqEnvio), ".030", "") & ",'" & lSenha & "')"
            
    If gfExeSQL(mConexaoSQL, lExec, pMensagem) <> 0 Then
        Exit Function
    End If
    
    mfIncluirSiscotaAuto = True
End Function
Private Function mfVerEntradaBoleto(ByRef pNumCopEntrada As Integer, _
                                    ByRef pNumArqRetorno As Integer) As Boolean
    'Fun��o: Fase 1 - Processa arquivo de entrada.

    Dim lMensagem       As String   'Mensagem.
    Dim lPriVez         As Boolean  'Primeira vez.
    Dim lRegistro       As String   'Registro.
    Dim lTemErro        As Boolean  'Indica que houve erro na proposta.
    Dim lComando        As String
    Dim lBoleto         As String
    Dim lNosso_Numero   As String
    Dim lRst            As ADODB.Recordset
    Dim lBoletoDuplicado    As Boolean
    Dim lTodosRegistros As String
    Dim lAlterar        As Boolean
    Dim lIncluir        As Boolean
    
    
Dim lQuaPropostas        As Integer             'Antigos gQuaPropostas
    
    '1. Processa arquivo.
    lQuaPropostas = 0
    If Not gfAbrBasSQL("SYAS_EMIS", gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, _
        gUidSYASEMIS, gPwdSYASEMIS, mConexaoSQL, lMensagem) Then
        Call gpGraLog(1, lMensagem)
        Exit Function
    End If
    Do
        lBoletoDuplicado = False
        Line Input #pNumCopEntrada, lRegistro
        If gfPreenchido(lRegistro) Then     'N�o considerar registro em branco.
            lRegistro = UCase$(Trim(lRegistro))
            If gfPreenchido(lRegistro) Then
                lBoleto = Mid(lRegistro, 1, 7)
                lNosso_Numero = Mid(lRegistro, 8, 20)
                lComando = " Select * from " & gPropTabelaCorporativo & "TAB_CTRL_PAGANTEC where  NUM_BOLETO = " & Mid(lBoleto, 2)
                lComando = lComando & " and (dat_venc = 0 or dat_venc > convert(varchar,dateadd(day,-210,getdate()),112))"
                If Not gfObtRegistro(mConexaoSQL, lComando, lRst, lMensagem) Then
                    Call gpGraLog(1, lMensagem)
                    Exit Function
                End If
                lTodosRegistros = ";"
                Do While Not lRst.EOF
                    lTodosRegistros = lTodosRegistros & Trim(lRst("Num_Prop")) & ";"
                    lRst.MoveNext
                Loop
                lAlterar = False
                lIncluir = False
                lBoletoDuplicado = False
                If lTodosRegistros Like "*;" & lNosso_Numero & ";*" Or lTodosRegistros = ";;" Then
                    lAlterar = True
                Else
                    If lTodosRegistros = ";" Then
                        lIncluir = True
                    Else
                        lIncluir = True
                        lBoletoDuplicado = True
                    End If
                End If
                
                If lBoletoDuplicado Then
                    'O mesmo boleto est� para dois nossos n�meros diferentes.
                    Call gpGraLog(0, "Boleto duplicado " & lBoleto)
                    Call mpGravaArqBolDuplicado(lRst, lRegistro)
                    GoTo Incluir
                ElseIf lAlterar = True Then
                    'Devo atualizar registro
                    lComando = " Update " & gPropTabelaCorporativo & "[TAB_CTRL_PAGANTEC]"
                    lComando = lComando & " SET [COD_UNID]=" & Mid(lRegistro, 28, 4)
                    lComando = lComando & " , [COD_RAMO]=" & Mid(lRegistro, 32, 3)
                    lComando = lComando & " , [COD_BANCO]=" & Mid(lRegistro, 35, 3)
                    lComando = lComando & " , [NOM_SEGURADO]='" & Trim(Mid(lRegistro, 38, 100)) & "'"
                    lComando = lComando & " , [VAL_PR]=" & Replace(CDbl(Mid(lRegistro, 138, 15)) / 100, ",", ".")
                    lComando = lComando & " , [DAT_VENC]=" & Mid(lRegistro, 153, 8)
                    lComando = lComando & " , [COD_CORR]=" & Mid(lRegistro, 161, 8)
                    lComando = lComando & " , [NUM_LINHA_DIGIT]= '" & Trim(Mid(lRegistro, 169, 100)) & "'"
                    lComando = lComando & " , [COD_USER]='" & Trim(Mid(lRegistro, 269, 10)) & "'"
                    lComando = lComando & " , [DAT_DIGIT]=" & Mid(lRegistro, 279, 8)
                    lComando = lComando & " , [HOR_DIGIT]=" & Mid(lRegistro, 287, 8)
                    lComando = lComando & " , [NUM_PROP] = '" & Mid(lRegistro, 8, 20) & "'"
                    lComando = lComando & " where [NUM_BOLETO]=" & Mid(lBoleto, 2)
                    If lTodosRegistros <> ";;" Then
                        lComando = lComando & " AND [NUM_PROP] = '" & Mid(lRegistro, 8, 20) & "'"
                    Else
                        lComando = lComando & " AND isnull([NUM_PROP],'') = ''"
                    End If
                    
                    If gfExeSQL(mConexaoSQL, lComando, lMensagem) <> 0 Then
                        Call gpGraLog(1, lMensagem)
                        Exit Function
                    End If
                Else
                    'Devo incluir o registro
Incluir:
                    lComando = "INSERT INTO " & gPropTabelaCorporativo & "[TAB_CTRL_PAGANTEC]"
                    lComando = lComando & " ([NUM_BOLETO], [NUM_PROP], [NUM_PI], "
                    lComando = lComando & " [NUM_APOL], [NUM_ENDO], [COD_UNID], "
                    lComando = lComando & " [COD_RAMO], [COD_BANCO], [NOM_SEGURADO], "
                    lComando = lComando & " [VAL_PR], [DAT_VENC], [COD_CORR], "
                    lComando = lComando & " [NUM_LINHA_DIGIT], [COD_USER], [DAT_DIGIT], "
                    lComando = lComando & " [HOR_DIGIT], [DAT_COMPT], [DAT_EMIS_APOL])"
                    lComando = lComando & " VALUES("
                    lComando = lComando & Mid(lRegistro, 2, 6) & ","
                    lComando = lComando & "'" & Mid(lRegistro, 8, 20) & "'," '<NUM_PROP,varchar(20),>
                    lComando = lComando & "0," '<NUM_PI,numeric(10,0),>
                    lComando = lComando & "0," '<NUM_APOL,numeric(10,0)>
                    lComando = lComando & "0," '<NUM_ENDO,numeric(6,0),>,
                    lComando = lComando & Mid(lRegistro, 28, 4) & "," '<COD_UNID,numeric(4,0),>,
                    lComando = lComando & Mid(lRegistro, 32, 3) & "," '<COD_RAMO,numeric(3,0),>,
                    lComando = lComando & Mid(lRegistro, 35, 3) & "," '<COD_BANCO,numeric(4,0),>,
                    lComando = lComando & "'" & Mid(lRegistro, 38, 100) & "'," '<NOM_SEGURADO,varchar(100),>,
                    lComando = lComando & Replace(CDbl(Mid(lRegistro, 138, 15)) / 100, ",", ".") & "," '<VAL_PR,numeric(15,2),>,
                    lComando = lComando & Mid(lRegistro, 153, 8) & "," '<DAT_VENC,numeric(8,0),>,
                    lComando = lComando & Mid(lRegistro, 161, 8) & "," '<COD_CORR,numeric(7,0),>,
                    lComando = lComando & "'" & Trim(Mid(lRegistro, 169, 100)) & "',"  '<NUM_LINHA_DIGIT,varchar(60),>,
                    lComando = lComando & "'" & Trim(Mid(lRegistro, 269, 10)) & "'," '<COD_USER,varchar(20),>,
                    lComando = lComando & Mid(lRegistro, 279, 8) & "," '<DAT_DIGIT,numeric(8,0),>,
                    lComando = lComando & Mid(lRegistro, 287, 8) & "," '<HOR_DIGIT,numeric(6,0),>,
                    lComando = lComando & "0," '<DAT_COMPT,numeric(8,0),>,
                    lComando = lComando & "0" '<DAT_EMIS_APOL,numeric(8,0),>
                    lComando = lComando & ")"
                    If gfExeSQL(mConexaoSQL, lComando, lMensagem) <> 0 Then
                        If UCase(lMensagem) Like "*VIOLATION OF PRIMARY KEY CONSTRAINT*" Then
                            'IGNORAR
                            Call gpGraLog(0, lMensagem)
                            lMensagem = ""
                        Else
                            Call gpGraLog(1, lMensagem)
                            Exit Function
                        End If
                    End If
                End If
            End If
            
            mCodCorretor = Mid(lRegistro, 161, 8)
            mBoletos = mBoletos & lBoleto & ";"
            Print #pNumArqRetorno, lBoleto & IIf(lBoletoDuplicado = True, " DUPLICADO", "")
            If EOF(pNumCopEntrada) Then
                Exit Do
            End If
        End If
    Loop
    
    mfVerEntradaBoleto = True
End Function

Private Sub mpGravaArqBolDuplicado(prst As ADODB.Recordset, pRegistro As String)
Dim lNomeArquivo    As String
Dim lComando        As String
Dim lMensagem       As String
Dim lConexao        As ADODB.Connection
Dim lRst            As ADODB.Recordset
Dim lSequencia      As Long
Dim lArquivo        As Integer

    On Error GoTo ControleErro
    If Not gfAbrBasSQL("SYAS_EMIS", gTipSYASEMIS, gSerSYASEMIS, gEndSYASEMIS, gUidSYASEMIS, _
        gPwdSYASEMIS, mConexaoSQL, lMensagem) Then
        Call gpGraLog(1, lMensagem)
        Exit Sub
    End If
    lComando = " exec " & gPropTabelaCorporativo & "Proc_InserirBoletoDupl " & Mid(pRegistro, 2, 6) & ",'" & Trim(pRegistro) & "'"

    If Not gfObtRegistro(mConexaoSQL, lComando, lRst, lMensagem) Then
        Call gpGraLog(1, lMensagem)
        Exit Sub
    End If
    If Not lRst.EOF Then
        lSequencia = lRst("Chave")
        lNomeArquivo = gAppPath & "BLTD" & Format(lSequencia, "000") & ".txt"
        lArquivo = FreeFile
        Open lNomeArquivo For Output As #lArquivo
        Print #lArquivo, String(80, "=")
        Print #lArquivo, "Boleto duplicado"
        Print #lArquivo, String(80, "=")
        Print #lArquivo, String(10, " ") & Mid(pRegistro, 2, 6)
        Print #lArquivo, String(80, "=")
        Close #lArquivo
        FileCopy lNomeArquivo, "\\spx20103psluapl\export$\Connect\Temp\BLTD" & Format(lSequencia, "000") & ".txt"
    Else
        Call gpGraLog(1, "N�o foi poss�vel gravar o registro de boleto duplicado")
    End If
    Exit Sub
ControleErro:
    Call gpGraLog(1, "Gravando arquivo inconsistente-boleto Erro:" & Err.Description)
End Sub

Private Sub mpProEntradaBoleto(ByRef pEndCopEntrada As String, _
                               ByRef pNumArqRetorno As Integer)
    'Procedure: processa arquivo de entrada (a partir da c�pia do arquivo de entrada).

Dim lMensagem       As String           'Mensagem.
Dim lNumCopEntrada  As Integer      ' antigo gNumCopEntrada
Dim lIsOpen         As Boolean

Err.Clear
On Error GoTo TrataErro

    '1. Verifica arquivo de entrada (atrav�s da c�pia do arquivo).
    lNumCopEntrada = FreeFile
    lIsOpen = False
    Open pEndCopEntrada For Input As #lNumCopEntrada: lIsOpen = True
    
    If mfVerEntradaBoleto(lNumCopEntrada, pNumArqRetorno) = False Then
        ''Call mpGraRetorno("2", lMensagem)
        GoTo SAIDA
    End If
    
SAIDA:
    If lIsOpen = True Then Close #lNumCopEntrada
    Err.Clear
    Exit Sub
    
TrataErro:
    lMensagem = "mpProEntradaBoleto Erro:" & Err & " - " & Error
    Call gpGraLog(0, lMensagem)
    GoTo SAIDA
    
End Sub

Public Function gfObtemDadosINI(ByRef pEndPastas As String, _
                               ByRef pEndSyasEdi As String, _
                               ByRef pIdeBasEAPDB As String, _
                               ByRef pTipBasEAPDB As String, _
                               ByRef pSerBasEAPDB As String, _
                               ByRef pEndBasEAPDB As String, _
                               ByRef pUIDBasEAPDB As String, _
                               ByRef pPWDBasEAPDB As String, _
                               ByRef pIdeBasSYASEMIS As String, _
                               ByRef pTipBasSyasEmis As String, _
                               ByRef pSerBasSYASEMIS As String, _
                               ByRef pEndBasSYASEMIS As String, _
                               ByRef pUIDBasSYASEMIS As String, _
                               ByRef pPWDBasSYASEMIS As String, _
                               ByRef pIdeBasPORTAL As String, _
                               ByRef pTipBasPORTAL As String, _
                               ByRef pSerBasPORTAL As String, _
                               ByRef pEndBasPortal As String, _
                               ByRef pUIDBasPORTAL As String, _
                               ByRef pPWDBasPORTAL As String, _
                               ByRef pMensagem As String) As Boolean
    'Fun��o: Busca os parametros de inicializa��o
  
'******** Exemplo do conteudo do arquivo
'//- Raiz do endere�o onde se localizam as pastas com os arquivos para transferencia/recep��o
'EndPastas = "C:\User_c\P24V007\MailboxesTeste\"
'
'//- Drive "Raiz do programa SYAS-EDI Server (P24V007.exe)
'EndSYASEDI = "C:\User_c\P24V007\"
'
'//- Informa��es da base de dados EAPDB
'IdeBasEAPDB = "EAPDB"
'TipBasEAPDB = "2"
'SerBasEAPDB = "spX20112cslumix"
'EndBasEAPDB = "EAPDB"
'UIDBasEAPDB = "workflow"
'PWDBasEAPDB = "yasworkflow"
'
'//- Informa��es da base de dados Syas_EMIS
'IdeBasSYASEMIS = "SYAS_EMIS"
'TipBasSYASEMIS = "2"
'SerBasSYASEMIS = "spX20112cslumix"
'EndBasSYASEMIS = "SYAS_EMIS"
'UIDBasSYASEMIS = "workflow"
'PWDBasSYASEMIS = "yasworkflow"
'*****************

    Dim lEndP28V300_INI    As String   'Endere�o do arquivo P28V300.INI.
    Dim lNumP28V300_INI    As Integer  'Utilizado com FreeFile.
    Dim lRegistro          As String   'Registro.
    Dim lStrAux            As String   'String auxiliar

Err = 0
On Error GoTo gfObtemDadosINI_ERRO

    gfObtemDadosINI = False

    '1. Verifica arquivo P28V300.INI.
    lEndP28V300_INI = gAppPath & "P28V300.INI"
    If Not gfPreenchido(Dir(lEndP28V300_INI)) Then
        pMensagem = "N�o localizado arquivo de inicializa��o"
        Exit Function
    End If
    lNumP28V300_INI = FreeFile
    Open lEndP28V300_INI For Input Access Read As #lNumP28V300_INI
    If Err <> 0 Then
        pMensagem = "Erro ao abrir arquivo de inicializa��o"
        Exit Function
    End If

     
    Do While Not EOF(lNumP28V300_INI)
        Line Input #lNumP28V300_INI, lRegistro
        'Obtem o usuario de transmissao
        If UCase(Mid(lRegistro, 1, 10)) = "ENDPASTAS=" Then
            lStrAux = Trim(Mid(lRegistro, 11))
            lStrAux = Replace(lStrAux, """", "")
            pEndPastas = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 11)) = "ENDSYASEDI=" Then
            lStrAux = Trim(Mid(lRegistro, 12))
            lStrAux = Replace(lStrAux, """", "")
            pEndSyasEdi = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "IDEBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pIdeBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "TIPBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pTipBasEAPDB = Val(lStrAux)
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "SERBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pSerBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "ENDBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pEndBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "UIDBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pUIDBasEAPDB = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 12)) = "PWDBASEAPDB=" Then
            lStrAux = Trim(Mid(lRegistro, 13))
            lStrAux = Replace(lStrAux, """", "")
            pPWDBasEAPDB = lStrAux
            lStrAux = ""
        End If
        
        If UCase(Mid(lRegistro, 1, 15)) = "IDEBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pIdeBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "TIPBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pTipBasSyasEmis = Val(lStrAux)
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "SERBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pSerBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "ENDBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pEndBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "UIDBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pUIDBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 15)) = "PWDBASSYASEMIS=" Then
            lStrAux = Trim(Mid(lRegistro, 16))
            lStrAux = Replace(lStrAux, """", "")
            pPWDBasSYASEMIS = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 17)) = "IDEBASSYASPORTAL=" Then
            lStrAux = Trim(Mid(lRegistro, 18))
            lStrAux = Replace(lStrAux, """", "")
            pIdeBasPORTAL = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 17)) = "TIPBASSYASPORTAL=" Then
            lStrAux = Trim(Mid(lRegistro, 18))
            lStrAux = Replace(lStrAux, """", "")
            pTipBasPORTAL = Val(lStrAux)
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 17)) = "SERBASSYASPORTAL=" Then
            lStrAux = Trim(Mid(lRegistro, 18))
            lStrAux = Replace(lStrAux, """", "")
            pSerBasPORTAL = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 17)) = "ENDBASSYASPORTAL=" Then
            lStrAux = Trim(Mid(lRegistro, 18))
            lStrAux = Replace(lStrAux, """", "")
            pEndBasPortal = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 17)) = "UIDBASSYASPORTAL=" Then
            lStrAux = Trim(Mid(lRegistro, 18))
            lStrAux = Replace(lStrAux, """", "")
            pUIDBasPORTAL = lStrAux
            lStrAux = ""
        End If
        If UCase(Mid(lRegistro, 1, 17)) = "PWDBASSYASPORTAL=" Then
            lStrAux = Trim(Mid(lRegistro, 18))
            lStrAux = Replace(lStrAux, """", "")
            pPWDBasPORTAL = lStrAux
            lStrAux = ""
        End If
    Loop
    Close #lNumP28V300_INI
    
'- Consiste os dados obtidos
    
    If gfPreenchido(pEndPastas) = False Then
        pMensagem = "N�o foi possivel obter o endere�o das pastas"
        GoTo gfObtemDadosINI_SAIDA
    Else
        If gfPreenchido(Dir(pEndPastas, vbDirectory)) = False Then
            pMensagem = "N�o foi possivel acessar o endere�o " & pEndPastas
            GoTo gfObtemDadosINI_SAIDA
        End If
    End If
    
    If gfPreenchido(pEndSyasEdi) = False Then
        pMensagem = "N�o foi possivel obter o endere�o do servidor SYAS-EDI"
        GoTo gfObtemDadosINI_SAIDA
    Else
        If gfPreenchido(Dir(pEndSyasEdi, vbDirectory)) = False Then
            pMensagem = "N�o foi possivel acessar o endere�o " & pEndSyasEdi
            GoTo gfObtemDadosINI_SAIDA
        End If
    End If
            
    gfObtemDadosINI = True
gfObtemDadosINI_SAIDA:
    Exit Function

gfObtemDadosINI_ERRO:
    If gfPreenchido(pMensagem) = True Then
        pMensagem = " gfObtemDadosINI - ERRO " & pMensagem
    Else
        pMensagem = " gfObtemDadosINI - ERRO " & Err & " - " & Error$
    End If
    Call gpGraLog(2, pMensagem)
    GoTo gfObtemDadosINI_SAIDA
    
End Function
