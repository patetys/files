VERSION 5.00
Begin VB.Form frmT28V300A 
   ClientHeight    =   3195
   ClientLeft      =   2445
   ClientTop       =   1260
   ClientWidth     =   4680
   Icon            =   "T28V300A.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   Visible         =   0   'False
   Begin VB.Timer TimerVerifica 
      Interval        =   500
      Left            =   3930
      Top             =   1170
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Fechar"
      Height          =   690
      Left            =   1380
      TabIndex        =   1
      Top             =   1995
      Width           =   1425
   End
   Begin VB.Shape ShLed 
      BackColor       =   &H0000FF00&
      BackStyle       =   1  'Opaque
      BorderColor     =   &H000000FF&
      Height          =   105
      Left            =   60
      Shape           =   3  'Circle
      Top             =   105
      Visible         =   0   'False
      Width           =   105
   End
   Begin VB.Label Lbl_ArqEst 
      AutoSize        =   -1  'True
      Height          =   195
      Left            =   345
      TabIndex        =   2
      Top             =   900
      Width           =   45
   End
   Begin VB.Label Lbl_ArqSer 
      AutoSize        =   -1  'True
      Height          =   195
      Left            =   360
      TabIndex        =   0
      Top             =   405
      Width           =   45
   End
End
Attribute VB_Name = "frmT28V300A"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Declare Function MoveFile Lib "kernel32" Alias "MoveFileA" _
                         (ByVal lpExistingFileName As String, ByVal lpNewFileName As String) As Long

Private Sub Command1_Click()
End
End Sub

Private Sub mpScanLog()
Dim lEndArqReceb
Dim lArquivoRec

'Desliga o Timer
TimerVerifica.Enabled = False

'THAIS
lEndArqReceb = gEndPastas & "SYASINFO\"
        
'Obtem arquivo recem recebido
    lArquivoRec = Dir(lEndArqReceb & "*.006")
    If gfPreenchido(lArquivoRec) = True Then
        MoveFile lEndArqReceb & lArquivoRec, gAppPath & Mid(lArquivoRec, 1, 12)
    End If
    
    'Call mpProcessa006
    
    Lbl_ArqSer.Caption = "Processados " & gArqSer & " Arquivos Rede"
    Lbl_ArqEst.Caption = "Processados " & gArqEst & " Arquivos Esta��o"

'Liga o Timer
TimerVerifica.Enabled = True

End Sub

Private Sub TimerVerifica_Timer()
    'Led p/ verificar funcionamento
    'Sub Main()
    'If ShLed.Visible = True Then
    '    ShLed.Visible = False
    'Else
    '    ShLed.Visible = True
    'End If
    
   ' Call mpScanLog
End Sub
